"""
Human-Object Interaction (HOI) Detector.

Main orchestrator for depth-aware HOI detection, combining
depth estimation with interaction classification.

Supports both static interactions (HOLDING, TOUCHING, etc.) and
temporal/motion-based interactions (PICKING, DROPPING, CARRYING, etc.).
"""
import time
from collections import defaultdict
from datetime import datetime
from typing import Dict, List, Optional, Set, Tuple

import numpy as np

from core.data_contracts import (
    BoundingBox,
    Detection,
    ObjectDetection,
    DepthMap,
    DepthInfo,
    DetectionWithDepth,
    HOInteraction,
    ActiveHOInteraction,
    HOIDetectionResult,
)
from core.enums import InteractionType, ContactRegion, TargetCategory
from utils import logger

from ..depth import DepthEstimator
from .interaction_classifier import InteractionClassifier
from .motion_tracker import MotionTracker


class HOIDetector:
    """
    Human-Object Interaction detector with depth awareness.

    Combines Depth Anything v2 for depth estimation with
    interaction classification for accurate HOI detection.

    Supports both static and temporal/motion-based interactions.

    Attributes
    ----------
    depth_estimator : DepthEstimator
        Depth estimation model wrapper.
    interaction_classifier : InteractionClassifier
        Interaction classification logic.
    motion_tracker : MotionTracker
        Motion tracking for temporal interactions.
    active_interactions : Dict
        Tracks active (ongoing) interactions per camera.

    Examples
    --------
    >>> detector = HOIDetector(depth_model="small")
    >>> result = detector.detect(frame, persons, objects, camera_id, timestamp)
    >>> for interaction in result.interactions:
    ...     print(f"{interaction.interaction_type}: {interaction.confidence}")
    """

    def __init__(
        self,
        depth_model: str = "small",
        device: str = "auto",
        depth_proximity_threshold: float = 0.15,
        near_threshold: float = 0.3,
        min_confidence: float = 0.5,
        temporal_smoothing: int = 3,
        inactivity_timeout: float = 1.0,
        # Motion tracking parameters
        motion_history_size: int = 10,
        velocity_threshold: float = 20.0,
        loitering_time_threshold: float = 30.0,
        # Group interaction parameters
        group_proximity_threshold: float = 200.0,
        # Retail analytics
        enable_retail_analytics: bool = True,
        browsing_object_threshold: int = 2,
    ) -> None:
        """
        Initialize the HOI detector.

        Parameters
        ----------
        depth_model : str
            Depth model variant ('small', 'base', 'large').
        device : str
            Device for inference ('auto', 'cuda', 'cpu').
        depth_proximity_threshold : float
            Max depth difference for physical interaction.
        near_threshold : float
            Max depth difference for near classification.
        min_confidence : float
            Minimum confidence to report interaction.
        temporal_smoothing : int
            Number of frames for temporal smoothing.
        inactivity_timeout : float
            Seconds before considering interaction ended.
        motion_history_size : int
            Number of frames to keep in motion history.
        velocity_threshold : float
            Minimum velocity (px/s) to consider moving.
        loitering_time_threshold : float
            Seconds before considering loitering.
        group_proximity_threshold : float
            Max distance for group detection.
        enable_retail_analytics : bool
            Enable retail-specific analytics.
        browsing_object_threshold : int
            Min objects examined to classify as browsing.
        """
        self.depth_estimator = DepthEstimator(
            variant=depth_model,
            device=device,
        )

        self.interaction_classifier = InteractionClassifier(
            depth_proximity_threshold=depth_proximity_threshold,
            near_threshold=near_threshold,
            min_confidence=min_confidence,
        )

        self.motion_tracker = MotionTracker(
            history_size=motion_history_size,
            velocity_threshold=velocity_threshold,
            loitering_time_threshold=loitering_time_threshold,
        )

        self.temporal_smoothing = temporal_smoothing
        self.inactivity_timeout = inactivity_timeout
        self.group_proximity_threshold = group_proximity_threshold
        self.enable_retail_analytics = enable_retail_analytics
        self.browsing_object_threshold = browsing_object_threshold

        # Track active interactions per camera: camera_id -> {(person_id, target_id) -> ActiveHOInteraction}
        self.active_interactions: Dict[str, Dict[Tuple[str, str], ActiveHOInteraction]] = defaultdict(dict)

        # Track frame counts for UUID generation
        self._uuid_counters: Dict[str, int] = defaultdict(int)

        # Track examined objects per person for BROWSING detection
        # camera_id -> person_id -> set of object_ids
        self._examined_objects: Dict[str, Dict[int, Set[int]]] = defaultdict(lambda: defaultdict(set))

        logger.info(
            f"HOIDetector initialized: depth_model={depth_model}, "
            f"depth_threshold={depth_proximity_threshold}, "
            f"near_threshold={near_threshold}, "
            f"retail_analytics={enable_retail_analytics}"
        )

    def detect(
        self,
        frame: np.ndarray,
        persons: List[Detection],
        objects: List[ObjectDetection],
        camera_id: str,
        timestamp: datetime,
        frame_number: int = 0,
    ) -> HOIDetectionResult:
        """
        Detect human-object interactions in a frame.

        Detects both static interactions (HOLDING, TOUCHING, etc.) and
        temporal interactions (PICKING, DROPPING, CARRYING, etc.).

        Parameters
        ----------
        frame : np.ndarray
            Input RGB frame (H, W, 3) in BGR format.
        persons : List[Detection]
            Detected persons from YOLO/tracker.
        objects : List[ObjectDetection]
            Detected objects from YOLO.
        camera_id : str
            Camera identifier.
        timestamp : datetime
            Frame timestamp.
        frame_number : int
            Frame number for tracking.

        Returns
        -------
        HOIDetectionResult
            Detection result with all interactions.
        """
        start_time = time.time()

        # Estimate depth
        depth_map = self.depth_estimator.estimate(frame)

        # Enrich detections with depth
        persons_with_depth = self._enrich_persons_with_depth(persons, depth_map)
        objects_with_depth = self._enrich_objects_with_depth(objects, depth_map)

        # Update motion tracker for all entities
        self._update_motion_tracking(
            camera_id, persons_with_depth, objects_with_depth, timestamp, frame_number
        )

        # Detect current frame interactions (static)
        current_interactions = self._detect_frame_interactions(
            persons_with_depth,
            objects_with_depth,
            camera_id,
            timestamp,
        )

        # Detect temporal/motion-based interactions
        temporal_interactions = self._detect_temporal_interactions(
            persons_with_depth,
            objects_with_depth,
            camera_id,
            timestamp,
            current_interactions,
        )
        current_interactions.extend(temporal_interactions)

        # Detect group interactions
        group_interactions = self._detect_group_interactions(
            persons_with_depth,
            camera_id,
            timestamp,
        )
        current_interactions.extend(group_interactions)

        # Detect retail behaviors if enabled
        if self.enable_retail_analytics:
            retail_interactions = self._detect_retail_behaviors(
                persons_with_depth,
                objects_with_depth,
                camera_id,
                timestamp,
            )
            current_interactions.extend(retail_interactions)

        # Detect posture interactions
        posture_interactions = self._detect_posture_interactions(
            persons_with_depth,
            objects_with_depth,
            camera_id,
            timestamp,
        )
        current_interactions.extend(posture_interactions)

        # Update active interactions tracking
        ended_interactions = self._update_active_interactions(
            camera_id,
            current_interactions,
            timestamp,
        )

        # Cleanup stale motion states
        self.motion_tracker.cleanup_stale_states(camera_id, timestamp)

        processing_time = (time.time() - start_time) * 1000

        # Create result with only ended interactions (completed ones)
        result = HOIDetectionResult(
            camera_id=camera_id,
            frame_number=frame_number,
            timestamp=timestamp,
            interactions=ended_interactions,
            depth_map_info=DepthMap(
                width=depth_map.width,
                height=depth_map.height,
                min_depth=depth_map.min_depth,
                max_depth=depth_map.max_depth,
                mean_depth=depth_map.mean_depth,
            ),
            processing_time_ms=processing_time,
        )

        if ended_interactions:
            logger.debug(
                f"[{camera_id}] HOI detection: {len(ended_interactions)} interactions ended, "
                f"processing={processing_time:.1f}ms"
            )

        return result

    def _update_motion_tracking(
        self,
        camera_id: str,
        persons: List[DetectionWithDepth],
        objects: List[DetectionWithDepth],
        timestamp: datetime,
        frame_number: int,
    ) -> None:
        """Update motion tracker with current frame detections."""
        for person in persons:
            depth = person.depth_info.center_depth if person.has_depth else 0.0
            self.motion_tracker.update_person(
                camera_id=camera_id,
                tracking_id=person.tracking_id,
                bbox=person.bbox,
                timestamp=timestamp,
                frame_number=frame_number,
                depth=depth,
            )

        for obj in objects:
            depth = obj.depth_info.center_depth if obj.has_depth else 0.0
            self.motion_tracker.update_object(
                camera_id=camera_id,
                tracking_id=obj.tracking_id,
                bbox=obj.bbox,
                timestamp=timestamp,
                frame_number=frame_number,
                depth=depth,
            )

    def _detect_temporal_interactions(
        self,
        persons: List[DetectionWithDepth],
        objects: List[DetectionWithDepth],
        camera_id: str,
        timestamp: datetime,
        static_interactions: List[HOInteraction],
    ) -> List[HOInteraction]:
        """Detect temporal/motion-based interactions like PICKING, DROPPING, CARRYING."""
        interactions = []

        # Build lookup for static interactions
        static_lookup: Dict[Tuple[str, str], InteractionType] = {}
        for interaction in static_interactions:
            key = (interaction.person_id, interaction.target_id or "")
            static_lookup[key] = interaction.interaction_type

        for person in persons:
            person_id = self._get_entity_id(camera_id, person.tracking_id, "person")

            for obj in objects:
                object_id = self._get_entity_id(camera_id, obj.tracking_id, "object")
                key = (person_id, object_id)

                # Get current static interaction type
                current_interaction = static_lookup.get(key)

                # Check for temporal interaction
                result = self.interaction_classifier.classify_temporal_interaction(
                    person=person,
                    obj=obj,
                    motion_tracker=self.motion_tracker,
                    camera_id=camera_id,
                    current_interaction=current_interaction,
                )

                if result is not None:
                    interaction_type, confidence, contact_region = result

                    depth_distance = 0.0
                    if person.has_depth and obj.has_depth:
                        depth_distance = abs(
                            person.depth_info.center_depth - obj.depth_info.center_depth
                        )

                    interactions.append(HOInteraction(
                        person_id=person_id,
                        target_id=object_id,
                        interaction_type=interaction_type,
                        confidence=confidence,
                        depth_distance=depth_distance,
                        contact_region=contact_region,
                        person_bbox=person.bbox,
                        target_bbox=obj.bbox,
                        target_category=obj.target_category,
                        start_time=timestamp,
                        end_time=None,
                    ))

                # Update interaction state for motion tracker
                is_holding = current_interaction == InteractionType.HOLDING
                self.motion_tracker.update_interaction_state(
                    camera_id=camera_id,
                    person_id=person.tracking_id,
                    object_id=obj.tracking_id,
                    is_holding=is_holding,
                    timestamp=timestamp,
                    object_y=obj.bbox.center.y,
                    object_depth=obj.depth_info.center_depth if obj.has_depth else 0.0,
                )

        return interactions

    def _detect_group_interactions(
        self,
        persons: List[DetectionWithDepth],
        camera_id: str,
        timestamp: datetime,
    ) -> List[HOInteraction]:
        """Detect group interactions like STANDING_TOGETHER, WALKING_TOGETHER, QUEUEING."""
        interactions = []

        result = self.interaction_classifier.classify_group_interaction(
            persons=persons,
            motion_tracker=self.motion_tracker,
            camera_id=camera_id,
            proximity_threshold=self.group_proximity_threshold,
        )

        if result is not None:
            interaction_type, confidence, person_ids = result

            # Create interaction for first person in group targeting "group"
            if person_ids:
                # Sort person_ids to ensure consistent group_id regardless of order
                sorted_person_ids = sorted(person_ids)
                first_person_id = sorted_person_ids[0]
                person = next((p for p in persons if p.tracking_id == first_person_id), None)

                if person:
                    person_id_str = self._get_entity_id(camera_id, first_person_id, "person")
                    # Use sorted IDs for consistent hash
                    group_id = f"group_{camera_id}_{hash(tuple(sorted_person_ids)) % 100000}"

                    interactions.append(HOInteraction(
                        person_id=person_id_str,
                        target_id=group_id,
                        interaction_type=interaction_type,
                        confidence=confidence,
                        depth_distance=0.0,
                        contact_region=ContactRegion.BODY,
                        person_bbox=person.bbox,
                        target_bbox=None,
                        target_category=TargetCategory.GROUP,
                        start_time=timestamp,
                        end_time=None,
                    ))

        return interactions

    def _detect_retail_behaviors(
        self,
        persons: List[DetectionWithDepth],
        objects: List[DetectionWithDepth],
        camera_id: str,
        timestamp: datetime,
    ) -> List[HOInteraction]:
        """Detect retail-specific behaviors like BROWSING, WAITING, LOITERING."""
        interactions = []

        for person in persons:
            person_id = self._get_entity_id(camera_id, person.tracking_id, "person")

            # Track examined objects for BROWSING
            examined = self._examined_objects[camera_id][person.tracking_id]

            # Check for EXAMINING interactions and track objects
            for obj in objects:
                # Simple proximity check for "examining"
                distance = self.interaction_classifier._calculate_spatial_distance(
                    person.bbox, obj.bbox
                )
                if distance < 150:  # Within examining distance
                    examined.add(obj.tracking_id)

            # Check for BROWSING
            browsing_result = self.interaction_classifier.classify_browsing(
                person=person,
                examined_objects=list(examined),
                min_objects_for_browsing=self.browsing_object_threshold,
            )

            if browsing_result is not None:
                interaction_type, confidence, contact_region = browsing_result
                # Use consistent target_id for BROWSING
                browsing_target_id = f"browsing_area_{camera_id}_{person.tracking_id}"
                interactions.append(HOInteraction(
                    person_id=person_id,
                    target_id=browsing_target_id,
                    interaction_type=interaction_type,
                    confidence=confidence,
                    depth_distance=0.0,
                    contact_region=contact_region,
                    person_bbox=person.bbox,
                    target_bbox=None,
                    target_category=TargetCategory.SHELF,
                    start_time=timestamp,
                    end_time=None,
                ))

            # Check for LOITERING
            current_pos = (person.bbox.center.x, person.bbox.center.y)
            is_loitering = self.motion_tracker.detect_loitering(
                camera_id=camera_id,
                person_id=person.tracking_id,
                current_time=timestamp,
                current_position=current_pos,
            )

            if is_loitering:
                # Use consistent target_id for LOITERING so it doesn't create duplicates
                loitering_target_id = f"loitering_zone_{camera_id}_{person.tracking_id}"
                # Use first_seen time as start_time for LOITERING (when they entered the area)
                loitering_start_time = self.motion_tracker.get_person_first_seen(
                    camera_id, person.tracking_id
                ) or timestamp
                interactions.append(HOInteraction(
                    person_id=person_id,
                    target_id=loitering_target_id,
                    interaction_type=InteractionType.LOITERING,
                    confidence=0.75,
                    depth_distance=0.0,
                    contact_region=ContactRegion.UNKNOWN,
                    person_bbox=person.bbox,
                    target_bbox=None,
                    target_category=TargetCategory.UNKNOWN,
                    start_time=loitering_start_time,
                    end_time=None,
                ))

            # Check for WAITING (stationary near service area)
            # Note: This requires zone definition which we simulate with object proximity
            is_stationary = self.motion_tracker.is_person_stationary(camera_id, person.tracking_id)
            near_service = any(
                obj.target_category in [TargetCategory.CHECKOUT, TargetCategory.COUNTER]
                for obj in objects
                if self.interaction_classifier._calculate_spatial_distance(person.bbox, obj.bbox) < 200
            )

            if is_stationary and near_service:
                # Use consistent target_id for WAITING
                waiting_target_id = f"service_area_{camera_id}_{person.tracking_id}"
                interactions.append(HOInteraction(
                    person_id=person_id,
                    target_id=waiting_target_id,
                    interaction_type=InteractionType.WAITING,
                    confidence=0.70,
                    depth_distance=0.0,
                    contact_region=ContactRegion.UNKNOWN,
                    person_bbox=person.bbox,
                    target_bbox=None,
                    target_category=TargetCategory.CHECKOUT,
                    start_time=timestamp,
                    end_time=None,
                ))

        return interactions

    def _detect_posture_interactions(
        self,
        persons: List[DetectionWithDepth],
        objects: List[DetectionWithDepth],
        camera_id: str,
        timestamp: datetime,
    ) -> List[HOInteraction]:
        """Detect posture-based interactions like SITTING_ON, CROUCHING, BENDING."""
        interactions = []

        # Find furniture objects
        furniture = [
            obj for obj in objects
            if obj.target_category in [
                TargetCategory.CHAIR,
                TargetCategory.COUCH,
                TargetCategory.BED,
            ]
        ]

        for person in persons:
            person_id = self._get_entity_id(camera_id, person.tracking_id, "person")

            # Find nearest furniture
            nearby_furniture = None
            min_distance = float('inf')

            for furn in furniture:
                distance = self.interaction_classifier._calculate_spatial_distance(
                    person.bbox, furn.bbox
                )
                if distance < min_distance and distance < 200:  # Within range
                    min_distance = distance
                    nearby_furniture = furn

            # Classify posture
            result = self.interaction_classifier.classify_posture_interaction(
                person=person,
                nearby_furniture=nearby_furniture,
            )

            if result is not None:
                interaction_type, confidence, contact_region = result

                interactions.append(HOInteraction(
                    person_id=person_id,
                    target_id=self._get_entity_id(camera_id, nearby_furniture.tracking_id, "object") if nearby_furniture else None,
                    interaction_type=interaction_type,
                    confidence=confidence,
                    depth_distance=0.0,
                    contact_region=contact_region,
                    person_bbox=person.bbox,
                    target_bbox=nearby_furniture.bbox if nearby_furniture else None,
                    target_category=nearby_furniture.target_category if nearby_furniture else TargetCategory.UNKNOWN,
                    start_time=timestamp,
                    end_time=None,
                ))

        return interactions

    def _enrich_persons_with_depth(
        self,
        persons: List[Detection],
        depth_map: DepthMap,
    ) -> List[DetectionWithDepth]:
        """Add depth information to person detections."""
        enriched = []
        for person in persons:
            # Convert bbox list to BoundingBox if needed
            if isinstance(person.bbox, list) and len(person.bbox) == 4:
                bbox = BoundingBox.from_list(person.bbox)
            else:
                bbox = person.bbox

            depth_info = depth_map.get_depth_in_bbox(bbox)

            enriched.append(DetectionWithDepth(
                tracking_id=person.tracking_id or 0,
                bbox=bbox,
                confidence=person.confidence,
                class_name="person",
                target_category=TargetCategory.PERSON,
                depth_info=depth_info,
            ))

        return enriched

    def _enrich_objects_with_depth(
        self,
        objects: List[ObjectDetection],
        depth_map: DepthMap,
    ) -> List[DetectionWithDepth]:
        """Add depth information to object detections."""
        enriched = []
        for obj in objects:
            depth_info = depth_map.get_depth_in_bbox(obj.bbox)

            enriched.append(DetectionWithDepth(
                tracking_id=obj.tracking_id,
                bbox=obj.bbox,
                confidence=obj.confidence,
                class_name=obj.class_name,
                target_category=obj.target_category,
                depth_info=depth_info,
            ))

        return enriched

    def _detect_frame_interactions(
        self,
        persons: List[DetectionWithDepth],
        objects: List[DetectionWithDepth],
        camera_id: str,
        timestamp: datetime,
    ) -> List[HOInteraction]:
        """Detect all interactions in current frame."""
        interactions = []

        # Person-Object interactions
        for person in persons:
            person_id = self._get_entity_id(camera_id, person.tracking_id, "person")

            for obj in objects:
                result = self.interaction_classifier.classify_person_object_interaction(
                    person, obj
                )

                if result is not None:
                    interaction_type, confidence, contact_region = result
                    object_id = self._get_entity_id(camera_id, obj.tracking_id, "object")

                    depth_distance = 0.0
                    if person.has_depth and obj.has_depth:
                        depth_distance = abs(
                            person.depth_info.center_depth - obj.depth_info.center_depth
                        )

                    interactions.append(HOInteraction(
                        person_id=person_id,
                        target_id=object_id,
                        interaction_type=interaction_type,
                        confidence=confidence,
                        depth_distance=depth_distance,
                        contact_region=contact_region,
                        person_bbox=person.bbox,
                        target_bbox=obj.bbox,
                        target_category=obj.target_category,
                        start_time=timestamp,
                        end_time=None,
                    ))

        # Person-Person interactions
        for i, person1 in enumerate(persons):
            person1_id = self._get_entity_id(camera_id, person1.tracking_id, "person")

            for person2 in persons[i + 1:]:
                result = self.interaction_classifier.classify_person_person_interaction(
                    person1, person2
                )

                if result is not None:
                    interaction_type, confidence, contact_region = result
                    person2_id = self._get_entity_id(camera_id, person2.tracking_id, "person")

                    depth_distance = 0.0
                    if person1.has_depth and person2.has_depth:
                        depth_distance = abs(
                            person1.depth_info.center_depth - person2.depth_info.center_depth
                        )

                    interactions.append(HOInteraction(
                        person_id=person1_id,
                        target_id=person2_id,
                        interaction_type=interaction_type,
                        confidence=confidence,
                        depth_distance=depth_distance,
                        contact_region=contact_region,
                        person_bbox=person1.bbox,
                        target_bbox=person2.bbox,
                        target_category=TargetCategory.PERSON,
                        start_time=timestamp,
                        end_time=None,
                    ))

        return interactions

    def _update_active_interactions(
        self,
        camera_id: str,
        current_interactions: List[HOInteraction],
        timestamp: datetime,
    ) -> List[HOInteraction]:
        """
        Update active interactions and return ended ones.

        Tracks ongoing interactions by (person_id, interaction_type, target_category)
        to consolidate multiple interactions of the same type into one continuous event.
        """
        camera_active = self.active_interactions[camera_id]
        ended_interactions = []
        current_keys = set()

        # Update or create active interactions
        for interaction in current_interactions:
            # Use (person_id, interaction_type, target_category) as key
            # This consolidates e.g. "TOUCHING multiple SHELF_ITEMs" into one interaction
            interaction_type_str = (
                interaction.interaction_type.value 
                if hasattr(interaction.interaction_type, 'value') 
                else str(interaction.interaction_type)
            )
            target_category_str = (
                interaction.target_category.value 
                if hasattr(interaction.target_category, 'value') 
                else str(interaction.target_category)
            )
            key = (interaction.person_id, interaction_type_str, target_category_str)
            current_keys.add(key)

            if key in camera_active:
                # Update existing - same person doing same interaction type with same category
                active = camera_active[key]
                active.last_seen = timestamp
                # Update to highest confidence seen
                if interaction.confidence > active.confidence:
                    active.confidence = interaction.confidence
                    active.depth_distance = interaction.depth_distance
                    active.contact_region = interaction.contact_region
                # Always update bboxes and target_id to latest
                active.person_bbox = interaction.person_bbox
                active.target_bbox = interaction.target_bbox
                active.target_id = interaction.target_id
                active.frame_count += 1
            else:
                # New interaction
                camera_active[key] = ActiveHOInteraction(
                    camera_id=camera_id,
                    person_id=interaction.person_id,
                    target_id=interaction.target_id,
                    interaction_type=interaction.interaction_type,
                    target_category=interaction.target_category,
                    confidence=interaction.confidence,
                    depth_distance=interaction.depth_distance,
                    contact_region=interaction.contact_region,
                    person_bbox=interaction.person_bbox,
                    target_bbox=interaction.target_bbox,
                    start_time=interaction.start_time or timestamp,
                    last_seen=timestamp,
                    frame_count=1,
                )

                logger.info(
                    f"[{camera_id}] New HOI interaction: "
                    f"{interaction_type_str} "
                    f"({target_category_str}), "
                    f"confidence={interaction.confidence:.2f}, "
                    f"depth_distance={interaction.depth_distance:.3f}"
                )

        # Check for ended interactions
        keys_to_remove = []
        for key, active in camera_active.items():
            if key not in current_keys:
                # Check timeout
                elapsed = (timestamp - active.last_seen).total_seconds()
                if elapsed > self.inactivity_timeout:
                    # Interaction ended - only report if enough frames
                    if active.frame_count >= self.temporal_smoothing:
                        ended = active.to_hoi_interaction()
                        ended_interactions.append(ended)

                        duration = ended.duration_seconds or 0
                        # Handle both enum and string values
                        ended_type_str = (
                            ended.interaction_type.value 
                            if hasattr(ended.interaction_type, 'value') 
                            else str(ended.interaction_type)
                        )
                        ended_category_str = (
                            ended.target_category.value 
                            if hasattr(ended.target_category, 'value') 
                            else str(ended.target_category)
                        )
                        logger.info(
                            f"[{camera_id}] HOI interaction ended: "
                            f"{ended_type_str} "
                            f"({ended_category_str}), "
                            f"duration={duration:.2f}s, "
                            f"frames={active.frame_count}"
                        )

                    keys_to_remove.append(key)

        # Remove ended interactions
        for key in keys_to_remove:
            del camera_active[key]

        return ended_interactions

    def _get_entity_id(self, camera_id: str, tracking_id: int, entity_type: str) -> str:
        """Generate consistent entity ID."""
        return f"{entity_type}_{camera_id}_{tracking_id}"

    def get_active_interaction_count(self, camera_id: Optional[str] = None) -> int:
        """Get count of active interactions."""
        if camera_id:
            return len(self.active_interactions.get(camera_id, {}))
        return sum(len(v) for v in self.active_interactions.values())

    def flush_camera(self, camera_id: str, timestamp: datetime) -> List[HOInteraction]:
        """
        Flush all active interactions for a camera.

        Used when camera disconnects or service stops.
        """
        camera_active = self.active_interactions.get(camera_id, {})
        ended = []

        for key, active in camera_active.items():
            active.last_seen = timestamp
            if active.frame_count >= self.temporal_smoothing:
                ended.append(active.to_hoi_interaction())

        # Clear active interactions for this camera
        if camera_id in self.active_interactions:
            del self.active_interactions[camera_id]

        return ended

    @property
    def is_depth_available(self) -> bool:
        """Check if depth estimation is available."""
        return self.depth_estimator.is_available
