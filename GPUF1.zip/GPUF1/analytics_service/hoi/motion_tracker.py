"""
Motion Tracker for temporal state tracking in HOI detection.

This module provides motion tracking capabilities for detecting
temporal interactions like PICKING, DROPPING, CARRYING, etc.
"""

import math
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional, Tuple

import numpy as np

from core.data_contracts import BoundingBox
from core.enums import InteractionType
from utils import logger


@dataclass
class PositionState:
  """Represents the position state of an entity at a point in time."""
  tracking_id: int
  timestamp: datetime
  bbox: BoundingBox
  center_x: float
  center_y: float
  depth: float = 0.0
  frame_number: int = 0


@dataclass
class MotionState:
  """
  Tracks motion state for an entity over time.

  Attributes
  ----------
  tracking_id : int
    Entity tracking ID.
  positions : List[PositionState]
    History of positions (most recent last).
  velocity_x : float
    Horizontal velocity (pixels/second).
  velocity_y : float
    Vertical velocity (pixels/second).
  velocity_depth : float
    Depth velocity (units/second).
  is_moving : bool
    Whether entity is currently moving.
  movement_direction : str
    Direction of movement (UP, DOWN, LEFT, RIGHT, STATIONARY).
  """
  tracking_id: int
  positions: List[PositionState] = field(default_factory=list)
  velocity_x: float = 0.0
  velocity_y: float = 0.0
  velocity_depth: float = 0.0
  is_moving: bool = False
  movement_direction: str = "STATIONARY"
  last_interaction_type: Optional[InteractionType] = None
  interaction_start_time: Optional[datetime] = None

  @property
  def speed(self) -> float:
    """Calculate overall speed magnitude."""
    return math.sqrt(self.velocity_x ** 2 + self.velocity_y ** 2)

  @property
  def is_moving_up(self) -> bool:
    """Check if entity is moving upward (negative Y in image coords)."""
    return self.velocity_y < -10  # Threshold for upward movement

  @property
  def is_moving_down(self) -> bool:
    """Check if entity is moving downward."""
    return self.velocity_y > 10  # Threshold for downward movement

  @property
  def is_moving_toward_camera(self) -> bool:
    """Check if entity is moving toward camera (depth decreasing)."""
    return self.velocity_depth < -0.01

  @property
  def is_moving_away_from_camera(self) -> bool:
    """Check if entity is moving away from camera (depth increasing)."""
    return self.velocity_depth > 0.01


@dataclass
class InteractionState:
  """
  Tracks the state of an interaction between person and object.

  Used for detecting temporal interactions like PICKING, DROPPING.
  """
  person_id: int
  object_id: int
  interaction_type: InteractionType
  start_time: datetime
  last_seen: datetime
  object_start_y: float  # Y position when interaction started
  object_start_depth: float  # Depth when interaction started
  was_holding: bool = False
  is_holding: bool = False


class MotionTracker:
  """
  Tracks motion of persons and objects for temporal interaction detection.

  This class maintains position history and calculates velocities to detect
  motion-based interactions like PICKING, DROPPING, CARRYING, etc.

  Attributes
  ----------
  history_size : int
    Number of frames to keep in position history.
  velocity_threshold : float
    Minimum velocity to consider entity as moving.
  stationary_threshold : float
    Maximum velocity to consider entity as stationary.
  """

  def __init__(
    self,
    history_size: int = 10,
    velocity_threshold: float = 20.0,
    stationary_threshold: float = 5.0,
    picking_velocity_threshold: float = 15.0,
    carrying_velocity_threshold: float = 10.0,
    loitering_time_threshold: float = 30.0,  # seconds
  ) -> None:
    """
    Initialize the motion tracker.

    Parameters
    ----------
    history_size : int
      Number of frames to keep in position history.
    velocity_threshold : float
      Minimum velocity (px/s) to consider entity as moving.
    stationary_threshold : float
      Maximum velocity (px/s) to consider entity as stationary.
    picking_velocity_threshold : float
      Minimum upward velocity for PICKING detection.
    carrying_velocity_threshold : float
      Minimum velocity for person to be considered CARRYING.
    loitering_time_threshold : float
      Seconds before considering a person as LOITERING.
    """
    self.history_size = history_size
    self.velocity_threshold = velocity_threshold
    self.stationary_threshold = stationary_threshold
    self.picking_velocity_threshold = picking_velocity_threshold
    self.carrying_velocity_threshold = carrying_velocity_threshold
    self.loitering_time_threshold = loitering_time_threshold

    # Per-camera tracking
    # camera_id -> tracking_id -> MotionState
    self.person_states: Dict[str, Dict[int, MotionState]] = defaultdict(dict)
    self.object_states: Dict[str, Dict[int, MotionState]] = defaultdict(dict)

    # Interaction states for temporal tracking
    # camera_id -> (person_id, object_id) -> InteractionState
    self.interaction_states: Dict[str, Dict[Tuple[int, int], InteractionState]] = defaultdict(dict)

    # First seen time for loitering detection
    # camera_id -> person_id -> first_seen_time
    self.first_seen: Dict[str, Dict[int, datetime]] = defaultdict(dict)

    # Position when first seen (for waiting/loitering)
    # camera_id -> person_id -> (center_x, center_y)
    self.first_position: Dict[str, Dict[int, Tuple[float, float]]] = defaultdict(dict)

  def update_person(
    self,
    camera_id: str,
    tracking_id: int,
    bbox: BoundingBox,
    timestamp: datetime,
    frame_number: int,
    depth: float = 0.0,
  ) -> MotionState:
    """
    Update position for a person and calculate motion state.

    Parameters
    ----------
    camera_id : str
      Camera identifier.
    tracking_id : int
      Person tracking ID.
    bbox : BoundingBox
      Current bounding box.
    timestamp : datetime
      Current timestamp.
    frame_number : int
      Current frame number.
    depth : float
      Depth value (0-1, relative).

    Returns
    -------
    MotionState
      Updated motion state for this person.
    """
    return self._update_entity(
      states=self.person_states[camera_id],
      tracking_id=tracking_id,
      bbox=bbox,
      timestamp=timestamp,
      frame_number=frame_number,
      depth=depth,
    )

  def update_object(
    self,
    camera_id: str,
    tracking_id: int,
    bbox: BoundingBox,
    timestamp: datetime,
    frame_number: int,
    depth: float = 0.0,
  ) -> MotionState:
    """
    Update position for an object and calculate motion state.

    Parameters
    ----------
    camera_id : str
      Camera identifier.
    tracking_id : int
      Object tracking ID.
    bbox : BoundingBox
      Current bounding box.
    timestamp : datetime
      Current timestamp.
    frame_number : int
      Current frame number.
    depth : float
      Depth value (0-1, relative).

    Returns
    -------
    MotionState
      Updated motion state for this object.
    """
    return self._update_entity(
      states=self.object_states[camera_id],
      tracking_id=tracking_id,
      bbox=bbox,
      timestamp=timestamp,
      frame_number=frame_number,
      depth=depth,
    )

  def _update_entity(
    self,
    states: Dict[int, MotionState],
    tracking_id: int,
    bbox: BoundingBox,
    timestamp: datetime,
    frame_number: int,
    depth: float = 0.0,
  ) -> MotionState:
    """Update motion state for any entity."""
    center_x = bbox.center.x
    center_y = bbox.center.y

    # Create position state
    position = PositionState(
      tracking_id=tracking_id,
      timestamp=timestamp,
      bbox=bbox,
      center_x=center_x,
      center_y=center_y,
      depth=depth,
      frame_number=frame_number,
    )

    # Get or create motion state
    if tracking_id not in states:
      states[tracking_id] = MotionState(tracking_id=tracking_id)

    motion_state = states[tracking_id]
    motion_state.positions.append(position)

    # Trim history
    if len(motion_state.positions) > self.history_size:
      motion_state.positions = motion_state.positions[-self.history_size:]

    # Calculate velocity if we have enough history
    if len(motion_state.positions) >= 2:
      self._calculate_velocity(motion_state)

    return motion_state

  def _calculate_velocity(self, motion_state: MotionState) -> None:
    """Calculate velocity from position history."""
    if len(motion_state.positions) < 2:
      return

    # Use last few positions for smoother velocity
    recent = motion_state.positions[-3:] if len(motion_state.positions) >= 3 else motion_state.positions

    oldest = recent[0]
    newest = recent[-1]

    # Time difference in seconds
    dt = (newest.timestamp - oldest.timestamp).total_seconds()
    if dt <= 0:
      return

    # Calculate velocities
    motion_state.velocity_x = (newest.center_x - oldest.center_x) / dt
    motion_state.velocity_y = (newest.center_y - oldest.center_y) / dt
    motion_state.velocity_depth = (newest.depth - oldest.depth) / dt

    # Determine if moving
    speed = motion_state.speed
    motion_state.is_moving = speed > self.velocity_threshold

    # Determine direction
    if speed < self.stationary_threshold:
      motion_state.movement_direction = "STATIONARY"
    elif abs(motion_state.velocity_y) > abs(motion_state.velocity_x):
      motion_state.movement_direction = "UP" if motion_state.velocity_y < 0 else "DOWN"
    else:
      motion_state.movement_direction = "LEFT" if motion_state.velocity_x < 0 else "RIGHT"

  def get_person_motion(self, camera_id: str, tracking_id: int) -> Optional[MotionState]:
    """Get motion state for a person."""
    return self.person_states.get(camera_id, {}).get(tracking_id)

  def get_object_motion(self, camera_id: str, tracking_id: int) -> Optional[MotionState]:
    """Get motion state for an object."""
    return self.object_states.get(camera_id, {}).get(tracking_id)

  def detect_picking(
    self,
    camera_id: str,
    person_id: int,
    object_id: int,
    is_currently_holding: bool,
  ) -> bool:
    """
    Detect if a PICKING action is occurring.

    PICKING = object was not held, now is held, and object moved upward.

    Parameters
    ----------
    camera_id : str
      Camera identifier.
    person_id : int
      Person tracking ID.
    object_id : int
      Object tracking ID.
    is_currently_holding : bool
      Whether person is currently holding the object.

    Returns
    -------
    bool
      True if PICKING action detected.
    """
    key = (person_id, object_id)
    interaction = self.interaction_states[camera_id].get(key)
    object_motion = self.get_object_motion(camera_id, object_id)

    if object_motion is None:
      return False

    # Check for transition from not-holding to holding
    was_holding = interaction.was_holding if interaction else False

    if not was_holding and is_currently_holding:
      # Check if object moved upward
      if object_motion.is_moving_up or object_motion.velocity_y < -self.picking_velocity_threshold:
        return True

    return False

  def detect_dropping(
    self,
    camera_id: str,
    person_id: int,
    object_id: int,
    is_currently_holding: bool,
  ) -> bool:
    """
    Detect if a DROPPING action is occurring.

    DROPPING = object was held, now is not held, and object moving downward.

    Parameters
    ----------
    camera_id : str
      Camera identifier.
    person_id : int
      Person tracking ID.
    object_id : int
      Object tracking ID.
    is_currently_holding : bool
      Whether person is currently holding the object.

    Returns
    -------
    bool
      True if DROPPING action detected.
    """
    key = (person_id, object_id)
    interaction = self.interaction_states[camera_id].get(key)
    object_motion = self.get_object_motion(camera_id, object_id)

    if object_motion is None:
      return False

    # Check for transition from holding to not-holding
    was_holding = interaction.was_holding if interaction else False

    if was_holding and not is_currently_holding:
      # Check if object moving downward
      if object_motion.is_moving_down:
        return True

    return False

  def detect_placing(
    self,
    camera_id: str,
    person_id: int,
    object_id: int,
    is_currently_holding: bool,
  ) -> bool:
    """
    Detect if a PLACING action is occurring.

    PLACING = object was held, now not held, object moved away (depth increased).

    Parameters
    ----------
    camera_id : str
      Camera identifier.
    person_id : int
      Person tracking ID.
    object_id : int
      Object tracking ID.
    is_currently_holding : bool
      Whether person is currently holding the object.

    Returns
    -------
    bool
      True if PLACING action detected.
    """
    key = (person_id, object_id)
    interaction = self.interaction_states[camera_id].get(key)
    object_motion = self.get_object_motion(camera_id, object_id)

    if object_motion is None:
      return False

    was_holding = interaction.was_holding if interaction else False

    if was_holding and not is_currently_holding:
      # Check if object moved away from camera (placed on surface)
      if object_motion.is_moving_away_from_camera:
        return True
      # Or if object is now stationary (placed down gently)
      if not object_motion.is_moving:
        return True

    return False

  def detect_carrying(
    self,
    camera_id: str,
    person_id: int,
    is_holding: bool,
  ) -> bool:
    """
    Detect if a person is CARRYING an object.

    CARRYING = person is holding + person is moving.

    Parameters
    ----------
    camera_id : str
      Camera identifier.
    person_id : int
      Person tracking ID.
    is_holding : bool
      Whether person is holding any object.

    Returns
    -------
    bool
      True if CARRYING detected.
    """
    if not is_holding:
      return False

    person_motion = self.get_person_motion(camera_id, person_id)
    if person_motion is None:
      return False

    return person_motion.speed > self.carrying_velocity_threshold

  def detect_loitering(
    self,
    camera_id: str,
    person_id: int,
    current_time: datetime,
    current_position: Tuple[float, float],
    max_displacement: float = 100.0,
  ) -> bool:
    """
    Detect if a person is LOITERING.

    LOITERING = person in same general area for extended time.

    Parameters
    ----------
    camera_id : str
      Camera identifier.
    person_id : int
      Person tracking ID.
    current_time : datetime
      Current timestamp.
    current_position : Tuple[float, float]
      Current (x, y) center position.
    max_displacement : float
      Maximum displacement from first position to still count as loitering.

    Returns
    -------
    bool
      True if LOITERING detected.
    """
    # Track first seen
    if person_id not in self.first_seen[camera_id]:
      self.first_seen[camera_id][person_id] = current_time
      self.first_position[camera_id][person_id] = current_position
      return False

    first_time = self.first_seen[camera_id][person_id]
    first_pos = self.first_position[camera_id][person_id]

    # Calculate time in area
    time_in_area = (current_time - first_time).total_seconds()

    # Calculate displacement from first position
    dx = current_position[0] - first_pos[0]
    dy = current_position[1] - first_pos[1]
    displacement = math.sqrt(dx * dx + dy * dy)

    # If person moved too far, reset first seen
    if displacement > max_displacement:
      self.first_seen[camera_id][person_id] = current_time
      self.first_position[camera_id][person_id] = current_position
      return False

    return time_in_area > self.loitering_time_threshold

  def detect_waiting(
    self,
    camera_id: str,
    person_id: int,
    is_stationary: bool,
    near_service_area: bool,
  ) -> bool:
    """
    Detect if a person is WAITING.

    WAITING = person is stationary near a service area.

    Parameters
    ----------
    camera_id : str
      Camera identifier.
    person_id : int
      Person tracking ID.
    is_stationary : bool
      Whether person is stationary.
    near_service_area : bool
      Whether person is near a service area (checkout, counter, etc.).

    Returns
    -------
    bool
      True if WAITING detected.
    """
    if not is_stationary:
      return False

    person_motion = self.get_person_motion(camera_id, person_id)
    if person_motion is None:
      return near_service_area

    return not person_motion.is_moving and near_service_area

  def update_interaction_state(
    self,
    camera_id: str,
    person_id: int,
    object_id: int,
    is_holding: bool,
    timestamp: datetime,
    object_y: float,
    object_depth: float,
  ) -> None:
    """
    Update the interaction state between a person and object.

    This tracks holding transitions for PICKING/DROPPING detection.

    Parameters
    ----------
    camera_id : str
      Camera identifier.
    person_id : int
      Person tracking ID.
    object_id : int
      Object tracking ID.
    is_holding : bool
      Whether person is currently holding the object.
    timestamp : datetime
      Current timestamp.
    object_y : float
      Current Y position of object.
    object_depth : float
      Current depth of object.
    """
    key = (person_id, object_id)

    if key not in self.interaction_states[camera_id]:
      self.interaction_states[camera_id][key] = InteractionState(
        person_id=person_id,
        object_id=object_id,
        interaction_type=InteractionType.UNKNOWN,
        start_time=timestamp,
        last_seen=timestamp,
        object_start_y=object_y,
        object_start_depth=object_depth,
        was_holding=False,
        is_holding=is_holding,
      )
    else:
      state = self.interaction_states[camera_id][key]
      state.was_holding = state.is_holding
      state.is_holding = is_holding
      state.last_seen = timestamp

  def cleanup_stale_states(
    self,
    camera_id: str,
    current_time: datetime,
    max_age_seconds: float = 5.0,
  ) -> None:
    """
    Remove stale tracking states that haven't been updated.

    Parameters
    ----------
    camera_id : str
      Camera identifier.
    current_time : datetime
      Current timestamp.
    max_age_seconds : float
      Maximum age before state is considered stale.
    """
    # Cleanup person states
    stale_persons = []
    for tracking_id, motion_state in self.person_states.get(camera_id, {}).items():
      if motion_state.positions:
        age = (current_time - motion_state.positions[-1].timestamp).total_seconds()
        if age > max_age_seconds:
          stale_persons.append(tracking_id)

    for tracking_id in stale_persons:
      del self.person_states[camera_id][tracking_id]
      if tracking_id in self.first_seen.get(camera_id, {}):
        del self.first_seen[camera_id][tracking_id]
      if tracking_id in self.first_position.get(camera_id, {}):
        del self.first_position[camera_id][tracking_id]

    # Cleanup object states
    stale_objects = []
    for tracking_id, motion_state in self.object_states.get(camera_id, {}).items():
      if motion_state.positions:
        age = (current_time - motion_state.positions[-1].timestamp).total_seconds()
        if age > max_age_seconds:
          stale_objects.append(tracking_id)

    for tracking_id in stale_objects:
      del self.object_states[camera_id][tracking_id]

    # Cleanup interaction states
    stale_interactions = []
    for key, state in self.interaction_states.get(camera_id, {}).items():
      age = (current_time - state.last_seen).total_seconds()
      if age > max_age_seconds:
        stale_interactions.append(key)

    for key in stale_interactions:
      del self.interaction_states[camera_id][key]

  def is_person_stationary(self, camera_id: str, person_id: int) -> bool:
    """Check if a person is stationary."""
    motion = self.get_person_motion(camera_id, person_id)
    if motion is None:
      return True  # Assume stationary if no motion data
    return not motion.is_moving

  def get_person_first_seen(self, camera_id: str, person_id: int) -> Optional[datetime]:
    """
    Get the first time a person was seen in an area.

    Used for LOITERING start_time calculation.

    Parameters
    ----------
    camera_id : str
      Camera identifier.
    person_id : int
      Person tracking ID.

    Returns
    -------
    Optional[datetime]
      First seen timestamp, or None if not tracked.
    """
    return self.first_seen.get(camera_id, {}).get(person_id)
