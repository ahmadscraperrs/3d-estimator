"""
Async Kafka Consumer Service for Analytics.

This module provides an asynchronous Kafka consumer for
consuming person detection events from the KAFKA_OUTPUT_TOPIC topic.
"""

import json
from typing import AsyncGenerator, Optional, Callable, Awaitable, List

from aiokafka import AIOKafkaConsumer
from aiokafka.errors import KafkaError
from pydantic import ValidationError

from core import configs
from core.data_contracts import (
    KafkaPersonDetectionEvent,
    ConsumerStats,
)
from utils import logger


class KafkaConsumerService:
    """
    Async Kafka consumer service for person detection events.

    This service consumes messages from the configured person detection
    topic and yields parsed KafkaPersonDetectionEvent objects.

    Attributes
    ----------
    _bootstrap_servers : str
        Kafka bootstrap servers connection string.
    _topic : str
        Source topic for person detection events.
    _group_id : str
        Consumer group ID.
    _consumer : AIOKafkaConsumer or None
        Underlying aiokafka consumer instance.
    _running : bool
        Consumer running state.
    _message_count : int
        Total messages consumed.
    _error_count : int
        Total parsing/consumption errors.

    Examples
    --------
    >>> consumer = KafkaConsumerService()
    >>> await consumer.start()
    >>> async for event in consumer.consume():
    ...     process_event(event)
    >>> await consumer.stop()
    """

    def __init__(
            self,
            bootstrap_servers: Optional[str] = None,
            topic: Optional[str] = None,
            group_id: Optional[str] = None,
    ) -> None:
        """
        Initialize Kafka consumer service.

        Parameters
        ----------
        bootstrap_servers : str, optional
            Kafka bootstrap servers. Defaults to config value.
        topic : str, optional
            Topic to consume from. Defaults to config value.
        group_id : str, optional
            Consumer group ID. Defaults to config value.
        """
        self._bootstrap_servers = bootstrap_servers or configs.kafka_bootstrap_servers
        self._topic = topic or configs.kafka_topic_input
        self._group_id = group_id or configs.kafka_consumer_group_id

        self._consumer: Optional[AIOKafkaConsumer] = None
        self._running = False
        self._message_count = 0
        self._error_count = 0

        # Consumer configuration from config
        self._auto_offset_reset = configs.kafka_consumer_auto_offset_reset
        self._enable_auto_commit = configs.kafka_consumer_enable_auto_commit
        self._max_poll_interval_ms = configs.kafka_consumer_max_poll_interval_ms
        self._session_timeout_ms = configs.kafka_consumer_session_timeout_ms
        self._heartbeat_interval_ms = configs.kafka_consumer_heartbeat_interval_ms

    async def start(self) -> None:
        """
        Start the Kafka consumer.

        Creates and starts the underlying AIOKafkaConsumer instance
        with low-latency settings.

        Raises
        ------
        KafkaError
            If connection to Kafka brokers fails.
        """
        if self._consumer is not None:
            logger.warning("Consumer already started")
            return

        logger.info(
            f"Starting Kafka consumer: servers={self._bootstrap_servers}, "
            f"topic={self._topic}, group={self._group_id}"
        )

        self._consumer = AIOKafkaConsumer(
            self._topic,
            bootstrap_servers=self._bootstrap_servers,
            group_id=self._group_id,
            auto_offset_reset=self._auto_offset_reset,
            enable_auto_commit=self._enable_auto_commit,
            max_poll_interval_ms=self._max_poll_interval_ms,
            session_timeout_ms=self._session_timeout_ms,
            heartbeat_interval_ms=self._heartbeat_interval_ms,
            value_deserializer=self._deserialize_value,
            # Low-latency settings
            fetch_min_bytes=1,  # Don't wait for minimum bytes
            fetch_max_wait_ms=10,  # Low wait time for faster fetching
            max_partition_fetch_bytes=10485760,  # 10MB per partition
        )

        await self._consumer.start()
        self._running = True
        logger.info("Kafka consumer started successfully")

    async def stop(self) -> None:
        """
        Stop the Kafka consumer.

        Commits offsets and closes the connection.
        """
        if self._consumer is None:
            return

        logger.info("Stopping Kafka consumer...")
        self._running = False

        try:
            await self._consumer.stop()
        except Exception as e:
            logger.error(f"Error stopping consumer: {e}")
        finally:
            self._consumer = None

        logger.info(
            f"Kafka consumer stopped. Messages: {self._message_count}, Errors: {self._error_count}"
        )

    def _deserialize_value(self, value: bytes) -> dict:
        """
        Deserialize Kafka message value from JSON bytes.

        Parameters
        ----------
        value : bytes
            Raw message bytes.

        Returns
        -------
        dict
            Parsed JSON dictionary, or empty dict on error.
        """
        try:
            return json.loads(value.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            logger.error(f"Failed to deserialize message: {e}")
            return {}

    def _parse_event(self, data: dict) -> Optional[KafkaPersonDetectionEvent]:
        """
        Parse raw message data into KafkaPersonDetectionEvent.

        Parameters
        ----------
        data : dict
            Raw message dictionary from Kafka.

        Returns
        -------
        KafkaPersonDetectionEvent or None
            Parsed event, or None if parsing fails.
        """
        try:
            # Use Pydantic's model_validate for automatic type conversion
            return KafkaPersonDetectionEvent.model_validate(data)

        except ValidationError as e:
            logger.error(f"Validation error parsing event: {e}")
            self._error_count += 1
            return None
        except Exception as e:
            logger.error(f"Error parsing event: {e}")
            self._error_count += 1
            return None

    async def consume(self) -> AsyncGenerator[KafkaPersonDetectionEvent, None]:
        """
        Consume messages from Kafka topic.

        Yields
        ------
        KafkaPersonDetectionEvent
            Parsed person detection events.

        Raises
        ------
        RuntimeError
            If consumer has not been started.
        KafkaError
            If Kafka communication fails.
        """
        if self._consumer is None:
            raise RuntimeError("Consumer not started. Call start() first.")

        logger.info(f"Starting to consume from {self._topic}")

        try:
            async for message in self._consumer:
                if not self._running:
                    break

                self._message_count += 1

                if message.value:
                    event = self._parse_event(message.value)
                    if event:
                        yield event

        except KafkaError as e:
            logger.error(f"Kafka error during consumption: {e}")
            self._error_count += 1
            raise

    async def consume_batch(
            self,
            max_records: int = 100,
            timeout_ms: int = 1000
    ) -> List[KafkaPersonDetectionEvent]:
        """
        Consume a batch of messages.

        Parameters
        ----------
        max_records : int, default=100
            Maximum records to fetch in this batch.
        timeout_ms : int, default=1000
            Timeout in milliseconds to wait for messages.

        Returns
        -------
        List[KafkaPersonDetectionEvent]
            List of parsed events. May be empty if no messages available.

        Raises
        ------
        RuntimeError
            If consumer has not been started.
        """
        if self._consumer is None:
            raise RuntimeError("Consumer not started. Call start() first.")

        events = []

        try:
            data = await self._consumer.getmany(
                timeout_ms=timeout_ms,
                max_records=max_records
            )

            for topic_partition, messages in data.items():
                for message in messages:
                    self._message_count += 1
                    if message.value:
                        event = self._parse_event(message.value)
                        if event:
                            events.append(event)

        except KafkaError as e:
            logger.error(f"Kafka error during batch consumption: {e}")
            self._error_count += 1

        return events

    async def consume_with_callback(
            self,
            callback: Callable[[KafkaPersonDetectionEvent], Awaitable[None]]
    ) -> None:
        """
        Consume messages and process with callback.

        Parameters
        ----------
        callback : Callable[[KafkaPersonDetectionEvent], Awaitable[None]]
            Async function to process each event.

        Notes
        -----
        Errors in the callback are logged but do not stop consumption.
        """
        async for event in self.consume():
            try:
                await callback(event)
            except Exception as e:
                logger.error(f"Error in callback: {e}")
                self._error_count += 1

    @property
    def is_running(self) -> bool:
        """
        Check if consumer is running.

        Returns
        -------
        bool
            True if consumer is running.
        """
        return self._running

    @property
    def message_count(self) -> int:
        """
        Get total message count.

        Returns
        -------
        int
            Total messages consumed.
        """
        return self._message_count

    @property
    def error_count(self) -> int:
        """
        Get error count.

        Returns
        -------
        int
            Total errors encountered.
        """
        return self._error_count

    def get_stats(self) -> ConsumerStats:
        """
        Get consumer statistics.

        Returns
        -------
        ConsumerStats
            Current consumer statistics.
        """
        return ConsumerStats(
            running=self._running,
            message_count=self._message_count,
            error_count=self._error_count,
            topic=self._topic,
            group_id=self._group_id,
        )
