"""
Constants for Analytics Service.

This module contains constant values and default configurations
used throughout the application.

All constants are defined as Final class attributes to prevent
accidental modification.
"""

from typing import Final, List
from .enums import LogLevel


class Constants:
    """
    Constants class containing all constant values and defaults.

    This class provides centralized access to constant values
    used throughout the dwell analytics service.

    Notes
    -----
    All attributes are marked as Final to indicate they should not be modified.
    """

    # Config File
    CONFIG_FILE_NAME: Final[str] = "config.yaml"

    # Kafka Topics
    DEFAULT_INPUT_KAFKA_TOPIC: Final[str] = "video.insights.person"
    DEFAULT_OUTPUT_KAFKA_TOPIC: Final[str] = "video.insights.person.output"

    # Default Kafka Configuration
    DEFAULT_BOOTSTRAP_SERVERS: Final[str] = "localhost:9092"
    DEFAULT_CONSUMER_GROUP_ID: Final[str] = "engagement-analytics-group"
    DEFAULT_AUTO_OFFSET_RESET: Final[str] = "latest"
    ENABLE_AUTO_COMMIT: Final[bool] = True
    MAX_POLL_INTERVAL_MS: Final[int] = 300000  # 5 minutes
    SESSION_TIMEOUT_MS: Final[int] = 30000  # 30 seconds (increased for YOLO processing)
    HEARTBEAT_INTERVAL_MS: Final[int] = 9000  # 9 seconds (must be < 1/3 of session timeout)
    DEFAULT_ACKS: Final[str] = "all"
    DEFAULT_RETRIES: Final[int] = 3
    DEFAULT_RETRY_BACKOFF_MS: Final[int] = 100
    DEFAULT_LINGER_MS: Final[int] = 5
    DEFAULT_PRODUCER_BATCH_SIZE: Final[int] = 16384

    # Logging Defaults
    DEFAULT_LOG_LEVEL: Final[LogLevel] = LogLevel.ERROR
    DEFAULT_LOG_FILE: Final[str] = "logs/engagement_analytics_{time:YYYY-MM-DD}.log"

    # Validation Constants
    MIN_CONFIDENCE_THRESHOLD: Final[float] = 0.0
    MAX_CONFIDENCE_THRESHOLD: Final[float] = 1.0
    MIN_BBOX_COORDINATES: Final[float] = 0.0


    # Enagegement Defaults
    MinEngagementDuration: Final[float] = 0.5
    # Number of frames to wait before considering engagement ended (handles tracking gaps)
    EngagementGraceFrames: Final[int] = 3

    # Engagement / talking detection numeric defaults (moved from config.yaml)
    DEFAULT_IOU_THRESHOLD: Final[float] = 0.3
    DEFAULT_MIN_TALKING_DISTANCE_RATIO: Final[float] = 0.3
    DEFAULT_MAX_TALKING_DISTANCE_RATIO: Final[float] = 2.0
    DEFAULT_MIN_TALKING_SEPARATION_RATIO: Final[float] = 0.05
    DEFAULT_MIN_ASPECT_RATIO: Final[float] = 1.2
    DEFAULT_MAX_VERTICAL_DIFF_RATIO: Final[float] = 1.5
    DEFAULT_MIN_HORIZONTAL_DIFF_RATIO: Final[float] = 0.5
    DEFAULT_MAX_HORIZONTAL_DIFF_RATIO: Final[float] = 3.0

    # Default model class ids (moved from config.yaml)
    DEFAULT_PERSON_CLASS_ID: Final[int] = 0
    DEFAULT_OBJECT_CLASSES: Final[List[int]] = [
        24,  # backpack
        26,  # handbag
        28,  # suitcase
        39,  # bottle
        41,  # cup
        42,  # fork
        43,  # knife
        44,  # spoon
        46,  # bowl
        47,  # banana
        62,  # chair
        63,  # couch
        64,  # potted plant
        65,  # bed
        66,  # dining table
        67,  # toilet
        73,  # book
        74,  # clock
        75,  # vase
        76,  # scissors
        77,  # teddy bear
        78,  # hair drier
    ]
