"""
Statistics Pydantic models for Analytics Service.

This module contains models for various statistics returned
by services and processors for monitoring and debugging.
"""

from pydantic import Field

from .base_app_model import BaseAppModel


class ProducerStats(BaseAppModel):
    """
    Statistics for Kafka producer.

    Attributes
    ----------
    running : bool
        Whether producer is currently running.
    message_count : int
        Total messages successfully published.
    error_count : int
        Total publish errors encountered.
    topic : str
        Output topic name.
    """

    running: bool = Field(..., description="Whether producer is running")
    message_count: int = Field(default=0, ge=0, description="Total messages published")
    error_count: int = Field(default=0, ge=0, description="Total errors encountered")
    topic: str = Field(..., description="Output topic name")


class ConsumerStats(BaseAppModel):
    """
    Statistics for Kafka consumer.

    Attributes
    ----------
    running : bool
        Whether consumer is currently running.
    message_count : int
        Total messages consumed.
    error_count : int
        Total consumption/parsing errors.
    topic : str
        Input topic name.
    group_id : str
        Consumer group identifier.
    """

    running: bool = Field(..., description="Whether consumer is running")
    message_count: int = Field(default=0, ge=0, description="Total messages consumed")
    error_count: int = Field(default=0, ge=0, description="Total errors encountered")
    topic: str = Field(..., description="Input topic name")
    group_id: str = Field(..., description="Consumer group ID")
