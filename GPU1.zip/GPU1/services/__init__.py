"""
Services for Analytics Service.

This package contains service classes for Kafka communication
and analyrics event servic

Modules
-------
kafka_consumer
    Async Kafka consumer for person detection events.
kafka_producer
    Async Kafka producer for dwell events.
kafka_admin
    Kafka topic management utilities.
"""

from .kafka_admin import KafkaAdminService, ensure_topics_exist
from .kafka_consumer import KafkaConsumerService
from .kafka_producer import KafkaProducerService

__all__ = [
    "KafkaConsumerService",
    "KafkaProducerService",
    "KafkaAdminService",
    "ensure_topics_exist",
]
