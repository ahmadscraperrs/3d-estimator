"""
Utilities for Analytics Service.

This package contains utility functions and logging configuration.

Modules
-------
helpers
    Singleton helper class with utility functions.
logger
    Loguru-based logging configuration.

Examples
--------
>>> from utils import helpers, logger
>>> track_key = helpers.generate_track_key("camera-1", 123)
>>> logger.info("Processing started")
"""

from .helpers import helpers
from .logger import logger, setup_logger, get_logger

__all__ = [
    "helpers",
    "logger",
    "setup_logger",
    "get_logger",
]
