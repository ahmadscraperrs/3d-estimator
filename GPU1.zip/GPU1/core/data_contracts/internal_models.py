"""
Internal Pydantic models for Analytics processing.

This module contains models used internally within the project

These models are not directly serialized to Kafka but are used
for state management within the tracker.
"""
from datetime import datetime
from typing import Optional, List, Dict

from pydantic import Field

from .base_app_model import BaseAppModel
from .common_models import BoundingBox
from .common_models import Region
from ..enums import IntersectionType, TargetCategory, ServiceType, InteractionType, ContactRegion


def _default_class_mapping() -> Dict[str, TargetCategory]:
    """Default class mapping dictionary to TargetCategory enum."""
    return {
        # Person
        'person': TargetCategory.PERSON, 'people': TargetCategory.PERSON,
        
        # Shelf/Storage
        'shelf': TargetCategory.SHELF, 'shelves': TargetCategory.SHELF, 
        'bookcase': TargetCategory.SHELF, 'cabinet': TargetCategory.SHELF,
        'rack': TargetCategory.SHELF, 'racks': TargetCategory.SHELF,
        
        # Table/Furniture
        'desk': TargetCategory.TABLE_ITEM, 'workstation': TargetCategory.TABLE_ITEM,
        'table': TargetCategory.TABLE_ITEM, 'dining table': TargetCategory.TABLE_ITEM,
        'booth': TargetCategory.TABLE_ITEM,
        'chair': TargetCategory.TABLE_ITEM,
        'couch': TargetCategory.TABLE_ITEM, 'sofa': TargetCategory.TABLE_ITEM,

        
        # Vehicles
        'car': TargetCategory.VEHICLE, 'truck': TargetCategory.VEHICLE, 
        'bus': TargetCategory.VEHICLE, 'bicycle': TargetCategory.VEHICLE,
        'motorcycle': TargetCategory.VEHICLE, 'airplane': TargetCategory.VEHICLE,
        'boat': TargetCategory.VEHICLE, 'train': TargetCategory.VEHICLE,
        
        # Shelf Items (small objects typically on shelves)
        'bottle': TargetCategory.SHELF_ITEM, 'cup': TargetCategory.SHELF_ITEM, 
        'bowl': TargetCategory.SHELF_ITEM, 'box': TargetCategory.SHELF_ITEM,
        'bag': TargetCategory.SHELF_ITEM, 'backpack': TargetCategory.SHELF_ITEM, 
        'handbag': TargetCategory.SHELF_ITEM, 'suitcase': TargetCategory.SHELF_ITEM,
        'book': TargetCategory.SHELF_ITEM, 'toy': TargetCategory.SHELF_ITEM,
        'teddy bear': TargetCategory.SHELF_ITEM,
        'vase': TargetCategory.SHELF_ITEM, 'clock': TargetCategory.SHELF_ITEM,
        'scissors': TargetCategory.SHELF_ITEM, 'hair drier': TargetCategory.SHELF_ITEM,
        'toothbrush': TargetCategory.SHELF_ITEM,
        'potted plant': TargetCategory.SHELF_ITEM,
        
        # Electronics
        'laptop': TargetCategory.ELECTRONICS, 'mouse': TargetCategory.ELECTRONICS, 
        'keyboard': TargetCategory.ELECTRONICS, 'cell phone': TargetCategory.ELECTRONICS,
        'tv': TargetCategory.ELECTRONICS, 'remote': TargetCategory.ELECTRONICS,
           
        # Other
        'bench': TargetCategory.TABLE_ITEM,
    }


class Detection(BaseAppModel):
    """
    Single person detection with bounding box and tracking info.

    Attributes
    ----------
    bbox : List[float]
        Bounding box coordinates as [x1, y1, x2, y2].
    confidence : float
        Detection confidence score between 0 and 1.
    tracking_id : int, optional
        Unique tracking ID assigned by the tracker.
    region : Region, optional
      Region where detection occurred.

    Examples
    --------
    >>> detection = Detection(
    ...     bbox=[100.0, 200.0, 300.0, 400.0],
    ...     confidence=0.95,
    ...     tracking_id=42
    ... )
    """

    bbox: List[float] = Field(..., description="Bounding box as [x1, y1, x2, y2]")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Detection confidence score")
    tracking_id: Optional[int] = Field(
        None,
        description="Tracking ID from tracker",
        alias="track_id"  # Handle common variation
    )
    region: Optional[Region] = Field(None, description="Region where detection occurred")


class ObjectDetection(BaseAppModel):
    """
    Single object detection from YOLO with bounding box and category info.

    Attributes
    ----------
    bbox : BoundingBox
        Bounding box with top_left, bottom_right, and center points.
    confidence : float
        Detection confidence score between 0 and 1.
    tracking_id : int
        Tracking ID assigned by the tracker or hash.
    class_id : int
        YOLO class ID.
    class_name : str
        Raw YOLO class name (e.g., 'bottle', 'chair').
    target_category : TargetCategory
        Mapped TargetCategory enum value.

    Examples
    --------
    >>> obj = ObjectDetection(
    ...     bbox=BoundingBox.from_list([100.0, 200.0, 300.0, 400.0]),
    ...     confidence=0.85,
    ...     tracking_id=123,
    ...     class_id=39,
    ...     class_name='bottle',
    ...     target_category=TargetCategory.SHELF_ITEM
    ... )
    >>> obj.info
    {'class_name': 'bottle', 'target_category': 'SHELF_ITEM'}
    """

    bbox: BoundingBox = Field(..., description="Bounding box with top_left, bottom_right, center")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Detection confidence score")
    tracking_id: int = Field(..., description="Tracking ID from tracker or hash")
    class_id: int = Field(..., description="YOLO class ID")
    class_name: str = Field(..., description="Raw YOLO class name")
    target_category: TargetCategory = Field(
        default=TargetCategory.UNKNOWN,
        description="Mapped TargetCategory enum value"
    )

    @property
    def info(self) -> Dict[str, str]:
        """
        Get summary info with class_name and target_category.
        
        Returns
        -------
        Dict[str, str]
            Dictionary with class_name and target_category.
        """
        return {
            'class_name': self.class_name,
            'target_category': self.target_category.value if hasattr(self.target_category, 'value') else str(self.target_category)
        }

    @property
    def bbox_list(self) -> List[float]:
        """
        Get bbox as list [x1, y1, x2, y2] for compatibility.
        
        Returns
        -------
        List[float]
            Bounding box as [x1, y1, x2, y2].
        """
        return [
            self.bbox.top_left.x,
            self.bbox.top_left.y,
            self.bbox.bottom_right.x,
            self.bbox.bottom_right.y
        ]


class Interaction(BaseAppModel):
    """
    Interaction between a person and target (object or another person).
    
    Supports both legacy IoU-based detection and new HOI depth-aware detection.
    """
    visitor_bbox: BoundingBox = Field(..., description="Visitor bounding box as [x1, y1, x2, y2]")
    target_bbox: BoundingBox = Field(..., description="Target bounding box as [x1, y1, x2, y2]")
    target_category: TargetCategory = Field(default=TargetCategory.UNKNOWN, description="Type of target")
    # Legacy engagement metrics (IoU-based)
    intersection_types: List[IntersectionType] = Field(
        default_factory=list,
        description="Type of intersection (legacy)"
    )
    start_time: datetime = Field(..., description="Event timestamp from the video source")
    end_time: datetime = Field(..., description="Event timestamp from the video source")
    
    # HOI-specific fields (depth-aware detection)
    interaction_type: Optional[InteractionType] = Field(
        None,
        description="HOI interaction type (HOLDING, TOUCHING, USING, NEAR, TALKING, etc.)"
    )
    depth_distance: Optional[float] = Field(
        None,
        description="Depth distance between person and target in relative units"
    )
    contact_region: Optional[ContactRegion] = Field(
        None,
        description="Body region involved in the interaction"
    )
    confidence: Optional[float] = Field(
        None,
        ge=0.0,
        le=1.0,
        description="Confidence score for the interaction"
    )


class ActiveEngagement(BaseAppModel):
    """
    Tracks an active engagement between a visitor and target.
    
    Used internally to track ongoing engagements and detect transitions.
    """
    camera_id: str = Field(..., description="Camera ID where engagement is detected")
    start_time: datetime = Field(..., description="When the engagement started")
    last_seen: datetime = Field(..., description="Last time engagement was detected")
    visitor_bbox: BoundingBox = Field(..., description="Visitor bounding box")
    target_bbox: BoundingBox = Field(..., description="Target bounding box")
    target_category: TargetCategory = Field(default=TargetCategory.UNKNOWN, description="Type of target")
    engagement_type: str = Field(..., description="Type of engagement (talking, physical_touch, etc.)")
    services: List[ServiceType] = Field(default_factory=list, description="Enabled services")
    region: Optional[Region] = Field(None, description="Region where engagement occurred")


class ClassNameMapper(BaseAppModel):
    """
    Maps YOLO class names to TargetCategory enum values.
    
    This Pydantic model provides a centralized way to map raw YOLO detection class names
    to TargetCategory enum values used in engagement detection.
    
    Attributes
    ----------
    class_mapping : Dict[str, TargetCategory]
        Dictionary mapping YOLO class names to TargetCategory enum values.
    
    Examples
    --------
    >>> mapper = ClassNameMapper()
    >>> mapper.map('bottle')
    <TargetCategory.SHELF_ITEM: 'SHELF_ITEM'>
    >>> mapper.map('person')
    <TargetCategory.PERSON: 'PERSON'>
    >>> mapper.map('unknown_class')
    <TargetCategory.UNKNOWN: 'UNKNOWN'>
    """
    
    class_mapping: Dict[str, TargetCategory] = Field(
        default_factory=_default_class_mapping,
        description="Dictionary mapping YOLO class names to TargetCategory enum values"
    )
    
    def map(self, class_name: str) -> TargetCategory:
        """
        Map YOLO class name to TargetCategory enum value.
        
        Parameters
        ----------
        class_name : str
            Raw YOLO class name (e.g., 'bottle', 'person', 'laptop')
        
        Returns
        -------
        TargetCategory
            Mapped TargetCategory enum value (e.g., TargetCategory.SHELF_ITEM, TargetCategory.PERSON)
        
        Examples
        --------
        >>> mapper = ClassNameMapper()
        >>> mapper.map('bottle')
        <TargetCategory.SHELF_ITEM: 'SHELF_ITEM'>
        >>> mapper.map('person')
        <TargetCategory.PERSON: 'PERSON'>
        >>> mapper.map('unknown_class')
        <TargetCategory.UNKNOWN: 'UNKNOWN'>
        """
        class_name_lower = class_name.lower()
        
        # Check direct mapping first
        if class_name_lower in self.class_mapping:
            return self.class_mapping[class_name_lower]
        
        # Check partial matches
        if 'desk' in class_name_lower or 'workstation' in class_name_lower:
            return TargetCategory.TABLE_ITEM
        if 'booth' in class_name_lower:
            return TargetCategory.TABLE_ITEM
        if 'rack' in class_name_lower:
            return TargetCategory.SHELF
        if 'shelf' in class_name_lower or 'cabinet' in class_name_lower:
            return TargetCategory.SHELF
        if 'table' in class_name_lower:
            return TargetCategory.TABLE_ITEM
        if 'laptop' in class_name_lower or 'mouse' in class_name_lower or 'keyboard' in class_name_lower or 'phone' in class_name_lower:
            return TargetCategory.ELECTRONICS
        if 'car' in class_name_lower or 'truck' in class_name_lower or 'bus' in class_name_lower or 'bicycle' in class_name_lower:
            return TargetCategory.VEHICLE
        
        # Default: return UNKNOWN
        return TargetCategory.UNKNOWN