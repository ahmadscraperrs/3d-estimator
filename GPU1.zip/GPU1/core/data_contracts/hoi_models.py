"""
Human-Object Interaction (HOI) Pydantic models.

This module contains models for depth-aware HOI detection,
replacing the traditional IoU-based engagement detection.

Models support both simplified depth-aware detection and
full LEMON pipeline integration.
"""
from datetime import datetime
from typing import Optional, List, Dict, Any

import numpy as np
from pydantic import Field, computed_field

from .base_app_model import BaseAppModel
from .common_models import BoundingBox, Point
from ..enums import InteractionType, ContactRegion, TargetCategory


class DepthInfo(BaseAppModel):
    """
    Depth information for a detected entity.

    Attributes
    ----------
    mean_depth : float
        Mean depth value within the bounding box (relative units).
    min_depth : float
        Minimum depth value (closest point).
    max_depth : float
        Maximum depth value (farthest point).
    center_depth : float
        Depth value at the center of the bounding box.
    depth_variance : float
        Variance of depth values (indicates flatness/3D extent).
    """

    mean_depth: float = Field(..., description="Mean depth within bounding box")
    min_depth: float = Field(..., description="Minimum depth (closest point)")
    max_depth: float = Field(..., description="Maximum depth (farthest point)")
    center_depth: float = Field(..., description="Depth at bbox center")
    depth_variance: float = Field(0.0, description="Depth variance within bbox")

    @computed_field
    @property
    def depth_range(self) -> float:
        """Calculate the depth range (max - min)."""
        return self.max_depth - self.min_depth


class DetectionWithDepth(BaseAppModel):
    """
    Detection result enriched with depth information.

    Combines 2D bounding box detection with depth estimation.
    """

    tracking_id: int = Field(..., description="Tracking ID from detector")
    bbox: BoundingBox = Field(..., description="2D bounding box")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Detection confidence")
    class_name: str = Field(..., description="Detected class name")
    target_category: TargetCategory = Field(
        default=TargetCategory.UNKNOWN,
        description="Mapped target category"
    )
    depth_info: Optional[DepthInfo] = Field(
        None,
        description="Depth information for this detection"
    )

    @property
    def has_depth(self) -> bool:
        """Check if depth information is available."""
        return self.depth_info is not None

    @property
    def primary_depth(self) -> float:
        """Get primary depth value (center_depth if available, else 0)."""
        if self.depth_info:
            return self.depth_info.center_depth
        return 0.0


class HOInteraction(BaseAppModel):
    """
    Human-Object Interaction detection result.

    Represents a detected interaction between a person and an object
    or between two people, with depth-aware analysis.

    Attributes
    ----------
    person_id : str
        Unique identifier for the person involved.
    target_id : str, optional
        Unique identifier for the target (object or another person).
    interaction_type : InteractionType
        Type of interaction detected (HOLDING, TOUCHING, USING, etc.).
    confidence : float
        Confidence score for this interaction (0.0 to 1.0).
    depth_distance : float
        Depth distance between person and target in relative units.
    spatial_distance : float
        2D spatial distance between centers.
    contact_region : ContactRegion, optional
        Body region involved in the interaction.
    person_bbox : BoundingBox
        Bounding box of the person.
    target_bbox : BoundingBox, optional
        Bounding box of the target.
    target_category : TargetCategory
        Category of the target (PERSON, SHELF, ELECTRONICS, etc.).
    start_time : datetime
        When the interaction started.
    end_time : datetime, optional
        When the interaction ended (None if ongoing).
    """

    person_id: str = Field(..., description="Person tracking ID")
    target_id: Optional[str] = Field(None, description="Target tracking ID")
    interaction_type: InteractionType = Field(
        default=InteractionType.UNKNOWN,
        description="Type of HOI interaction"
    )
    confidence: float = Field(..., ge=0.0, le=1.0, description="Interaction confidence")
    depth_distance: float = Field(
        0.0,
        description="Depth distance between person and target"
    )
    spatial_distance: float = Field(
        0.0,
        description="2D spatial distance between centers"
    )
    contact_region: ContactRegion = Field(
        default=ContactRegion.UNKNOWN,
        description="Body region in contact"
    )
    person_bbox: BoundingBox = Field(..., description="Person bounding box")
    target_bbox: Optional[BoundingBox] = Field(None, description="Target bounding box")
    target_category: TargetCategory = Field(
        default=TargetCategory.UNKNOWN,
        description="Target category"
    )
    start_time: datetime = Field(..., description="Interaction start time")
    end_time: Optional[datetime] = Field(None, description="Interaction end time")

    @computed_field
    @property
    def duration_seconds(self) -> Optional[float]:
        """Calculate interaction duration in seconds."""
        if self.end_time and self.start_time:
            return (self.end_time - self.start_time).total_seconds()
        return None

    @computed_field
    @property
    def is_person_interaction(self) -> bool:
        """Check if this is a person-to-person interaction."""
        return self.target_category == TargetCategory.PERSON

    @computed_field
    @property
    def is_active(self) -> bool:
        """Check if interaction is still active (no end_time)."""
        return self.end_time is None


class ActiveHOInteraction(BaseAppModel):
    """
    Tracks an active (ongoing) HOI interaction.

    Used internally for state management during real-time detection.
    """

    camera_id: str = Field(..., description="Camera ID")
    person_id: str = Field(..., description="Person tracking ID")
    target_id: Optional[str] = Field(None, description="Target tracking ID")
    interaction_type: InteractionType = Field(..., description="Interaction type")
    target_category: TargetCategory = Field(..., description="Target category")
    confidence: float = Field(..., description="Current confidence score")
    depth_distance: float = Field(0.0, description="Current depth distance")
    contact_region: ContactRegion = Field(
        default=ContactRegion.UNKNOWN,
        description="Contact region"
    )
    person_bbox: BoundingBox = Field(..., description="Last person bbox")
    target_bbox: Optional[BoundingBox] = Field(None, description="Last target bbox")
    start_time: datetime = Field(..., description="Start time")
    last_seen: datetime = Field(..., description="Last detection time")
    frame_count: int = Field(1, description="Number of frames detected")

    def to_hoi_interaction(self) -> HOInteraction:
        """Convert to completed HOInteraction with end_time."""
        return HOInteraction(
            person_id=self.person_id,
            target_id=self.target_id,
            interaction_type=self.interaction_type,
            confidence=self.confidence,
            depth_distance=self.depth_distance,
            spatial_distance=0.0,  # Can be calculated if needed
            contact_region=self.contact_region,
            person_bbox=self.person_bbox,
            target_bbox=self.target_bbox,
            target_category=self.target_category,
            start_time=self.start_time,
            end_time=self.last_seen,
        )


class DepthMap(BaseAppModel):
    """
    Wrapper for depth estimation results.

    Note: The actual numpy array is not serialized to JSON.
    """

    width: int = Field(..., description="Depth map width")
    height: int = Field(..., description="Depth map height")
    min_depth: float = Field(..., description="Minimum depth value")
    max_depth: float = Field(..., description="Maximum depth value")
    mean_depth: float = Field(..., description="Mean depth value")
    # Actual depth data stored but not serialized
    _depth_array: Optional[np.ndarray] = None

    def set_depth_array(self, arr: np.ndarray) -> None:
        """Set the depth array (not serialized)."""
        self._depth_array = arr

    def get_depth_array(self) -> Optional[np.ndarray]:
        """Get the depth array."""
        return self._depth_array

    def get_depth_at(self, x: int, y: int) -> float:
        """Get depth value at a specific pixel."""
        if self._depth_array is None:
            return 0.0
        if 0 <= y < self.height and 0 <= x < self.width:
            return float(self._depth_array[y, x])
        return 0.0

    def get_depth_in_bbox(self, bbox: BoundingBox) -> DepthInfo:
        """Extract depth information within a bounding box."""
        if self._depth_array is None:
            return DepthInfo(
                mean_depth=0.0,
                min_depth=0.0,
                max_depth=0.0,
                center_depth=0.0,
                depth_variance=0.0
            )

        x1 = max(0, int(bbox.top_left.x))
        y1 = max(0, int(bbox.top_left.y))
        x2 = min(self.width, int(bbox.bottom_right.x))
        y2 = min(self.height, int(bbox.bottom_right.y))

        if x2 <= x1 or y2 <= y1:
            return DepthInfo(
                mean_depth=0.0,
                min_depth=0.0,
                max_depth=0.0,
                center_depth=0.0,
                depth_variance=0.0
            )

        region = self._depth_array[y1:y2, x1:x2]
        center_x = int(bbox.center.x)
        center_y = int(bbox.center.y)
        center_depth = self.get_depth_at(center_x, center_y)

        return DepthInfo(
            mean_depth=float(np.mean(region)),
            min_depth=float(np.min(region)),
            max_depth=float(np.max(region)),
            center_depth=center_depth,
            depth_variance=float(np.var(region))
        )


class HOIDetectionResult(BaseAppModel):
    """
    Complete result from HOI detection pipeline.

    Contains all detected interactions for a single frame.
    """

    camera_id: str = Field(..., description="Camera ID")
    frame_number: int = Field(..., description="Frame number")
    timestamp: datetime = Field(..., description="Frame timestamp")
    interactions: List[HOInteraction] = Field(
        default_factory=list,
        description="Detected interactions"
    )
    depth_map_info: Optional[DepthMap] = Field(
        None,
        description="Depth map metadata (array not included)"
    )
    processing_time_ms: float = Field(0.0, description="Processing time in ms")

    @computed_field
    @property
    def interaction_count(self) -> int:
        """Total number of interactions detected."""
        return len(self.interactions)

    @computed_field
    @property
    def person_interactions(self) -> List[HOInteraction]:
        """Filter person-to-person interactions."""
        return [i for i in self.interactions if i.is_person_interaction]

    @computed_field
    @property
    def object_interactions(self) -> List[HOInteraction]:
        """Filter person-to-object interactions."""
        return [i for i in self.interactions if not i.is_person_interaction]
