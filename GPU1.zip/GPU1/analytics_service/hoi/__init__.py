"""
Human-Object Interaction (HOI) detection module.

This package provides depth-aware HOI detection, replacing
traditional IoU-based engagement detection with more accurate
spatial and depth analysis.

Modules
-------
hoi_detector
    Main HOI detection orchestrator.
interaction_classifier
    Depth-aware interaction classification logic.
motion_tracker
    Temporal motion tracking for dynamic interactions.
"""
from .hoi_detector import HOIDetector
from .interaction_classifier import InteractionClassifier
from .motion_tracker import MotionTracker, MotionState, PositionState

__all__ = [
    "HOIDetector",
    "InteractionClassifier",
    "MotionTracker",
    "MotionState",
    "PositionState",
]
