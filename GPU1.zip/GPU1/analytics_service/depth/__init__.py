"""
Depth estimation module for HOI detection.

This package provides depth estimation using Depth Anything v2
for depth-aware human-object interaction detection.

Modules
-------
depth_estimator
    Depth Anything v2 wrapper for monocular depth estimation.
"""
from .depth_estimator import DepthEstimator

__all__ = [
    "DepthEstimator",
]
