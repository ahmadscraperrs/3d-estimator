"""
Depth Anything v2 wrapper for monocular depth estimation.

This module provides a wrapper class for Depth Anything v2 model
to estimate depth from single RGB images for HOI detection.

Supports multiple model variants (small, base, large) and both
relative and metric depth estimation modes.
"""
import time
from typing import Optional, Tuple, Literal

import cv2
import numpy as np
import torch

from core.data_contracts import DepthMap, DepthInfo, BoundingBox
from utils import logger


# Model configurations for different variants
MODEL_CONFIGS = {
    "small": {
        "encoder": "vits",
        "features": 64,
        "out_channels": [48, 96, 192, 384],
    },
    "base": {
        "encoder": "vitb",
        "features": 128,
        "out_channels": [96, 192, 384, 768],
    },
    "large": {
        "encoder": "vitl",
        "features": 256,
        "out_channels": [256, 512, 1024, 1024],
    },
}


class DepthEstimator:
    """
    Depth Anything v2 wrapper for monocular depth estimation.

    Provides depth estimation from RGB images using the Depth Anything v2
    model. Supports different model sizes for speed/quality tradeoff.

    Attributes
    ----------
    variant : str
        Model variant ('small', 'base', 'large').
    device : str
        Device to run inference on ('cuda', 'cpu', 'auto').
    max_depth : float
        Maximum depth value for metric depth (default 20.0 meters).
    model : DepthAnythingV2
        Loaded depth estimation model.

    Examples
    --------
    >>> estimator = DepthEstimator(variant="small", device="cuda")
    >>> depth_map = estimator.estimate(frame)
    >>> depth_info = depth_map.get_depth_in_bbox(bbox)
    """

    def __init__(
        self,
        variant: Literal["small", "base", "large"] = "small",
        device: str = "auto",
        max_depth: float = 20.0,
        checkpoint_path: Optional[str] = None,
    ) -> None:
        """
        Initialize the depth estimator.

        Parameters
        ----------
        variant : str, optional
            Model variant to use. Options: 'small', 'base', 'large'.
            Default is 'small' for fastest inference.
        device : str, optional
            Device for inference. 'auto' selects CUDA if available.
        max_depth : float, optional
            Maximum depth value for metric depth mode (meters).
        checkpoint_path : str, optional
            Custom path to model checkpoint. If None, uses default.
        """
        self.variant = variant
        self.max_depth = max_depth
        self._checkpoint_path = checkpoint_path
        self._model = None
        self._device = None
        self._initialized = False

        # Determine device
        if device == "auto":
            self._device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self._device = torch.device(device)

        logger.info(f"DepthEstimator initialized with variant={variant}, device={self._device}")

    def _lazy_load_model(self) -> None:
        """
        Lazily load the model on first use.

        This allows the estimator to be created without loading
        the heavy model until actually needed.
        """
        if self._initialized:
            return

        try:
            # Try to import Depth Anything v2
            from depth_anything_v2.dpt import DepthAnythingV2
        except ImportError:
            logger.warning(
                "depth_anything_v2 not installed. "
                "Install with: pip install depth-anything-v2 "
                "or: pip install git+https://github.com/DepthAnything/Depth-Anything-V2.git"
            )
            # Try alternative import from transformers
            try:
                from transformers import pipeline
                self._use_transformers = True
                model_name = f"depth-anything/Depth-Anything-V2-{self.variant.capitalize()}-hf"
                self._model = pipeline(
                    task="depth-estimation",
                    model=model_name,
                    device=0 if str(self._device) == "cuda" else -1
                )
                logger.info(f"Using transformers pipeline for depth estimation: {model_name}")
                self._initialized = True
                return
            except Exception as e:
                logger.error(f"Failed to load depth model via transformers: {e}")
                self._model = None
                self._initialized = True
                return

        self._use_transformers = False

        # Get model config
        if self.variant not in MODEL_CONFIGS:
            logger.warning(f"Unknown variant {self.variant}, defaulting to 'small'")
            self.variant = "small"

        config = MODEL_CONFIGS[self.variant]

        try:
            # Initialize model
            self._model = DepthAnythingV2(
                encoder=config["encoder"],
                features=config["features"],
                out_channels=config["out_channels"],
            )

            # Load checkpoint
            if self._checkpoint_path:
                ckpt_path = self._checkpoint_path
            else:
                # Default checkpoint path
                ckpt_path = f"checkpoints/depth_anything_v2_{config['encoder']}.pth"

            try:
                state_dict = torch.load(ckpt_path, map_location=self._device)
                self._model.load_state_dict(state_dict)
                logger.info(f"Loaded depth model checkpoint from {ckpt_path}")
            except FileNotFoundError:
                logger.warning(
                    f"Checkpoint not found at {ckpt_path}. "
                    "Model will use random weights. "
                    "Download from: https://github.com/DepthAnything/Depth-Anything-V2"
                )

            self._model.to(self._device)
            self._model.eval()
            logger.info(f"Depth model loaded on {self._device}")

        except Exception as e:
            logger.error(f"Failed to initialize depth model: {e}")
            self._model = None

        self._initialized = True

    def estimate(self, frame: np.ndarray) -> DepthMap:
        """
        Estimate depth from an RGB frame.

        Parameters
        ----------
        frame : np.ndarray
            Input RGB image (H, W, 3) in BGR format (OpenCV).

        Returns
        -------
        DepthMap
            Depth estimation result with metadata and depth array.
        """
        self._lazy_load_model()

        if self._model is None:
            # Return dummy depth map if model not available
            h, w = frame.shape[:2]
            return self._create_dummy_depth_map(w, h)

        start_time = time.time()

        try:
            if self._use_transformers:
                # Use transformers pipeline
                from PIL import Image
                # Convert BGR to RGB
                rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                pil_image = Image.fromarray(rgb_frame)
                result = self._model(pil_image)
                depth_array = np.array(result["depth"])
                # Normalize to 0-1 range
                depth_array = depth_array.astype(np.float32)
                if depth_array.max() > 0:
                    depth_array = depth_array / depth_array.max()
            else:
                # Use native Depth Anything v2
                depth_array = self._model.infer_image(frame)

            # Create depth map result
            h, w = depth_array.shape[:2]
            depth_map = DepthMap(
                width=w,
                height=h,
                min_depth=float(np.min(depth_array)),
                max_depth=float(np.max(depth_array)),
                mean_depth=float(np.mean(depth_array)),
            )
            depth_map.set_depth_array(depth_array)

            elapsed = (time.time() - start_time) * 1000
            logger.debug(f"Depth estimation completed in {elapsed:.1f}ms")

            return depth_map

        except Exception as e:
            logger.error(f"Depth estimation failed: {e}")
            h, w = frame.shape[:2]
            return self._create_dummy_depth_map(w, h)

    def _create_dummy_depth_map(self, width: int, height: int) -> DepthMap:
        """Create a dummy depth map when model is not available."""
        dummy_array = np.ones((height, width), dtype=np.float32) * 0.5
        depth_map = DepthMap(
            width=width,
            height=height,
            min_depth=0.5,
            max_depth=0.5,
            mean_depth=0.5,
        )
        depth_map.set_depth_array(dummy_array)
        return depth_map

    def get_depth_for_detection(
        self,
        depth_map: DepthMap,
        bbox: BoundingBox
    ) -> DepthInfo:
        """
        Extract depth information for a detected object.

        Parameters
        ----------
        depth_map : DepthMap
            Depth estimation result.
        bbox : BoundingBox
            Bounding box of the detection.

        Returns
        -------
        DepthInfo
            Depth statistics within the bounding box.
        """
        return depth_map.get_depth_in_bbox(bbox)

    def compute_depth_distance(
        self,
        depth_info1: DepthInfo,
        depth_info2: DepthInfo
    ) -> float:
        """
        Compute depth distance between two detections.

        Uses center depth values to compute relative distance.

        Parameters
        ----------
        depth_info1 : DepthInfo
            Depth info for first detection.
        depth_info2 : DepthInfo
            Depth info for second detection.

        Returns
        -------
        float
            Absolute depth distance (relative units).
        """
        return abs(depth_info1.center_depth - depth_info2.center_depth)

    def are_at_similar_depth(
        self,
        depth_info1: DepthInfo,
        depth_info2: DepthInfo,
        threshold: float = 0.15
    ) -> bool:
        """
        Check if two detections are at similar depth.

        Parameters
        ----------
        depth_info1 : DepthInfo
            Depth info for first detection.
        depth_info2 : DepthInfo
            Depth info for second detection.
        threshold : float, optional
            Maximum depth difference threshold (default 0.15).

        Returns
        -------
        bool
            True if detections are within threshold depth distance.
        """
        distance = self.compute_depth_distance(depth_info1, depth_info2)
        return distance <= threshold

    @property
    def is_available(self) -> bool:
        """Check if depth estimation is available."""
        self._lazy_load_model()
        return self._model is not None

    @property
    def device(self) -> torch.device:
        """Get the device used for inference."""
        return self._device
