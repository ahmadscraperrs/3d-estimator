"""
Enums for Analytics Service.

This module contains enum definitions used throughout the application
for type-safe string values.

All enums inherit from StrEnum for string compatibility and serialization.
"""

from enum import StrEnum


class EventType(StrEnum):
    """
    Event type enumeration for detection and dwell events.

    Represents different types of events in the analytics system.

    Attributes
    ----------
    PERSON_DETECTION : str
        Person detected in frame.
    """

    # Kafka event types
    PERSON_DETECTION = "person.detection"
    PERSON_ENGAGEMENT = "person.engagement"


class LogLevel(StrEnum):
    """
    Logging Level available for monitoring.
    """
    TRACE = "TRACE"
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class FrameFormat(StrEnum):
    """
    Frame format enumeration for video frames.

    Represents different image formats for frame encoding.

    Attributes
    ----------
    JPEG : str
        JPEG image format.
    PNG : str
        PNG image format.
    """

    JPEG = "jpeg"
    PNG = "png"


class Compression(StrEnum):
    """
    Compression algorithm for frame data.

    Represents different compression algorithms used for
    encoding frame data in Kafka messages.

    Attributes
    ----------
    ZLIB : str
        Zlib compression.
    NONE : str
        No compression.
    GZIP : str
        Gzip compression.
    LZ4 : str
        LZ4 compression.
    """

    ZLIB = "zlib"
    NONE = "none"
    GZIP = "gzip"
    LZ4 = "lz4"


class CompressionType(StrEnum):
    """
    Compression type options for frame encoding.

    Represents different compression algorithm combinations
    available for encoding video frames.

    Attributes
    ----------
    JPEG : str
        JPEG compression only.
    WEBP : str
        WebP compression only.
    JPEG_ZLIB : str
        JPEG with additional zlib compression.
    WEBP_ZLIB : str
        WebP with additional zlib compression.
    """

    JPEG = "JPEG"
    WEBP = "WEBP"
    JPEG_ZLIB = "JPEG+ZLIB"
    WEBP_ZLIB = "WEBP+ZLIB"


class ServiceType(StrEnum):
    """
    Service types available for monitoring regions.

    Each service type represents a different analytics capability
    that can be enabled for a region.

    Attributes
    ----------
    ENTRY_EXIT : str
        Entry/exit counting service.
    ENGAGEMENT : str
        Engagement detection service.
    DWELL_TIME : str
        Dwell time tracking service.
    OCCUPANCY : str
        Occupancy counting service.
    """

    ENTRY_EXIT = "ENTRY/EXIT"
    ENGAGEMENT = "ENGAGEMENT"
    DWELL_TIME = "DWELL_TIME"
    OCCUPANCY = "OCCUPANCY"


class IntersectionType(StrEnum):
    """Type of intersection detected."""
    UNKNOWN = "UNKNOWN"
    TALKING = "TALKING"
    PHYSICAL = "PHYSICAL"
    OTHER = "OTHER"
    # New interaction categories
    OBJECT_MANIPULATION = "OBJECT_MANIPULATION"  # PICKING, DROPPING, PLACING, CARRYING
    GROUP_INTERACTION = "GROUP_INTERACTION"  # STANDING_TOGETHER, WALKING_TOGETHER, QUEUEING
    RETAIL_BEHAVIOR = "RETAIL_BEHAVIOR"  # BROWSING, WAITING, LOITERING
    POSTURE = "POSTURE"  # SITTING_ON, CROUCHING, BENDING


class TargetCategory(StrEnum):
    """Type of target in intersection."""
    UNKNOWN = "UNKNOWN"

    # People
    PERSON = "PERSON"
    GROUP = "GROUP"  # Multiple people together

    # Furniture
    SHELF = "SHELF"
    CHAIR = "CHAIR"
    COUCH = "COUCH"
    BED = "BED"
    TABLE = "TABLE"
    COUNTER = "COUNTER"

    # Items
    SHELF_ITEM = "SHELF_ITEM"
    TABLE_ITEM = "TABLE_ITEM"
    FOOD = "FOOD"
    DRINK = "DRINK"
    BAG = "BAG"

    # Vehicles & Equipment
    VEHICLE = "VEHICLE"
    RACKET = "RACKET"

    # Electronics
    ELECTRONICS = "ELECTRONICS"
    PHONE = "PHONE"
    LAPTOP = "LAPTOP"
    SCREEN = "SCREEN"

    # Retail/Service
    CHECKOUT = "CHECKOUT"
    QUEUE_AREA = "QUEUE_AREA"


class InteractionType(StrEnum):
    """
    Human-Object Interaction types for depth-aware HOI detection.

    Represents different types of interactions detected between
    humans and objects using depth and spatial analysis.

    Attributes
    ----------
    # Static Interactions (Original)
    HOLDING : str
        Person is holding an object (close depth, hand region).
    TOUCHING : str
        Person is physically touching an object or person.
    USING : str
        Person is actively using an object (e.g., phone, laptop).
    NEAR : str
        Person is near an object but not interacting.
    TALKING : str
        Two people are engaged in conversation.
    EXAMINING : str
        Person is looking at/examining an object.
    REACHING : str
        Person is reaching towards an object.
    UNKNOWN : str
        Interaction type could not be determined.

    # Motion-based Interactions (Temporal)
    PICKING : str
        Person is picking up an object (object moves up + holding starts).
    DROPPING : str
        Person is dropping an object (object moves down + holding ends).
    PLACING : str
        Person is placing an object on a surface.
    CARRYING : str
        Person is carrying an object while moving.

    # Person-Person Interactions
    STANDING_TOGETHER : str
        Multiple people standing in proximity, stationary.
    WALKING_TOGETHER : str
        Multiple people walking side by side.
    QUEUEING : str
        People standing in a line/queue formation.
    HANDSHAKING : str
        Two people shaking hands.
    HUGGING : str
        Two people in an embrace.
    POINTING_AT : str
        Person pointing at another person or object.

    # Retail Analytics
    BROWSING : str
        Person looking at multiple items sequentially.
    WAITING : str
        Person waiting at a location (stationary, facing service area).
    LOITERING : str
        Person in same area for extended time.

    # Posture Interactions
    SITTING_ON : str
        Person sitting on furniture.
    CROUCHING : str
        Person crouching down.
    BENDING : str
        Person bending over.
    """

    # ===== Static Interactions (Original) =====
    HOLDING = "HOLDING"
    TOUCHING = "TOUCHING"
    USING = "USING"
    NEAR = "NEAR"
    TALKING = "TALKING"
    EXAMINING = "EXAMINING"
    REACHING = "REACHING"
    UNKNOWN = "UNKNOWN"

    # ===== Motion-based Interactions (Temporal) =====
    PICKING = "PICKING"
    DROPPING = "DROPPING"
    PLACING = "PLACING"
    CARRYING = "CARRYING"

    # ===== Person-Person Interactions =====
    STANDING_TOGETHER = "STANDING_TOGETHER"
    WALKING_TOGETHER = "WALKING_TOGETHER"
    QUEUEING = "QUEUEING"
    HANDSHAKING = "HANDSHAKING"
    HUGGING = "HUGGING"
    POINTING_AT = "POINTING_AT"

    # ===== Retail Analytics =====
    BROWSING = "BROWSING"
    WAITING = "WAITING"
    LOITERING = "LOITERING"

    # ===== Posture Interactions =====
    SITTING_ON = "SITTING_ON"
    CROUCHING = "CROUCHING"
    BENDING = "BENDING"


class ContactRegion(StrEnum):
    """
    Body region involved in contact/interaction.

    Represents the part of the human body involved in an interaction.
    """

    HAND = "HAND"
    ARM = "ARM"
    BODY = "BODY"
    FACE = "FACE"
    HEAD = "HEAD"
    LEG = "LEG"
    FOOT = "FOOT"
    UNKNOWN = "UNKNOWN"
