"""
Data contracts for Analytics Service.

This package contains Pydantic models for data validation and serialization.

Modules
-------
base_app_model
    Base model with common configuration.
common_models
    Shared models like Point, Region, BoundingBox.
internal_models
    Models for internal processing state.
kafka_models
    Models for Kafka event serialization.
stats_models
    Models for statistics and metrics.
"""

from .base_app_model import BaseAppModel
from .common_models import (
    Point,
    Line,
    BoundingBox,
    Region,
)

from .internal_models import (
    Detection,
    ObjectDetection,
    Interaction,
    ActiveEngagement,
    ClassNameMapper,
)

from .hoi_models import (
    DepthInfo,
    DetectionWithDepth,
    HOInteraction,
    ActiveHOInteraction,
    DepthMap,
    HOIDetectionResult,
)

from .kafka_models import (
    KafkaBaseModel,
    KafkaBaseAnalyticsEvent,
    KafkaPersonDetectionEvent,
    KafkaEngagementEvent,
    KafkaEventQueueItem,
)
from .stats_models import (
    ProducerStats,
    ConsumerStats
)

__all__ = [
    # Base Model
    "BaseAppModel",
    # Common Models
    "Point",
    "Line",
    "BoundingBox",
    "Region",
    # Internal Models
    "Detection",
    "ObjectDetection",
    "Interaction",
    "ActiveEngagement",
    "ClassNameMapper",
    # HOI Models
    "DepthInfo",
    "DetectionWithDepth",
    "HOInteraction",
    "ActiveHOInteraction",
    "DepthMap",
    "HOIDetectionResult",
    # Kafka Models
    "KafkaBaseModel",
    "KafkaBaseAnalyticsEvent",
    "KafkaPersonDetectionEvent",
    "KafkaEngagementEvent",
    "KafkaEventQueueItem",
    # Stats Models
    "ProducerStats",
    "ConsumerStats",
]
