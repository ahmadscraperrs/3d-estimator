"""
Singleton Helper utilities for Analytics Service.

This module provides a singleton helper object containing utility
functions used throughout the application.

Examples
--------
>>> from utils import helpers
>>> track_key = helpers.generate_track_key("camera-1", 123)
>>> center = helpers.bbox_center([100, 200, 300, 400])
"""

import base64
import hashlib
import zlib
from datetime import datetime, timezone
from typing import Any, Optional, List, Tuple
from uuid import UUID, uuid4
import torch
from core.data_contracts import Point, Region, BoundingBox
from core.constants import Constants


class Helpers:
    """
    Singleton helper class containing utility functions.

    Provides centralized access to helper functions used throughout
    the analytics service.

    Attributes
    ----------
    _instance : Helpers or None
        Singleton instance.
    """

    _instance: Optional["Helpers"] = None

    def __new__(cls) -> "Helpers":
        """
        Create or return singleton instance.

        Returns
        -------
        Helpers
            Singleton instance.
        """
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    @classmethod
    def get_instance(cls) -> "Helpers":
        """
        Get the singleton helper instance.

        Returns
        -------
        Helpers
            Singleton instance.
        """
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """
        Reset the singleton instance.

        Useful for testing to ensure clean state.
        """
        cls._instance = None

    # ==================== ID Generation ====================

    @staticmethod
    def generate_uuid() -> UUID:
        """
        Generate a new UUID.

        Returns
        -------
        UUID
            Newly generated UUID4.
        """
        return uuid4()

    # ==================== Time Utilities ====================

    @staticmethod
    def utc_now() -> datetime:
        """
        Get current UTC datetime.

        Returns
        -------
        datetime
            Current time in UTC timezone.
        """
        return datetime.now(timezone.utc)

    # ==================== Geometry Utilities ====================

    @staticmethod
    def point_in_polygon(point: Point, polygon: List[Point]) -> bool:
        """
        Check if a point is inside a polygon using ray casting algorithm.

        Parameters
        ----------
        point : Point
            Coordinates of point to check
        polygon : List[Point]
            List of Point polygon vertices.

        Returns
        -------
        bool
            True if point is inside polygon.
        """
        if not Helpers.is_valid_polygon(polygon):
            return False
        n = len(polygon)
        inside = False

        j = n - 1
        for i in range(n):
            point_i = polygon[i]
            point_j = polygon[j]

            if ((point_i.y > point.y) != (point_j.y > point.y)) and (
                    point.x < (point_j.x - point_i.x) * (point.y - point_i.x) / (point_j.y - point_i.y) + point_i.x):
                inside = not inside

            j = i

        return inside

    @staticmethod
    def is_point_in_polygon(point: Tuple[float, float], polygon_points: List[Tuple[float, float]]) -> bool:
        """
        Check if a point (x, y tuple) is inside a polygon (list of (x, y) tuples).
        
        Parameters
        ----------
        point : Tuple[float, float]
            Point coordinates as (x, y) tuple.
        polygon_points : List[Tuple[float, float]]
            List of polygon vertices as (x, y) tuples.
            
        Returns
        -------
        bool
            True if point is inside polygon.
        """
        if len(polygon_points) < 3:
            return False
            
        x, y = point
        n = len(polygon_points)
        inside = False
        
        j = n - 1
        for i in range(n):
            xi, yi = polygon_points[i]
            xj, yj = polygon_points[j]
            
            if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / (yj - yi) + xi):
                inside = not inside
                
            j = i
            
        return inside

    @staticmethod
    def bbox_area(bbox: BoundingBox) -> float:
        """
        Calculate area of bounding box.

        Parameters
        ----------
        bbox : BoundingBox
            Bounding box.

        Returns
        -------
        float
            Area in square units.
        """
        x1, y1, x2, y2 = bbox.top_left.x, bbox.top_left.y, bbox.bottom_right.x, bbox.bottom_right.y
        return abs(x2 - x1) * abs(y2 - y1)

    @staticmethod
    def is_detection_in_region(
            bbox: BoundingBox,
            polygon: List[Point],
            use_bottom_center: bool = True
    ) -> bool:
        """
        Check if a detection is inside a region.

        Parameters
        ----------
        bbox : BoundingBox
            Bounding box.
        polygon : List[Point]
            Polygon vertices as list of Point.
        use_bottom_center : bool, default=True
            Use bottom center (feet) instead of center.

        Returns
        -------
        bool
            True if detection is inside region.
        """
        if use_bottom_center:
            center: Point = (Point(x=(bbox.top_left.x + bbox.bottom_right.x) / 2,
                                   y=bbox.bottom_right.y))
        else:
            center: Point = bbox.center

        return Helpers.point_in_polygon(center, polygon)

    # ==================== Data Compression ====================

    @staticmethod
    def compress_data(data: bytes, level: int = 6) -> bytes:
        """
        Compress data using zlib.

        Parameters
        ----------
        data : bytes
            Data to compress.
        level : int, default=6
            Compression level (0-9).

        Returns
        -------
        bytes
            Compressed data.
        """
        return zlib.compress(data, level)

    @staticmethod
    def decompress_data(data: bytes) -> bytes:
        """
        Decompress zlib-compressed data.

        Parameters
        ----------
        data : bytes
            Compressed data.

        Returns
        -------
        bytes
            Decompressed data.
        """
        return zlib.decompress(data)

    @staticmethod
    def encode_base64(data: bytes) -> str:
        """
        Encode bytes to base64 string.

        Parameters
        ----------
        data : bytes
            Data to encode.

        Returns
        -------
        str
            Base64 encoded string.
        """
        return base64.b64encode(data).decode("utf-8")

    @staticmethod
    def decode_base64(data: str) -> bytes:
        """
        Decode base64 string to bytes.

        Parameters
        ----------
        data : str
            Base64 encoded string.

        Returns
        -------
        bytes
            Decoded bytes.
        """
        return base64.b64decode(data.encode("utf-8"))

    # ==================== Hashing ====================

    @staticmethod
    def md5_hash(data: str) -> str:
        """
        Generate MD5 hash of string.

        Parameters
        ----------
        data : str
            String to hash.

        Returns
        -------
        str
            Hexadecimal MD5 hash.
        """
        return hashlib.md5(data.encode("utf-8")).hexdigest()

    @staticmethod
    def sha256_hash(data: str) -> str:
        """
        Generate SHA256 hash of string.

        Parameters
        ----------
        data : str
            String to hash.

        Returns
        -------
        str
            Hexadecimal SHA256 hash.
        """
        return hashlib.sha256(data.encode("utf-8")).hexdigest()

    # ==================== Validation ====================

    @staticmethod
    def is_valid_bbox(bbox: List[float]) -> bool:
        """
        Validate bounding box format and values.

        Parameters
        ----------
        bbox : List[float]
            Bounding box as [x1, y1, x2, y2].

        Returns
        -------
        bool
            True if valid bounding box.

        Notes
        -----
        Checks for:
        - Exactly 4 coordinates
        - Non-negative values
        - x2 > x1 and y2 > y1
        """
        if len(bbox) != 4:
            return False
        if any(v < Constants.MIN_BBOX_COORDINATES for v in bbox):
            return False

        _bbox = BoundingBox.from_list(bbox)
        top_left, bottom_right = _bbox.top_left, _bbox.bottom_right

        if bottom_right.x <= top_left.x or bottom_right.y <= top_left.y:
            return False

        return True

    @staticmethod
    def is_valid_confidence(confidence: float) -> bool:
        """
        Validate confidence score.

        Parameters
        ----------
        confidence : float
            Confidence score to validate.

        Returns
        -------
        bool
            True if confidence is within valid range [0, 1].
        """
        return Constants.MIN_CONFIDENCE_THRESHOLD <= confidence <= Constants.MAX_CONFIDENCE_THRESHOLD

    @staticmethod
    def is_valid_polygon(polygon: List[Point]) -> bool:
        """
        Validate polygon has at least 3 vertices.

        Parameters
        ----------
        polygon : List[Point]
            List of Point vertices.

        Returns
        -------
        bool
            True if polygon has at least 3 vertices.
        """
        return polygon is not None and len(polygon) >= 3

    # ==================== Batch Processing ====================

    @staticmethod
    def chunk_list(items: List[Any], chunk_size: int) -> List[List[Any]]:
        """
        Split a list into chunks of specified size.

        Parameters
        ----------
        items : List[Any]
            List to split.
        chunk_size : int
            Size of each chunk.

        Returns
        -------
        List[List[Any]]
            List of chunks.

        Examples
        --------
        >>> helpers.chunk_list([1, 2, 3, 4, 5], 2)
        [[1, 2], [3, 4], [5]]
        """
        return [items[i:i + chunk_size] for i in range(0, len(items), chunk_size)]

    # ==================== Device Detection ====================

    @staticmethod
    def get_best_device() -> str:
        """
        Detect and return the best available device for model inference.
        
        Checks for devices in priority order:
        1. CUDA GPU (NVIDIA) - best performance
        2. MPS (Apple Silicon) - good performance on Mac
        3. CPU - fallback option
        
        Works with PyTorch-based models (YOLO, etc.).
        
        Returns
        -------
        str
            Device string: 'cuda', 'mps', or 'cpu' based on availability.
            
        Examples
        --------
        >>> device = helpers.get_best_device()
        >>> print(f"Using device: {device}")
        Using device: cuda
        """
        return torch.device("cuda" if torch.cuda.is_available() else "mps" if torch.mps.is_available() else "cpu"
)

    @staticmethod
    def get_device_info() -> dict:
        """
        Get detailed information about available devices.
        
        Returns
        -------
        dict
            Dictionary containing device information:
            - device: str - Device name ('cuda', 'mps', or 'cpu')
            - gpu_available: bool - Whether GPU/accelerator is available
            - gpu_count: int - Number of available GPUs (0 for MPS)
            - gpu_name: str - GPU name if available, None otherwise
            
        Examples
        --------
        >>> info = helpers.get_device_info()
        >>> print(f"Device: {info['device']}, GPU: {info['gpu_name']}")
        Device: cuda, GPU: NVIDIA GeForce RTX 3080
        """
        info = {
            'device': 'cpu',
            'gpu_available': False,
            'gpu_count': 0,
            'gpu_name': None
        }
        if torch.cuda.is_available():
            info['device'] = 'cuda'
            info['gpu_available'] = True
            info['gpu_count'] = torch.cuda.device_count()
            if info['gpu_count'] > 0:
                info['gpu_name'] = torch.cuda.get_device_name(0)
        # Check for MPS (Apple Silicon)
        elif torch.backends.mps.is_available():
            info['device'] = 'mps'
            info['gpu_available'] = True
            info['gpu_count'] = 1  # MPS typically has one device
            info['gpu_name'] = 'Apple Silicon (MPS)'
        
        return info

helpers = Helpers.get_instance()
