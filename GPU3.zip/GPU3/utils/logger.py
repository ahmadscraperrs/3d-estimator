"""
Logging configuration using loguru.

This module provides centralized logging configuration with
console and file output, daily rotation, and compression.

Examples
--------
>>> from utils import logger, setup_logger
>>> setup_logger()  # Initialize with config defaults
>>> logger.info("Application started")
>>> logger.error("An error occurred")
"""

import os
import sys

from loguru import logger

from core.configurations import configs


def setup_logger(
        log_level: str = None,
        log_file: str = None
) -> None:
    """
    Configure logger with file and console output.

    Parameters
    ----------
    log_level : str, optional
        Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL).
        Defaults to config value.
    log_file : str, optional
        Path to log file. Supports {time} placeholder for date-based naming.
        Defaults to config value.

    Notes
    -----
    - Console output includes colors and detailed formatting
    - File output rotates daily at midnight
    - Old log files are compressed with zip and retained for 30 days
    """
    # Use config values if not provided
    log_level = log_level or configs.log_level
    log_file = log_file or configs.log_file

    # Remove default logger
    logger.remove()

    # Add console logger with colors
    logger.add(
        sys.stderr,
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> | <level>{message}</level>",
        level=log_level,
        colorize=True
    )

    # Extract directory from log file path (handle {time} placeholder in filename)
    # Replace {time:...} placeholder with a temporary string to extract directory
    temp_path = log_file.split("{time}")[0] if "{time}" in log_file else log_file
    log_dir = os.path.dirname(temp_path) if temp_path else os.path.dirname(log_file)

    # Create log directory if it doesn't exist
    if log_dir:
        os.makedirs(log_dir, exist_ok=True)

    # Add file logger with daily rotation (24 hours) and date-based naming
    # mode="a" ensures the file is always opened in append mode
    logger.add(
        log_file,
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} | {message}",
        level=log_level,
        rotation="00:00",  # Rotate at midnight every day
        retention="30 days",  # Keep logs for 30 days
        compression="zip",  # Compress old log files
        mode="a"  # Always open file in append mode
    )

    logger.info(f"Logger initialized with level: {log_level}")


def get_logger():
    """
    Get logger instance.

    Returns
    -------
    loguru.Logger
        Configured logger instance.
    """
    return logger


# Export the configured logger
__all__ = ['logger', 'setup_logger', 'get_logger']
