"""
Async Kafka Producer Service for Analytics.

This module provides an asynchronous Kafka producer for
publishing events to the KAFKA_OUTPUT_TOPIC topic.
"""

import asyncio
import json
from datetime import datetime
from typing import Optional, List
from uuid import UUID

from aiokafka import AIOKafkaProducer
from aiokafka.errors import KafkaError

from core import Constants, configs
from core.data_contracts import (
    BaseAppModel,
    KafkaBaseAnalyticsEvent,
    KafkaEngagementEvent,
    KafkaEventQueueItem,
    ProducerStats
)
from utils import logger


class KafkaProducerService:
    """
    Async Kafka producer service for events.

    This service publishes KafkaBaseAnalyticsEvent messages to the
    configured events topic.

    Attributes
    ----------
    _bootstrap_servers : str
        Kafka bootstrap servers connection string.
    _topic : str
        Target topic for publishing events.
    _producer : AIOKafkaProducer or None
        Underlying aiokafka producer instance.
    _running : bool
        Producer running state.
    _message_count : int
        Total messages successfully published.
    _error_count : int
        Total publish errors encountered.

    Examples
    --------
    >>> producer = KafkaProducerService()
    >>> event: KafkaBaseAnalyticsEvent = KafkaBaseAnalyticsEvent()
    >>> await producer.start()
    >>> await producer.publish(event)
    >>> await producer.stop()
    """

    def __init__(
            self,
            bootstrap_servers: Optional[str] = None,
            topic: Optional[str] = None,
    ) -> None:
        """
        Initialize Kafka producer service.

        Parameters
        ----------
        bootstrap_servers : str, optional
            Kafka bootstrap servers. Defaults to config value.
        topic : str, optional
            Topic to publish to. Defaults to config value.
        """
        self._bootstrap_servers = bootstrap_servers or configs.kafka_bootstrap_servers
        self._topic = topic or configs.kafka_topic_output

        self._producer: Optional[AIOKafkaProducer] = None
        self._running = False
        self._message_count = 0
        self._error_count = 0

        # Producer configuration from Constants
        self._acks = Constants.DEFAULT_ACKS
        self._retries = Constants.DEFAULT_RETRIES
        self._retry_backoff_ms = Constants.DEFAULT_RETRY_BACKOFF_MS
        self._linger_ms = Constants.DEFAULT_LINGER_MS
        self._batch_size = Constants.DEFAULT_PRODUCER_BATCH_SIZE

    async def start(self) -> None:
        """
        Start the Kafka producer.

        Creates and starts the underlying AIOKafkaProducer instance.

        Raises
        ------
        KafkaError
            If connection to Kafka brokers fails.
        """
        if self._producer is not None:
            logger.warning("Producer already started")
            return

        logger.info(
            f"Starting Kafka producer: servers={self._bootstrap_servers}, "
            f"topic={self._topic}"
        )

        self._producer = AIOKafkaProducer(
            bootstrap_servers=self._bootstrap_servers,
            acks=self._acks,
            retry_backoff_ms=self._retry_backoff_ms,
            linger_ms=0,  # Send immediately for low latency
            max_batch_size=self._batch_size,
            value_serializer=self._serialize_value,
            key_serializer=self._serialize_key,
        )

        await self._producer.start()
        self._running = True
        logger.info("Kafka producer started successfully")

    async def stop(self) -> None:
        """
        Stop the Kafka producer.

        Flushes pending messages and closes the connection.
        """
        if self._producer is None:
            return

        logger.info("Stopping Kafka producer...")
        self._running = False

        try:
            await self._producer.stop()
        except Exception as e:
            logger.error(f"Error stopping producer: {e}")
        finally:
            self._producer = None

        logger.info(
            f"Kafka producer stopped. Messages: {self._message_count}, Errors: {self._error_count}"
        )

    def _serialize_key(self, key: Optional[str]) -> Optional[bytes]:
        """
        Serialize message key to bytes.

        Parameters
        ----------
        key : str or None
            Message key string.

        Returns
        -------
        bytes or None
            UTF-8 encoded key, or None if input is None.
        """
        if key is None:
            return None
        return key.encode("utf-8")

    def _serialize_value(self, value: dict) -> bytes:
        """
        Serialize message value to JSON bytes.

        Parameters
        ----------
        value : dict
            Message value dictionary.

        Returns
        -------
        bytes
            UTF-8 encoded JSON string.
        """
        return json.dumps(value, default=self._json_serializer).encode("utf-8")

    @staticmethod
    def _json_serializer(obj):
        """
        Custom JSON serializer for special types.

        Parameters
        ----------
        obj : Any
            Object to serialize.

        Returns
        -------
        str or dict
            Serializable representation of the object.

        Raises
        ------
        TypeError
            If object type is not supported.
        """
        if isinstance(obj, datetime):
            return obj.isoformat()
        if isinstance(obj, UUID):
            return str(obj)
        if isinstance(obj, BaseAppModel):
            return obj.model_dump(mode="json")
        raise TypeError(f"Object of type {type(obj)} is not JSON serializable")

    @staticmethod
    def _event_to_dict(event: KafkaBaseAnalyticsEvent) -> dict:
        """
        Convert KafkaBaseAnalyticsEvent to dictionary for Kafka serialization.

        Parameters
        ----------
        event : KafkaBaseAnalyticsEvent
            Analytics event to convert.

        Returns
        -------
        dict
            JSON-serializable dictionary representation.
        """
        return event.model_dump(mode="json")

    @staticmethod
    def _generate_key(event: KafkaBaseAnalyticsEvent) -> str:
        """
        Generate message key from event.

        Parameters
        ----------
        event : KafkaBaseAnalyticsEvent
            Analytics event to generate key for.

        Returns
        -------
        str
            Message key (camera_id).
        """
        return event.camera_id

    async def publish(
            self,
            event: KafkaBaseAnalyticsEvent,
            topic: Optional[str] = None,
    ) -> bool:
        """
        Publish a single event asynchronously (fire-and-forget).

        Parameters
        ----------
        event : KafkaBaseAnalyticsEvent
            Analytics event to publish.
        topic : str, optional
            Target topic. Defaults to configured topic.

        Returns
        -------
        bool
            True if message was queued successfully.

        Raises
        ------
        RuntimeError
            If producer has not been started.
        """
        if self._producer is None:
            raise RuntimeError("Producer not started. Call start() first.")

        target_topic = topic or self._topic
        key = self._generate_key(event)
        value = self._event_to_dict(event)

        try:
            # Use send() for async fire-and-forget (non-blocking)
            await self._producer.send(
                topic=target_topic,
                key=key,
                value=value,
            )
            self._message_count += 1
            return True

        except KafkaError as e:
            logger.error(f"Failed to publish event: {e}")
            self._error_count += 1
            return False

    async def publish_batch(
            self,
            events: List[KafkaBaseAnalyticsEvent],
            topic: Optional[str] = None,
    ) -> int:
        """
        Publish a batch of events.

        Parameters
        ----------
        events : List[KafkaBaseAnalyticsEvent]
            List of events to publish.
        topic : str, optional
            Target topic. Defaults to configured topic.

        Returns
        -------
        int
            Number of successfully published events.

        Raises
        ------
        RuntimeError
            If producer has not been started.
        """
        if self._producer is None:
            raise RuntimeError("Producer not started. Call start() first.")

        target_topic = topic or self._topic
        success_count = 0

        # Send all messages
        futures = []
        for event in events:
            key = self._generate_key(event)
            value = self._event_to_dict(event)

            try:
                future = await self._producer.send(
                    topic=target_topic,
                    key=key,
                    value=value,
                )
                futures.append((event, future))
            except KafkaError as e:
                logger.error(f"Failed to send event: {e}")
                self._error_count += 1

        # Wait for all to complete
        for event, future in futures:
            try:
                await future
                self._message_count += 1
                success_count += 1
            except KafkaError as e:
                logger.error(f"Failed to publish event: {e}")
                self._error_count += 1

        logger.info(f"Published {success_count}/{len(events)} events")
        return success_count

    async def publish_engagement(
            self,
            event: KafkaEngagementEvent,
            topic: Optional[str] = None,
    ) -> bool:
        """
        Publish an engagement event to Kafka.

        Parameters
        ----------
        event : KafkaEngagementEvent
            Engagement event to publish.
        topic : str, optional
            Target topic. Defaults to configured engagement topic.

        Returns
        -------
        bool
            True if message was queued successfully.

        Raises
        ------
        RuntimeError
            If producer has not been started.
        """
        if self._producer is None:
            raise RuntimeError("Producer not started. Call start() first.")

        target_topic = topic or configs.kafka_topic_output
        key = event.camera_id
        value = event.model_dump(mode="json")

        try:
            await self._producer.send(
                topic=target_topic,
                key=key,
                value=value,
            )
            self._message_count += 1
            return True

        except KafkaError as e:
            logger.error(f"Failed to publish engagement event: {e}")
            self._error_count += 1
            return False

    async def publish_from_queue(
            self,
            queue: asyncio.Queue,
            stop_event: asyncio.Event,
    ) -> None:
        """
        Continuously publish events from a queue.

        Parameters
        ----------
        queue : asyncio.Queue
            Queue of KafkaEventQueueItem to publish.
        stop_event : asyncio.Event
            Event to signal stopping.

        Notes
        -----
        Failed publishes are re-queued up to 3 times.
        """
        logger.info("Starting queue publisher")

        while not stop_event.is_set():
            try:
                # Use timeout to check stop event periodically
                try:
                    item: KafkaEventQueueItem = await asyncio.wait_for(
                        queue.get(),
                        timeout=1.0
                    )
                except asyncio.TimeoutError:
                    continue

                success = await self.publish(item.event)

                if not success and item.retry_count < 3:
                    # Re-queue for retry
                    item.retry_count += 1
                    await queue.put(item)

                queue.task_done()

            except Exception as e:
                logger.error(f"Error in queue publisher: {e}")

        logger.info("Queue publisher stopped")

    @property
    def is_running(self) -> bool:
        """
        Check if producer is running.

        Returns
        -------
        bool
            True if producer is running.
        """
        return self._running

    @property
    def message_count(self) -> int:
        """
        Get total message count.

        Returns
        -------
        int
            Total messages successfully published.
        """
        return self._message_count

    @property
    def error_count(self) -> int:
        """
        Get error count.

        Returns
        -------
        int
            Total publish errors encountered.
        """
        return self._error_count

    def get_stats(self) -> ProducerStats:
        """
        Get producer statistics.

        Returns
        -------
        ProducerStats
            Current producer statistics.
        """
        return ProducerStats(
            running=self._running,
            message_count=self._message_count,
            error_count=self._error_count,
            topic=self._topic,
        )
