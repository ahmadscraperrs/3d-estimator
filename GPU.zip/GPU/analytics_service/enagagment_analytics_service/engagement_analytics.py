"""
Engagement Analytics Service with HOI (Human-Object Interaction) Detection.

This module provides depth-aware engagement detection using Depth Anything v2
for more accurate "who-did-what-to-what" understanding compared to IoU-based
detection.

Consumes person detection events and detects engagements (person-person and
person-object) using depth estimation and spatial analysis.
"""
import asyncio
import base64
import uuid
import zlib
from collections import defaultdict
from datetime import datetime
from typing import Optional, Dict, List, Tuple

import cv2
import numpy as np
from ultralytics import YOLO

from utils import logger

from core import configs
from core.data_contracts import (
    KafkaBaseAnalyticsEvent,
    KafkaEngagementEvent,
    KafkaPersonDetectionEvent,
    Region,
    Interaction,
    BoundingBox,
    ObjectDetection,
    ClassNameMapper,
    Detection,
    HOInteraction,
)
from core.enums import (
    ServiceType,
    EventType,
    IntersectionType,
    TargetCategory,
    InteractionType,
    ContactRegion,
)
from ..base_analytics_service import BaseAnalyticsService
from ..hoi import HOIDetector
from services import ensure_topics_exist, KafkaProducerService
from utils import logger, helpers


class EngagementAnalyticsService(BaseAnalyticsService):
    """
    Engagement Analytics Service with HOI Detection.
    
    Consumes person detection events and detects engagements using
    depth-aware Human-Object Interaction (HOI) detection.
    
    Features:
    - Depth Anything v2 for depth estimation
    - Depth-aware interaction classification
    - Supports HOLDING, TOUCHING, USING, NEAR, TALKING, EXAMINING, REACHING
    - Temporal smoothing for stable detections
    - Multi-camera support
    """

    def __init__(self):
        super().__init__()
        
        # Engagement producer (separate from base producer)
        self._engagement_producer: Optional[KafkaProducerService] = None
        
        # Detect and set device (GPU/CPU)
        device_info = helpers.get_device_info()
        self.device = helpers.get_best_device()
        
        logger.info("=" * 60)
        logger.info("HOI Engagement Analytics Service")
        logger.info("=" * 60)
        logger.info(f"Device: {self.device}")
        logger.info(f"GPU Available: {device_info['gpu_available']}")
        if device_info['gpu_available']:
            logger.info(f"GPU Count: {device_info['gpu_count']}")
            logger.info(f"GPU Name: {device_info['gpu_name']}")
        logger.info("=" * 60)
        
        # YOLO model for object detection
        logger.info(f"Loading YOLO model from {configs.model_path}")
        logger.info(f"Model will use device: {self.device}")
        try:
            self.model = YOLO(configs.model_path)
            self.model.model.to(self.device)
            logger.info(f"YOLO model initialized on {self.device}")
        except Exception as e:
            logger.error(f"Failed to initialize YOLO model: {e}")
            raise
        
        self.confidence_threshold = configs.model_conf
        self.person_class_id = configs.person_class_id
        self.object_classes = set(configs.object_classes)
        
        # HOI Detection Configuration
        self.HOI_ENABLED = configs.hoi_enabled
        logger.info(f"HOI Detection: {'Enabled' if self.HOI_ENABLED else 'Disabled'}")
        
        if self.HOI_ENABLED:
            # Initialize HOI Detector
            self.hoi_detector = HOIDetector(
                depth_model=configs.hoi_depth_model_variant,
                device=configs.hoi_depth_model_device,
                depth_proximity_threshold=configs.hoi_depth_proximity_threshold,
                near_threshold=configs.hoi_near_threshold,
                min_confidence=configs.hoi_min_confidence,
                temporal_smoothing=configs.hoi_temporal_smoothing_frames,
                inactivity_timeout=configs.hoi_inactivity_timeout,
            )
            logger.info(
                f"HOI Detector initialized: "
                f"depth_model={configs.hoi_depth_model_variant}, "
                f"depth_threshold={configs.hoi_depth_proximity_threshold}, "
                f"near_threshold={configs.hoi_near_threshold}"
            )
        else:
            self.hoi_detector = None
            logger.warning("HOI detection disabled - using fallback mode")
        
        # Engagement parameters
        self.ENABLE_ENGAGEMENT_BY_DEFAULT = configs.enable_engagement_by_default
        
        # Initialize class name mapper
        self.class_name_mapper = ClassNameMapper()
        
        # State tracking per camera
        self.camera_states: Dict[str, Dict] = defaultdict(
            lambda: {
                "frame_count": 0,
                "_warned_normalized_bbox_without_frame": False,
            }
        )
        
        # Store regions per camera
        self.camera_regions: Dict[str, List[Region]] = {}
        self.camera_services: Dict[str, List[ServiceType]] = {}
        
        # Track skipped events (engagement not enabled)
        self._events_skipped: int = 0
        # Track engagement publications
        self._engagements_published: int = 0

    async def start(self) -> None:
        """Start all services including engagement producer."""
        await super().start()
        
        # Start engagement producer
        self._engagement_producer = KafkaProducerService(
            topic=configs.kafka_topic_engagement
        )
        await self._engagement_producer.start()
        logger.info("Engagement producer started")

    async def stop(self) -> None:
        """Stop all services including engagement producer."""
        if self._engagement_producer:
            await self._engagement_producer.stop()
        await super().stop()

    def _decode_frame(self, frame_data: str) -> Optional[np.ndarray]:
        """Decode and decompress frame data."""
        try:
            compressed_bytes = base64.b64decode(frame_data)
            try:
                raw_bytes = zlib.decompress(compressed_bytes)
            except (zlib.error, TypeError):
                raw_bytes = compressed_bytes
            nparr = np.frombuffer(raw_bytes, np.uint8)
            frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            return frame
        except Exception as e:
            logger.error(f"Failed to decode frame: {e}")
            return None

    def _normalize_bbox(
        self,
        camera_id: str,
        bbox: List[float],
        frame: Optional[np.ndarray]
    ) -> Optional[List[float]]:
        """Normalize bbox into xyxy pixel coordinates."""
        if not bbox or len(bbox) != 4:
            return None
        
        try:
            x1, y1, x2, y2 = [float(v) for v in bbox]
        except Exception:
            return None
        
        is_xywh = (x2 < x1) or (y2 < y1)
        looks_normalized = all(0.0 <= v <= 1.0 for v in [x1, y1, x2, y2])
        
        if looks_normalized and frame is None:
            state = self.camera_states[camera_id]
            if not state.get("_warned_normalized_bbox_without_frame", False):
                logger.warning(f"[{camera_id}] BBox appears normalized but frame is missing")
                state["_warned_normalized_bbox_without_frame"] = True
        
        if frame is not None and looks_normalized:
            h, w = frame.shape[:2]
            if is_xywh:
                x, y, bw, bh = x1, y1, x2, y2
                x1, y1 = x * w, y * h
                x2, y2 = (x + bw) * w, (y + bh) * h
            else:
                x1, x2 = x1 * w, x2 * w
                y1, y2 = y1 * h, y2 * h
            is_xywh = False
        
        if is_xywh:
            x, y, bw, bh = x1, y1, x2, y2
            x1, y1, x2, y2 = x, y, x + bw, y + bh
        
        x_min, x_max = (x1, x2) if x1 <= x2 else (x2, x1)
        y_min, y_max = (y1, y2) if y1 <= y2 else (y2, y1)
        
        return [x_min, y_min, x_max, y_max]

    def _detect_region(
        self,
        engagement_center: tuple,
        regions: Optional[List[Region]]
    ) -> Optional[Region]:
        """Detect which region the engagement center point is in."""
        if not regions:
            return None
        
        for region in regions:
            if helpers.is_valid_polygon(region.polygon):
                polygon_points = [(p.x, p.y) for p in region.polygon]
                if helpers.is_point_in_polygon(engagement_center, polygon_points):
                    return region
            elif not region.polygon:
                return region
        
        return None

    def _get_services_from_region(self, region: Optional[Region]) -> List[ServiceType]:
        """Get services from region."""
        if not region or not hasattr(region, 'services') or not region.services:
            return []
        
        service_types: List[ServiceType] = []
        for svc in region.services:
            if isinstance(svc, str):
                try:
                    service_types.append(ServiceType(svc))
                except ValueError:
                    pass
            elif isinstance(svc, ServiceType):
                service_types.append(svc)
        return service_types

    def _interaction_type_to_intersection_types(
        self,
        interaction_type
    ) -> List[IntersectionType]:
        """Convert HOI InteractionType to legacy IntersectionType list."""
        # Handle both enum and string values (due to use_enum_values=True)
        mapping = {
            "HOLDING": [IntersectionType.PHYSICAL],
            "TOUCHING": [IntersectionType.PHYSICAL],
            "USING": [IntersectionType.PHYSICAL],
            "NEAR": [IntersectionType.OTHER],
            "TALKING": [IntersectionType.TALKING],
            "EXAMINING": [IntersectionType.OTHER],
            "REACHING": [IntersectionType.OTHER],
            "UNKNOWN": [IntersectionType.UNKNOWN],
        }
        # Get string value from enum or use directly if already string
        key = interaction_type.value if hasattr(interaction_type, 'value') else str(interaction_type)
        return mapping.get(key, [IntersectionType.UNKNOWN])

    async def _publish_hoi_engagement(
        self,
        camera_id: str,
        person_event_id: uuid.UUID,
        hoi_interaction: HOInteraction,
        services: Optional[List[ServiceType]] = None,
        region: Optional[Region] = None,
    ) -> bool:
        """Publish HOI engagement event."""
        if not self._engagement_producer:
            logger.warning(f"[{camera_id}] Engagement producer not available")
            return False
        
        # Create Interaction from HOInteraction (for backward compatibility)
        interaction = Interaction(
            visitor_bbox=hoi_interaction.person_bbox,
            target_bbox=hoi_interaction.target_bbox or hoi_interaction.person_bbox,
            target_category=hoi_interaction.target_category,
            intersection_types=self._interaction_type_to_intersection_types(
                hoi_interaction.interaction_type
            ),
            start_time=hoi_interaction.start_time,
            end_time=hoi_interaction.end_time or datetime.now(),
            # HOI-specific fields
            interaction_type=hoi_interaction.interaction_type,
            depth_distance=hoi_interaction.depth_distance,
            contact_region=hoi_interaction.contact_region,
            confidence=hoi_interaction.confidence,
        )
        
        event = KafkaEngagementEvent(
            event_type=EventType.PERSON_ENGAGEMENT,
            camera_id=camera_id,
            person_event_id=person_event_id,
            services=services or [],
            region=region,
            interaction=interaction,
            # HOI-specific fields in event
            interaction_type=hoi_interaction.interaction_type,
            depth_distance=hoi_interaction.depth_distance,
            contact_region=hoi_interaction.contact_region,
            confidence=hoi_interaction.confidence,
        )
        
        success = await self._engagement_producer.publish_engagement(event)
        if success:
            self._engagements_published += 1
            self._events_published += 1
            
            duration = hoi_interaction.duration_seconds or 0
            # Handle both enum and string values (due to use_enum_values=True)
            interaction_type_str = (
                hoi_interaction.interaction_type.value 
                if hasattr(hoi_interaction.interaction_type, 'value') 
                else str(hoi_interaction.interaction_type)
            )
            target_category_str = (
                hoi_interaction.target_category.value 
                if hasattr(hoi_interaction.target_category, 'value') 
                else str(hoi_interaction.target_category)
            )
            logger.debug(
                f"[{camera_id}] Published HOI engagement: "
                f"{interaction_type_str} "
                f"({target_category_str}), "
                f"depth={hoi_interaction.depth_distance:.3f}, "
                f"conf={hoi_interaction.confidence:.2f}, "
                f"duration={duration:.2f}s"
            )
        else:
            logger.error(f"[{camera_id}] Failed to publish HOI engagement event")
        
        return success

    def _is_engagement_enabled(self, event: KafkaPersonDetectionEvent) -> bool:
        """Check if Engagement service is enabled for this camera."""
        event_services = event.services if hasattr(event, 'services') and event.services else []
        if ServiceType.ENGAGEMENT in event_services or "ENGAGEMENT" in event_services:
            return True
        
        if hasattr(event, 'regions') and event.regions:
            for region in event.regions:
                if hasattr(region, 'services') and region.services:
                    if ServiceType.ENGAGEMENT in region.services or "ENGAGEMENT" in region.services:
                        camera_id = event.camera_id
                        if camera_id not in self.camera_regions:
                            self.camera_regions[camera_id] = []
                        if region not in self.camera_regions[camera_id]:
                            self.camera_regions[camera_id].append(region)
                        return True
        
        if self.ENABLE_ENGAGEMENT_BY_DEFAULT:
            return True
        
        return False

    async def _process_person_event(self, event: KafkaPersonDetectionEvent):
        """Process a person detection event using HOI detection."""
        try:
            camera_id = event.camera_id
            
            # Check if Engagement service is enabled
            if not self._is_engagement_enabled(event):
                self._events_skipped += 1
                if self._events_skipped <= 3:
                    logger.debug(
                        f"[{camera_id}] Event skipped - ENGAGEMENT service not enabled"
                    )
                return
            
            frame_number = event.frame_number
            timestamp = event.timestamp
            frame_data = event.frame_data
            detections = event.detections
            regions = event.regions
            
            services = event.services
            if not services:
                services = self.camera_services.get(camera_id, [])
            
            # Update frame count
            self.camera_states[camera_id]["frame_count"] = frame_number
            
            # Decode frame - required for HOI detection
            frame = self._decode_frame(frame_data) if frame_data else None
            
            if frame is None:
                logger.debug(f"[{camera_id}] No frame available for HOI detection")
                return
            
            # Run YOLO object detection on frame
            objects: List[ObjectDetection] = []
            if self.model is not None:
                results = self.model.track(
                    frame,
                    conf=self.confidence_threshold,
                    device=self.device,
                    persist=True,
                    verbose=False
                )
                
                if results and len(results) > 0:
                    boxes = results[0].boxes
                    for box in boxes:
                        cls = int(box.cls[0])
                        
                        if cls in self.object_classes:
                            conf = float(box.conf[0])
                            bbox = box.xyxy[0].cpu().numpy().tolist()
                            track_id = int(box.id[0]) if box.id is not None else hash(str(bbox)) % 100000
                            raw_class = self.model.names[cls] if hasattr(self.model, 'names') else f"class_{cls}"
                            target_category = self.class_name_mapper.map(raw_class)
                            
                            obj_detection = ObjectDetection(
                                bbox=BoundingBox.from_list(bbox),
                                confidence=conf,
                                tracking_id=track_id,
                                class_id=cls,
                                class_name=raw_class,
                                target_category=target_category
                            )
                            objects.append(obj_detection)
            
            # Process person detections - convert to Detection objects
            persons: List[Detection] = []
            for detection in detections:
                raw_bbox = detection.bbox if isinstance(detection.bbox, list) else []
                tracking_id = detection.tracking_id or 0
                
                bbox = self._normalize_bbox(camera_id, raw_bbox, frame)
                if bbox and len(bbox) == 4:
                    persons.append(Detection(
                        bbox=bbox,
                        confidence=detection.confidence if hasattr(detection, 'confidence') else 1.0,
                        tracking_id=tracking_id,
                        region=detection.region if hasattr(detection, 'region') else None,
                    ))
            
            if not persons:
                return
            
            # Convert services to ServiceType enum
            service_types: List[ServiceType] = []
            for svc in services:
                if isinstance(svc, str):
                    try:
                        service_types.append(ServiceType(svc))
                    except ValueError:
                        pass
                elif isinstance(svc, ServiceType):
                    service_types.append(svc)
            
            # Run HOI detection
            if self.hoi_detector is not None:
                hoi_result = self.hoi_detector.detect(
                    frame=frame,
                    persons=persons,
                    objects=objects,
                    camera_id=camera_id,
                    timestamp=timestamp,
                    frame_number=frame_number,
                )
                
                # Publish ended interactions
                for interaction in hoi_result.interactions:
                    # Determine region from engagement center
                    if interaction.target_bbox:
                        engagement_center = (
                            (interaction.person_bbox.center.x + interaction.target_bbox.center.x) / 2,
                            (interaction.person_bbox.center.y + interaction.target_bbox.center.y) / 2,
                        )
                    else:
                        engagement_center = (
                            interaction.person_bbox.center.x,
                            interaction.person_bbox.center.y,
                        )
                    
                    detected_region = self._detect_region(engagement_center, regions)
                    resolved_services = service_types
                    if detected_region:
                        region_services = self._get_services_from_region(detected_region)
                        if region_services:
                            resolved_services = region_services
                    
                    await self._publish_hoi_engagement(
                        camera_id=camera_id,
                        person_event_id=event.event_id,
                        hoi_interaction=interaction,
                        services=resolved_services,
                        region=detected_region,
                    )
            else:
                logger.warning(f"[{camera_id}] HOI detector not available")
        
        except Exception as e:
            logger.error(f"Error processing person event: {e}", exc_info=True)

    def fire_and_forget_publish(self, event: KafkaBaseAnalyticsEvent) -> None:
        """Schedule publish without blocking."""
        task = asyncio.create_task(self.publish_event(event))
        self._publish_tasks.add(task)
        task.add_done_callback(self._publish_tasks.discard)

    async def publish_event(self, event: KafkaBaseAnalyticsEvent) -> None:
        """Publish event to Kafka."""
        if self._producer:
            try:
                await self._producer.publish(event)
                self._events_published += 1
            except Exception as e:
                logger.error(f"Error publishing event: {e}")

    async def log_stats(self) -> None:
        """Periodically log statistics."""
        while self._running:
            await asyncio.sleep(30.0)
            if self._start_time:
                elapsed = (datetime.now() - self._start_time).total_seconds()
                rate = self._events_consumed / elapsed if elapsed > 0 else 0
                
                # Get active HOI interactions count
                active_count = 0
                if self.hoi_detector:
                    active_count = self.hoi_detector.get_active_interaction_count()
                
                depth_status = "Available" if (
                    self.hoi_detector and self.hoi_detector.is_depth_available
                ) else "Unavailable"
                
                logger.info(
                    f"Stats: Consumed={self._events_consumed}, "
                    f"Processed={self._events_processed}, "
                    f"Published={self._events_published}, "
                    f"HOI_Engagements={self._engagements_published}, "
                    f"Active={active_count}, "
                    f"Skipped={self._events_skipped}, "
                    f"Depth={depth_status}, "
                    f"Rate={rate:.2f} events/sec"
                )

    async def run(self) -> None:
        """Main run loop - HOI engagement detection pipeline."""
        await self.start()
        
        # Start stats logging task
        stats_task = asyncio.create_task(self.log_stats())
        
        try:
            logger.info("Starting HOI engagement detection pipeline...")
            logger.info(f"HOI Detection: {'Enabled' if self.HOI_ENABLED else 'Disabled'}")
            if self.hoi_detector:
                logger.info(f"Depth Estimation: {'Available' if self.hoi_detector.is_depth_available else 'Unavailable'}")
            
            # Consume events
            async for event in self._consumer.consume():
                if not self._running:
                    break
                
                self._events_consumed += 1
                await self._process_person_event(event)
                self._events_processed += 1
        
        except Exception as e:
            logger.error(f"Error in run loop: {e}", exc_info=True)
            raise
        finally:
            stats_task.cancel()
            try:
                await stats_task
            except asyncio.CancelledError:
                pass
