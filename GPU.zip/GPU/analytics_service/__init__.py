"""
Services for Analytics Service.

This package contains service classes for analytics event processing.

Modules
-------
base_analytics_service
    Async abstract base analytics service
depth
    Depth estimation using Depth Anything v2
hoi
    Human-Object Interaction detection

Examples
--------
>>> from analytics_service import EngagementAnalyticsService
>>> service = EngagementAnalyticsService()
"""
from .base_analytics_service import BaseAnalyticsService
from .enagagment_analytics_service import EngagementAnalyticsService
from .depth import DepthEstimator
from .hoi import HOIDetector, InteractionClassifier


__all__ = [
    "BaseAnalyticsService",
    "EngagementAnalyticsService",
    "DepthEstimator",
    "HOIDetector",
    "InteractionClassifier",
]