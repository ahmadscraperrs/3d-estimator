"""
Human-Object Interaction (HOI) Detector.

Main orchestrator for depth-aware HOI detection, combining
depth estimation with interaction classification.
"""
import time
from collections import defaultdict
from datetime import datetime
from typing import Dict, List, Optional, Tuple

import numpy as np

from core.data_contracts import (
    BoundingBox,
    Detection,
    ObjectDetection,
    DepthMap,
    DepthInfo,
    DetectionWithDepth,
    HOInteraction,
    ActiveHOInteraction,
    HOIDetectionResult,
)
from core.enums import InteractionType, ContactRegion, TargetCategory
from utils import logger

from ..depth import DepthEstimator
from .interaction_classifier import InteractionClassifier


class HOIDetector:
    """
    Human-Object Interaction detector with depth awareness.

    Combines Depth Anything v2 for depth estimation with
    interaction classification for accurate HOI detection.

    Attributes
    ----------
    depth_estimator : DepthEstimator
        Depth estimation model wrapper.
    interaction_classifier : InteractionClassifier
        Interaction classification logic.
    active_interactions : Dict
        Tracks active (ongoing) interactions per camera.

    Examples
    --------
    >>> detector = HOIDetector(depth_model="small")
    >>> result = detector.detect(frame, persons, objects, camera_id, timestamp)
    >>> for interaction in result.interactions:
    ...     print(f"{interaction.interaction_type}: {interaction.confidence}")
    """

    def __init__(
        self,
        depth_model: str = "small",
        device: str = "auto",
        depth_proximity_threshold: float = 0.15,
        near_threshold: float = 0.3,
        min_confidence: float = 0.5,
        temporal_smoothing: int = 3,
        inactivity_timeout: float = 1.0,
    ) -> None:
        """
        Initialize the HOI detector.

        Parameters
        ----------
        depth_model : str
            Depth model variant ('small', 'base', 'large').
        device : str
            Device for inference ('auto', 'cuda', 'cpu').
        depth_proximity_threshold : float
            Max depth difference for physical interaction.
        near_threshold : float
            Max depth difference for near classification.
        min_confidence : float
            Minimum confidence to report interaction.
        temporal_smoothing : int
            Number of frames for temporal smoothing.
        inactivity_timeout : float
            Seconds before considering interaction ended.
        """
        self.depth_estimator = DepthEstimator(
            variant=depth_model,
            device=device,
        )

        self.interaction_classifier = InteractionClassifier(
            depth_proximity_threshold=depth_proximity_threshold,
            near_threshold=near_threshold,
            min_confidence=min_confidence,
        )

        self.temporal_smoothing = temporal_smoothing
        self.inactivity_timeout = inactivity_timeout

        # Track active interactions per camera: camera_id -> {(person_id, target_id) -> ActiveHOInteraction}
        self.active_interactions: Dict[str, Dict[Tuple[str, str], ActiveHOInteraction]] = defaultdict(dict)

        # Track frame counts for UUID generation
        self._uuid_counters: Dict[str, int] = defaultdict(int)

        logger.info(
            f"HOIDetector initialized: depth_model={depth_model}, "
            f"depth_threshold={depth_proximity_threshold}, "
            f"near_threshold={near_threshold}"
        )

    def detect(
        self,
        frame: np.ndarray,
        persons: List[Detection],
        objects: List[ObjectDetection],
        camera_id: str,
        timestamp: datetime,
        frame_number: int = 0,
    ) -> HOIDetectionResult:
        """
        Detect human-object interactions in a frame.

        Parameters
        ----------
        frame : np.ndarray
            Input RGB frame (H, W, 3) in BGR format.
        persons : List[Detection]
            Detected persons from YOLO/tracker.
        objects : List[ObjectDetection]
            Detected objects from YOLO.
        camera_id : str
            Camera identifier.
        timestamp : datetime
            Frame timestamp.
        frame_number : int
            Frame number for tracking.

        Returns
        -------
        HOIDetectionResult
            Detection result with all interactions.
        """
        start_time = time.time()

        # Estimate depth
        depth_map = self.depth_estimator.estimate(frame)

        # Enrich detections with depth
        persons_with_depth = self._enrich_persons_with_depth(persons, depth_map)
        objects_with_depth = self._enrich_objects_with_depth(objects, depth_map)

        # Detect current frame interactions
        current_interactions = self._detect_frame_interactions(
            persons_with_depth,
            objects_with_depth,
            camera_id,
            timestamp,
        )

        # Update active interactions tracking
        ended_interactions = self._update_active_interactions(
            camera_id,
            current_interactions,
            timestamp,
        )

        processing_time = (time.time() - start_time) * 1000

        # Create result with only ended interactions (completed ones)
        result = HOIDetectionResult(
            camera_id=camera_id,
            frame_number=frame_number,
            timestamp=timestamp,
            interactions=ended_interactions,
            depth_map_info=DepthMap(
                width=depth_map.width,
                height=depth_map.height,
                min_depth=depth_map.min_depth,
                max_depth=depth_map.max_depth,
                mean_depth=depth_map.mean_depth,
            ),
            processing_time_ms=processing_time,
        )

        if ended_interactions:
            logger.debug(
                f"[{camera_id}] HOI detection: {len(ended_interactions)} interactions ended, "
                f"processing={processing_time:.1f}ms"
            )

        return result

    def _enrich_persons_with_depth(
        self,
        persons: List[Detection],
        depth_map: DepthMap,
    ) -> List[DetectionWithDepth]:
        """Add depth information to person detections."""
        enriched = []
        for person in persons:
            # Convert bbox list to BoundingBox if needed
            if isinstance(person.bbox, list) and len(person.bbox) == 4:
                bbox = BoundingBox.from_list(person.bbox)
            else:
                bbox = person.bbox

            depth_info = depth_map.get_depth_in_bbox(bbox)

            enriched.append(DetectionWithDepth(
                tracking_id=person.tracking_id or 0,
                bbox=bbox,
                confidence=person.confidence,
                class_name="person",
                target_category=TargetCategory.PERSON,
                depth_info=depth_info,
            ))

        return enriched

    def _enrich_objects_with_depth(
        self,
        objects: List[ObjectDetection],
        depth_map: DepthMap,
    ) -> List[DetectionWithDepth]:
        """Add depth information to object detections."""
        enriched = []
        for obj in objects:
            depth_info = depth_map.get_depth_in_bbox(obj.bbox)

            enriched.append(DetectionWithDepth(
                tracking_id=obj.tracking_id,
                bbox=obj.bbox,
                confidence=obj.confidence,
                class_name=obj.class_name,
                target_category=obj.target_category,
                depth_info=depth_info,
            ))

        return enriched

    def _detect_frame_interactions(
        self,
        persons: List[DetectionWithDepth],
        objects: List[DetectionWithDepth],
        camera_id: str,
        timestamp: datetime,
    ) -> List[HOInteraction]:
        """Detect all interactions in current frame."""
        interactions = []

        # Person-Object interactions
        for person in persons:
            person_id = self._get_entity_id(camera_id, person.tracking_id, "person")

            for obj in objects:
                result = self.interaction_classifier.classify_person_object_interaction(
                    person, obj
                )

                if result is not None:
                    interaction_type, confidence, contact_region = result
                    object_id = self._get_entity_id(camera_id, obj.tracking_id, "object")

                    depth_distance = 0.0
                    if person.has_depth and obj.has_depth:
                        depth_distance = abs(
                            person.depth_info.center_depth - obj.depth_info.center_depth
                        )

                    interactions.append(HOInteraction(
                        person_id=person_id,
                        target_id=object_id,
                        interaction_type=interaction_type,
                        confidence=confidence,
                        depth_distance=depth_distance,
                        contact_region=contact_region,
                        person_bbox=person.bbox,
                        target_bbox=obj.bbox,
                        target_category=obj.target_category,
                        start_time=timestamp,
                        end_time=None,
                    ))

        # Person-Person interactions
        for i, person1 in enumerate(persons):
            person1_id = self._get_entity_id(camera_id, person1.tracking_id, "person")

            for person2 in persons[i + 1:]:
                result = self.interaction_classifier.classify_person_person_interaction(
                    person1, person2
                )

                if result is not None:
                    interaction_type, confidence, contact_region = result
                    person2_id = self._get_entity_id(camera_id, person2.tracking_id, "person")

                    depth_distance = 0.0
                    if person1.has_depth and person2.has_depth:
                        depth_distance = abs(
                            person1.depth_info.center_depth - person2.depth_info.center_depth
                        )

                    interactions.append(HOInteraction(
                        person_id=person1_id,
                        target_id=person2_id,
                        interaction_type=interaction_type,
                        confidence=confidence,
                        depth_distance=depth_distance,
                        contact_region=contact_region,
                        person_bbox=person1.bbox,
                        target_bbox=person2.bbox,
                        target_category=TargetCategory.PERSON,
                        start_time=timestamp,
                        end_time=None,
                    ))

        return interactions

    def _update_active_interactions(
        self,
        camera_id: str,
        current_interactions: List[HOInteraction],
        timestamp: datetime,
    ) -> List[HOInteraction]:
        """
        Update active interactions and return ended ones.

        Tracks ongoing interactions and detects when they end.
        """
        camera_active = self.active_interactions[camera_id]
        ended_interactions = []
        current_keys = set()

        # Update or create active interactions
        for interaction in current_interactions:
            key = (interaction.person_id, interaction.target_id or "")
            current_keys.add(key)

            if key in camera_active:
                # Update existing
                active = camera_active[key]
                active.last_seen = timestamp
                active.confidence = interaction.confidence
                active.depth_distance = interaction.depth_distance
                active.person_bbox = interaction.person_bbox
                active.target_bbox = interaction.target_bbox
                active.frame_count += 1

                # Update interaction type if confidence is higher
                if interaction.confidence > active.confidence:
                    active.interaction_type = interaction.interaction_type
                    active.contact_region = interaction.contact_region
            else:
                # New interaction
                camera_active[key] = ActiveHOInteraction(
                    camera_id=camera_id,
                    person_id=interaction.person_id,
                    target_id=interaction.target_id,
                    interaction_type=interaction.interaction_type,
                    target_category=interaction.target_category,
                    confidence=interaction.confidence,
                    depth_distance=interaction.depth_distance,
                    contact_region=interaction.contact_region,
                    person_bbox=interaction.person_bbox,
                    target_bbox=interaction.target_bbox,
                    start_time=timestamp,
                    last_seen=timestamp,
                    frame_count=1,
                )

                # Handle both enum and string values (due to use_enum_values=True)
                interaction_type_str = (
                    interaction.interaction_type.value 
                    if hasattr(interaction.interaction_type, 'value') 
                    else str(interaction.interaction_type)
                )
                target_category_str = (
                    interaction.target_category.value 
                    if hasattr(interaction.target_category, 'value') 
                    else str(interaction.target_category)
                )
                logger.info(
                    f"[{camera_id}] New HOI interaction: "
                    f"{interaction_type_str} "
                    f"({target_category_str}), "
                    f"confidence={interaction.confidence:.2f}, "
                    f"depth_distance={interaction.depth_distance:.3f}"
                )

        # Check for ended interactions
        keys_to_remove = []
        for key, active in camera_active.items():
            if key not in current_keys:
                # Check timeout
                elapsed = (timestamp - active.last_seen).total_seconds()
                if elapsed > self.inactivity_timeout:
                    # Interaction ended - only report if enough frames
                    if active.frame_count >= self.temporal_smoothing:
                        ended = active.to_hoi_interaction()
                        ended_interactions.append(ended)

                        duration = ended.duration_seconds or 0
                        # Handle both enum and string values
                        ended_type_str = (
                            ended.interaction_type.value 
                            if hasattr(ended.interaction_type, 'value') 
                            else str(ended.interaction_type)
                        )
                        ended_category_str = (
                            ended.target_category.value 
                            if hasattr(ended.target_category, 'value') 
                            else str(ended.target_category)
                        )
                        logger.info(
                            f"[{camera_id}] HOI interaction ended: "
                            f"{ended_type_str} "
                            f"({ended_category_str}), "
                            f"duration={duration:.2f}s, "
                            f"frames={active.frame_count}"
                        )

                    keys_to_remove.append(key)

        # Remove ended interactions
        for key in keys_to_remove:
            del camera_active[key]

        return ended_interactions

    def _get_entity_id(self, camera_id: str, tracking_id: int, entity_type: str) -> str:
        """Generate consistent entity ID."""
        return f"{entity_type}_{camera_id}_{tracking_id}"

    def get_active_interaction_count(self, camera_id: Optional[str] = None) -> int:
        """Get count of active interactions."""
        if camera_id:
            return len(self.active_interactions.get(camera_id, {}))
        return sum(len(v) for v in self.active_interactions.values())

    def flush_camera(self, camera_id: str, timestamp: datetime) -> List[HOInteraction]:
        """
        Flush all active interactions for a camera.

        Used when camera disconnects or service stops.
        """
        camera_active = self.active_interactions.get(camera_id, {})
        ended = []

        for key, active in camera_active.items():
            active.last_seen = timestamp
            if active.frame_count >= self.temporal_smoothing:
                ended.append(active.to_hoi_interaction())

        # Clear active interactions for this camera
        if camera_id in self.active_interactions:
            del self.active_interactions[camera_id]

        return ended

    @property
    def is_depth_available(self) -> bool:
        """Check if depth estimation is available."""
        return self.depth_estimator.is_available
