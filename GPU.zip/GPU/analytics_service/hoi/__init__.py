"""
Human-Object Interaction (HOI) detection module.

This package provides depth-aware HOI detection, replacing
traditional IoU-based engagement detection with more accurate
spatial and depth analysis.

Modules
-------
hoi_detector
    Main HOI detection orchestrator.
interaction_classifier
    Depth-aware interaction classification logic.
"""
from .hoi_detector import HOIDetector
from .interaction_classifier import InteractionClassifier

__all__ = [
    "HOIDetector",
    "InteractionClassifier",
]
