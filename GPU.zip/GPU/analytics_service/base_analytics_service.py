"""
Base Class for all the Analytics model so that everything must
run in a proper flow
"""
import asyncio
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Optional

from core.data_contracts import KafkaBaseAnalyticsEvent
from services import KafkaConsumerService, KafkaProducerService
from utils import logger


class BaseAnalyticsService(ABC):
    """
    High-performance analytics service.

    Uses a direct async processing pipeline for real-time analytics:
    Consumer → [CUSTOM_LOGIC_BLOCK] → Producer (fire-and-forget)

    No multiprocessing overhead - trackers are lightweight dict operations.

    Attributes
    ----------
    _consumer : KafkaConsumerService or None
        Async Kafka consumer for person detection events.
    _producer : KafkaProducerService or None
        Async Kafka producer for dwell events.
    _running : bool
        Service running state.
    _events_consumed : int
        Total events consumed from Kafka.
    _events_processed : int
        Total events processed (with dwell service).
    _events_published : int
        Total dwell events published to Kafka.
    """

    def __init__(self) -> None:
        """
        Initialize dwell analytics service.

        Creates empty service references and initializes statistics counters.
        """
        # Services
        self._consumer: Optional[KafkaConsumerService] = None
        self._producer: Optional[KafkaProducerService] = None

        # State
        self._running = False
        self._shutdown_event: Optional[asyncio.Event] = None

        # Statistics
        self._events_consumed = 0
        self._events_processed = 0
        self._events_published = 0
        self._start_time: Optional[datetime] = None

        # Pending publish tasks (fire-and-forget)
        self._publish_tasks: set = set()

    async def start(self) -> None:
        """
        Start all services.

        Initializes and starts Kafka consumer and producer services.
        Sets the running state to True.
        """
        logger.info("Starting Engagement Analytics Service...")

        self._shutdown_event = asyncio.Event()
        self._start_time = datetime.now()

        # Start Kafka services
        self._consumer = KafkaConsumerService()
        self._producer = KafkaProducerService()

        await self._consumer.start()
        await self._producer.start()

        self._running = True
        logger.info("Engagement Analytics Service started successfully")

    async def stop(self) -> None:
        """
        Stop all services.

        Waits for pending publish tasks to complete (with timeout),
        then stops Kafka consumer and producer services.
        """
        logger.info("Stopping Engagement Analytics Service...")
        self._running = False

        if self._shutdown_event:
            self._shutdown_event.set()

        # Wait for pending publish tasks (with timeout)
        if self._publish_tasks:
            logger.info(f"Waiting for {len(self._publish_tasks)} pending publishes...")
            done, pending = await asyncio.wait(
                self._publish_tasks,
                timeout=5.0,
                return_when=asyncio.ALL_COMPLETED
            )
            for task in pending:
                task.cancel()

        # Stop Kafka services
        if self._consumer:
            await self._consumer.stop()

        if self._producer:
            await self._producer.stop()

        logger.info(
            f"Analytics Service stopped. "
            f"Consumed: {self._events_consumed}, "
            f"Processed: {self._events_processed}, "
            f"Published: {self._events_published}"
        )

    @abstractmethod
    def fire_and_forget_publish(self, event: KafkaBaseAnalyticsEvent) -> None:
        """
        Schedule publish without blocking.

        Creates an async task for publishing and tracks it for cleanup.

        Parameters
        ----------
        event : KafkaBaseAnalyticsEvent
            Analytics event to publish to Kafka.
        """
        raise NotImplemented

    @abstractmethod
    async def publish_event(self, event: KafkaBaseAnalyticsEvent) -> None:
        """
        Publish event to Kafka.

        Parameters
        ----------
        event : KafkaBaseAnalyticsEvent
            Analytics event to publish.

        Notes
        -----
        Errors are logged but not raised to prevent blocking other publishes.
        """
        raise NotImplemented

    @abstractmethod
    async def log_stats(self) -> None:
        """
        Periodically log statistics.

        Logs consumption rate and statistics every 30 seconds.
        """
        raise NotImplemented

    @abstractmethod
    async def run(self) -> None:
        """
        Main run loop - direct async processing pipeline.

        Starts services, consumes events in batches, processes them
        through trackers, and publishes dwell events.

        Raises
        ------
        Exception
            Re-raises any unhandled exception after cleanup.
        """
        raise NotImplemented
