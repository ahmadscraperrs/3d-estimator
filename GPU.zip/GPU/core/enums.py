"""
Enums for Analytics Service.

This module contains enum definitions used throughout the application
for type-safe string values.

All enums inherit from StrEnum for string compatibility and serialization.
"""

from enum import StrEnum


class EventType(StrEnum):
    """
    Event type enumeration for detection and dwell events.

    Represents different types of events in the analytics system.

    Attributes
    ----------
    PERSON_DETECTION : str
        Person detected in frame.
    """

    # Kafka event types
    PERSON_DETECTION = "person.detection"
    PERSON_ENGAGEMENT = "person.engagement"


class LogLevel(StrEnum):
    """
    Logging Level available for monitoring.
    """
    TRACE = "TRACE"
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class FrameFormat(StrEnum):
    """
    Frame format enumeration for video frames.

    Represents different image formats for frame encoding.

    Attributes
    ----------
    JPEG : str
        JPEG image format.
    PNG : str
        PNG image format.
    """

    JPEG = "jpeg"
    PNG = "png"


class Compression(StrEnum):
    """
    Compression algorithm for frame data.

    Represents different compression algorithms used for
    encoding frame data in Kafka messages.

    Attributes
    ----------
    ZLIB : str
        Zlib compression.
    NONE : str
        No compression.
    GZIP : str
        Gzip compression.
    LZ4 : str
        LZ4 compression.
    """

    ZLIB = "zlib"
    NONE = "none"
    GZIP = "gzip"
    LZ4 = "lz4"


class CompressionType(StrEnum):
    """
    Compression type options for frame encoding.

    Represents different compression algorithm combinations
    available for encoding video frames.

    Attributes
    ----------
    JPEG : str
        JPEG compression only.
    WEBP : str
        WebP compression only.
    JPEG_ZLIB : str
        JPEG with additional zlib compression.
    WEBP_ZLIB : str
        WebP with additional zlib compression.
    """

    JPEG = "JPEG"
    WEBP = "WEBP"
    JPEG_ZLIB = "JPEG+ZLIB"
    WEBP_ZLIB = "WEBP+ZLIB"


class ServiceType(StrEnum):
    """
    Service types available for monitoring regions.

    Each service type represents a different analytics capability
    that can be enabled for a region.

    Attributes
    ----------
    ENTRY_EXIT : str
        Entry/exit counting service.
    ENGAGEMENT : str
        Engagement detection service.
    DWELL_TIME : str
        Dwell time tracking service.
    OCCUPANCY : str
        Occupancy counting service.
    """

    ENTRY_EXIT = "ENTRY/EXIT"
    ENGAGEMENT = "ENGAGEMENT"
    DWELL_TIME = "DWELL_TIME"
    OCCUPANCY = "OCCUPANCY"


class IntersectionType(StrEnum):
    """Type of intersection detected."""
    # PERSON_OBJECT = "person_object"
    # PERSON_PERSON = "person_person"
    UNKNOWN = "UNKNOWN"
    TALKING = "TALKING"
    PHYSICAL = "PHYSICAL"
    # IOU = "IOU"
    OTHER = "OTHER"


class TargetCategory(StrEnum):
    """Type of target in intersection."""
    UNKNOWN = "UNKNOWN"

    PERSON = "PERSON"
    SHELF = "SHELF"
    VEHICLE = "VEHICLE"
    SHELF_ITEM = "SHELF_ITEM"
    RACKET = "RACKET"
    TABLE_ITEM = "TABLE_ITEM"
    ELECTRONICS = "ELECTRONICS"


class InteractionType(StrEnum):
    """
    Human-Object Interaction types for depth-aware HOI detection.

    Represents different types of interactions detected between
    humans and objects using depth and spatial analysis.

    Attributes
    ----------
    HOLDING : str
        Person is holding an object (close depth, hand region).
    TOUCHING : str
        Person is physically touching an object or person.
    USING : str
        Person is actively using an object (e.g., phone, laptop).
    NEAR : str
        Person is near an object but not interacting.
    TALKING : str
        Two people are engaged in conversation.
    EXAMINING : str
        Person is looking at/examining an object.
    REACHING : str
        Person is reaching towards an object.
    UNKNOWN : str
        Interaction type could not be determined.
    """

    HOLDING = "HOLDING"
    TOUCHING = "TOUCHING"
    USING = "USING"
    NEAR = "NEAR"
    TALKING = "TALKING"
    EXAMINING = "EXAMINING"
    REACHING = "REACHING"
    UNKNOWN = "UNKNOWN"


class ContactRegion(StrEnum):
    """
    Body region involved in contact/interaction.

    Represents the part of the human body involved in an interaction.
    """

    HAND = "HAND"
    ARM = "ARM"
    BODY = "BODY"
    FACE = "FACE"
    HEAD = "HEAD"
    LEG = "LEG"
    FOOT = "FOOT"
    UNKNOWN = "UNKNOWN"
