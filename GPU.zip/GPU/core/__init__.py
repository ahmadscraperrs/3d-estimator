"""
Core module for Analytics Service.

This module provides centralized access to configuration, constants,
and core utilities used throughout the application.

Exports
-------
configs : Configurations
    Global configuration instance loaded from YAML.
Constants : class
    Constants class with all default values.
"""

from .configurations import configs
from .constants import Constants

__all__ = [
    "configs",
    "Constants",
]
