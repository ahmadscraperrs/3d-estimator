"""
Configuration loader for Analytics Service.

This module loads configuration from a YAML file and provides access
to all configurable parameters. Falls back to constants if config
file is not found or values are missing.
"""

import os
from typing import Dict, Any, Optional, List

import yaml

from .constants import Constants
from .enums import LogLevel


class Configurations:
    """
    Configuration manager that loads from YAML and falls back to constants.

    This class provides a centralized way to access all configuration
    parameters with support for dot-notation key paths and default values.

    Attributes
    ----------
    config_path : str
        Path to the configuration YAML file.
    _config_data : Dict[str, Any]
        Loaded configuration data dictionary.

    Examples
    --------
    >>> config = Configurations("config.yaml")
    >>> bootstrap = config.kafka_bootstrap_servers
    """

    def __init__(self, config_path: Optional[str] = None) -> None:
        """
        Initialize configuration.

        Parameters
        ----------
        config_path : str, optional
            Path to config YAML file. If None, uses default config file name.

        Raises
        ------
        FileNotFoundError
            If the configuration file does not exist.
        """
        self.config_path = config_path or Constants.CONFIG_FILE_NAME
        self._config_data: Dict[str, Any] = {}
        self._load_config()

    def _load_config(self) -> None:
        """
        Load configuration from YAML file.

        Raises
        ------
        FileNotFoundError
            If configuration file is not found.

        Notes
        -----
        If YAML parsing fails, falls back to empty config and uses defaults.
        """
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, 'r') as f:
                    self._config_data = yaml.safe_load(f) or {}
                print(f"Loaded configuration from {self.config_path}")
            except Exception as e:
                print(f"Failed to load config from {self.config_path}: {e}. Using default constants.")
                self._config_data = {}
        else:
            raise FileNotFoundError(
                f"Configuration file not found: {self.config_path}. "
                "Make sure the file exists."
            )

    def get(self, key_path: str, default: Any = None) -> Any:
        """
        Get configuration value using dot notation.

        Parameters
        ----------
        key_path : str
            Dot-separated path to config value (e.g., 'Kafka.BootstrapServers').
        default : Any, optional
            Default value if not found. Defaults to None.

        Returns
        -------
        Any
            Configuration value or default if not found.

        Examples
        --------
        >>> config.get('Kafka.BootstrapServers', 'localhost:9092')
        'kafka-broker:9092'
        """
        keys = key_path.split('.')
        value = self._config_data

        try:
            for key in keys:
                value = value[key]
            return value
        except (KeyError, TypeError):
            return default

    # ==================== Kafka Configuration ====================

    @property
    def kafka_bootstrap_servers(self) -> str:
        """
        Get Kafka bootstrap servers.

        Returns
        -------
        str
            Comma-separated list of Kafka broker addresses.
        """
        return self.get('Kafka.BootstrapServers', Constants.DEFAULT_BOOTSTRAP_SERVERS)

    @property
    def kafka_topic_input(self) -> str:
        """
        Get Kafka input topic for person detection events.

        Returns
        -------
        str
            Input topic name.
        """
        topics = self.get('Kafka.Topics', {})
        if isinstance(topics, dict):
            return topics.get('Input', Constants.DEFAULT_INPUT_KAFKA_TOPIC)
        return Constants.DEFAULT_INPUT_KAFKA_TOPIC

    @property
    def kafka_topic_output(self) -> str:
        """
        Get Kafka output topic for dwell events.

        Returns
        -------
        str
            Output topic name.
        """
        topics = self.get('Kafka.Topics', {})
        if isinstance(topics, dict):
            return topics.get('Output', Constants.DEFAULT_OUTPUT_KAFKA_TOPIC)
        return Constants.DEFAULT_OUTPUT_KAFKA_TOPIC

    @property
    def kafka_topic_engagement(self) -> str:
        """
        Get Kafka topic for engagement events.
        
        Uses the Output topic for engagement events.

        Returns
        -------
        str
            Engagement topic name (same as output topic).
        """
        return self.kafka_topic_output

    @property
    def kafka_consumer_group_id(self) -> str:
        """
        Get Kafka consumer group ID.

        Returns
        -------
        str
            Consumer group identifier.
        """
        return self.get('Kafka.Consumer.GroupId', Constants.DEFAULT_CONSUMER_GROUP_ID)

    @property
    def kafka_consumer_auto_offset_reset(self) -> str:
        """
        Get Kafka consumer auto offset reset policy.

        Returns
        -------
        str
            Offset reset policy ('earliest' or 'latest').
        """
        return self.get('Kafka.Consumer.AutoOffsetReset', Constants.DEFAULT_AUTO_OFFSET_RESET)

    @property
    def kafka_consumer_enable_auto_commit(self) -> bool:
        """
        Get Kafka consumer auto commit setting.

        Returns
        -------
        bool
            True if auto commit is enabled.
        """
        return Constants.ENABLE_AUTO_COMMIT

    @property
    def kafka_consumer_max_poll_interval_ms(self) -> int:
        """
        Get Kafka consumer max poll interval in milliseconds.

        Returns
        -------
        int
            Maximum time between polls before consumer is considered dead.
        """
        return int(self.get('Kafka.Consumer.MaxPollIntervalMs', Constants.MAX_POLL_INTERVAL_MS))

    @property
    def kafka_consumer_session_timeout_ms(self) -> int:
        """
        Get Kafka consumer session timeout in milliseconds.

        Returns
        -------
        int
            Session timeout for consumer group coordination.
        """
        return int(self.get('Kafka.Consumer.SessionTimeoutMs', Constants.SESSION_TIMEOUT_MS))

    @property
    def kafka_consumer_heartbeat_interval_ms(self) -> int:
        """
        Get Kafka consumer heartbeat interval in milliseconds.

        Returns
        -------
        int
            Interval between heartbeats to consumer coordinator.
        """
        return int(self.get('Kafka.Consumer.HeartbeatIntervalMs', Constants.HEARTBEAT_INTERVAL_MS))

    # ==================== Processing Configuration ====================

    """
    Your project configurations must be in this section
    """

    # ==================== Engagement Configuration ====================

    @property
    def model_path(self) -> str:
        """
        Get YOLO model path.

        Returns
        -------
        str
            Path to YOLO model file.
        """
        return self.get('Model.Path', getattr(Constants, 'DEFAULT_MODEL_PATH', 'yolov8n.pt'))

    @property
    def model_conf(self) -> float:
        """
        Get model confidence threshold.

        Returns
        -------
        float
            Confidence threshold (0.0 to 1.0).
        """
        return float(self.get('Model.Conf', getattr(Constants, 'DEFAULT_MODEL_CONF', 0.3)))

    @property
    def person_class_id(self) -> int:
        """
        Get person class ID for YOLO.

        Returns
        -------
        int
            Person class ID (default: 0 for COCO).
        """
        return int(self.get('Model.PersonClassId', getattr(Constants, 'DEFAULT_PERSON_CLASS_ID', 0)))

    @property
    def object_classes(self) -> List[int]:
        """
        Get object class IDs for YOLO.

        Returns
        -------
        List[int]
            List of object class IDs.
        """
        default_classes = getattr(Constants, 'DEFAULT_OBJECT_CLASSES', list(range(1, 80)))
        classes = self.get('Model.ObjectClasses', default_classes)
        return list(classes) if isinstance(classes, (list, tuple)) else default_classes

    @property
    def enable_engagement_by_default(self) -> bool:
        """
        Get enable engagement by default flag.
        
        If True, engagement detection will run even if ENGAGEMENT service
        is not explicitly in the event services list.

        Returns
        -------
        bool
            True if engagement should be enabled by default.
        """
        return bool(self.get('Engagement.EnableByDefault', True))

    @property
    def iou_threshold(self) -> float:
        """
        Get IoU threshold for engagement detection.

        Returns
        -------
        float
            IoU threshold (0.0 to 1.0).
        """
        return float(self.get('Engagement.IouThreshold', getattr(Constants, 'DEFAULT_IOU_THRESHOLD', 0.1)))

    @property
    def enable_talking_check(self) -> bool:
        """
        Get enable talking check flag.

        Returns
        -------
        bool
            True if talking check is enabled.
        """
        return bool(self.get('Engagement.EnableTalkingCheck', getattr(Constants, 'DEFAULT_ENABLE_TALKING_CHECK', True)))

    @property
    def publish_talking_without_iou(self) -> bool:
        """
        Get publish talking without IoU flag.

        Returns
        -------
        bool
            True if talking-only events should be published.
        """
        return bool(self.get('Engagement.PublishTalkingWithoutIou', getattr(Constants, 'DEFAULT_PUBLISH_TALKING_WITHOUT_IOU', False)))

    @property
    def min_talking_distance_ratio(self) -> float:
        """
        Get minimum talking distance ratio.

        Returns
        -------
        float
            Minimum talking distance ratio.
        """
        return float(self.get('Engagement.MinTalkingDistanceRatio', getattr(Constants, 'DEFAULT_MIN_TALKING_DISTANCE_RATIO', 0.3)))

    @property
    def max_talking_distance_ratio(self) -> float:
        """
        Get maximum talking distance ratio.

        Returns
        -------
        float
            Maximum talking distance ratio.
        """
        return float(self.get('Engagement.MaxTalkingDistanceRatio', getattr(Constants, 'DEFAULT_MAX_TALKING_DISTANCE_RATIO', 2.0)))

    @property
    def min_talking_separation_ratio(self) -> float:
        """
        Get minimum talking separation ratio.

        Returns
        -------
        float
            Minimum talking separation ratio.
        """
        return float(self.get('Engagement.MinTalkingSeparationRatio', getattr(Constants, 'DEFAULT_MIN_TALKING_SEPARATION_RATIO', 0.05)))

    @property
    def min_aspect_ratio(self) -> float:
        """
        Get minimum aspect ratio for talking detection.

        Returns
        -------
        float
            Minimum aspect ratio.
        """
        return float(self.get('Engagement.MinAspectRatio', getattr(Constants, 'DEFAULT_MIN_ASPECT_RATIO', 1.2)))

    @property
    def max_vertical_diff_ratio(self) -> float:
        """
        Get maximum vertical difference ratio.

        Returns
        -------
        float
            Maximum vertical difference ratio.
        """
        return float(self.get('Engagement.MaxVerticalDiffRatio', getattr(Constants, 'DEFAULT_MAX_VERTICAL_DIFF_RATIO', 1.5)))

    @property
    def min_horizontal_diff_ratio(self) -> float:
        """
        Get minimum horizontal difference ratio.

        Returns
        -------
        float
            Minimum horizontal difference ratio.
        """
        return float(self.get('Engagement.MinHorizontalDiffRatio', getattr(Constants, 'DEFAULT_MIN_HORIZONTAL_DIFF_RATIO', 0.5)))

    @property
    def max_horizontal_diff_ratio(self) -> float:
        """
        Get maximum horizontal difference ratio.

        Returns
        -------
        float
            Maximum horizontal difference ratio.
        """
        return float(self.get('Engagement.MaxHorizontalDiffRatio', getattr(Constants, 'DEFAULT_MAX_HORIZONTAL_DIFF_RATIO', 3.0)))

    @property
    def engagement_inactivity_timeout_seconds(self) -> float:
        """
        Get engagement inactivity timeout in seconds.

        This value controls how long to wait after an engagement was last seen
        before considering it ended. Falls back to Constants.DEFAULT_ENGAGEMENT_INACTIVITY_TIMEOUT.
        """
        return float(self.get('Engagement.InactivityTimeoutSeconds', getattr(Constants, 'DEFAULT_ENGAGEMENT_INACTIVITY_TIMEOUT', 1.0)))

    # ==================== HOI Configuration ====================

    @property
    def hoi_enabled(self) -> bool:
        """
        Check if HOI-based detection is enabled.

        Returns
        -------
        bool
            True if HOI detection should be used instead of IoU-based.
        """
        return bool(self.get('HOI.Enabled', True))

    @property
    def hoi_depth_model_variant(self) -> str:
        """
        Get depth model variant for HOI detection.

        Returns
        -------
        str
            Depth model variant ('small', 'base', 'large').
        """
        return str(self.get('HOI.DepthModel.Variant', 'small'))

    @property
    def hoi_depth_model_device(self) -> str:
        """
        Get device for depth model inference.

        Returns
        -------
        str
            Device ('auto', 'cuda', 'cpu').
        """
        return str(self.get('HOI.DepthModel.Device', 'auto'))

    @property
    def hoi_depth_max_depth(self) -> float:
        """
        Get maximum depth value for metric depth.

        Returns
        -------
        float
            Maximum depth in meters.
        """
        return float(self.get('HOI.DepthModel.MaxDepth', 20.0))

    @property
    def hoi_depth_checkpoint_path(self) -> Optional[str]:
        """
        Get custom checkpoint path for depth model.

        Returns
        -------
        Optional[str]
            Path to checkpoint or None for default.
        """
        return self.get('HOI.DepthModel.CheckpointPath', None)

    @property
    def hoi_depth_proximity_threshold(self) -> float:
        """
        Get depth proximity threshold for physical interaction.

        Returns
        -------
        float
            Maximum depth difference for physical interaction (0-1).
        """
        return float(self.get('HOI.InteractionThresholds.DepthProximity', 0.15))

    @property
    def hoi_near_threshold(self) -> float:
        """
        Get near threshold for HOI detection.

        Returns
        -------
        float
            Maximum depth difference for 'near' classification.
        """
        return float(self.get('HOI.InteractionThresholds.NearThreshold', 0.3))

    @property
    def hoi_min_confidence(self) -> float:
        """
        Get minimum confidence threshold for HOI interactions.

        Returns
        -------
        float
            Minimum confidence to report interaction.
        """
        return float(self.get('HOI.InteractionThresholds.MinConfidence', 0.5))

    @property
    def hoi_spatial_overlap_threshold(self) -> float:
        """
        Get spatial overlap threshold for HOI detection.

        Returns
        -------
        float
            Minimum 2D overlap ratio for interaction.
        """
        return float(self.get('HOI.InteractionThresholds.SpatialOverlap', 0.1))

    @property
    def hoi_talking_distance_ratio(self) -> float:
        """
        Get talking distance ratio for person-person interaction.

        Returns
        -------
        float
            Maximum distance ratio for talking detection.
        """
        return float(self.get('HOI.InteractionThresholds.TalkingDistanceRatio', 2.0))

    @property
    def hoi_temporal_smoothing_frames(self) -> int:
        """
        Get temporal smoothing frames for HOI detection.

        Returns
        -------
        int
            Number of frames for temporal smoothing.
        """
        return int(self.get('HOI.Temporal.SmoothingFrames', 3))

    @property
    def hoi_inactivity_timeout(self) -> float:
        """
        Get inactivity timeout for HOI interactions.

        Returns
        -------
        float
            Seconds before considering interaction ended.
        """
        return float(self.get('HOI.Temporal.InactivityTimeout', 1.0))

    # ==================== Logging Configuration ====================

    @property
    def log_level(self) -> LogLevel:
        """
        Get logging level.

        Returns
        -------
        str
            Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL).
        """
        value = self.get('Logging.Level', Constants.DEFAULT_LOG_LEVEL)
        try:
            value = LogLevel(value)
        except ValueError:
            value = Constants.DEFAULT_LOG_LEVEL
        return value

    @property
    def log_file(self) -> str:
        """
        Get path to log file.

        Returns
        -------
        str
            Path to log file with optional time placeholder.
        """
        return self.get('Logging.File', Constants.DEFAULT_LOG_FILE)


# Global config instance - initialized on module import
_config_instance: Optional[Configurations] = None


def _initialize_config(config_path: Optional[str] = None) -> Configurations:
    """
    Initialize the global config instance.

    Parameters
    ----------
    config_path : str, optional
        Path to configuration file.

    Returns
    -------
    Configurations
        Initialized configuration instance.
    """
    global _config_instance
    if _config_instance is None:
        _config_instance = Configurations(config_path)
    return _config_instance


# Initialize configs on module import
configs = _initialize_config(Constants.CONFIG_FILE_NAME)
