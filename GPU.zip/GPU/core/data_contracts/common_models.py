"""
Common Pydantic models for Analytics Service.

This module contains common models like Point, Line, BoundingBox,
and Region that are used across multiple modules.
"""

from typing import Optional, List

from pydantic import Field, computed_field

from .base_app_model import BaseAppModel
from ..enums import ServiceType


class Point(BaseAppModel):
    """
    A 2D point coordinate.

    Attributes
    ----------
    x : float
        X coordinate value.
    y : float
        Y coordinate value.

    Examples
    --------
    >>> point = Point(x=100.0, y=200.0)
    >>> print(point.x, point.y)
    100.0 200.0
    """

    x: float = Field(..., description="X coordinate.", examples=[100.0])
    y: float = Field(..., description="Y coordinate.", examples=[200.0])


class Line(BaseAppModel):
    """
    A line segment defined by start and end points.

    Attributes
    ----------
    point1 : Point
        Start point of the line segment.
    point2 : Point
        End point of the line segment.

    Examples
    --------
    >>> line = Line(
    ...     point1=Point(x=0, y=0),
    ...     point2=Point(x=100, y=100)
    ... )
    """

    point1: Point = Field(..., description="Start point of the line.")
    point2: Point = Field(..., description="End point of the line.")


class BoundingBox(BaseAppModel):
    """
    A bounding box defined by two corner points.

    The bounding box is defined by top-left and bottom-right corners,
    with a computed center point.

    Attributes
    ----------
    top_left : Point
        Top-left corner coordinates (x1, y1).
    bottom_right : Point
        Bottom-right corner coordinates (x2, y2).
    center : Point
        Center point, computed automatically.

    Examples
    --------
    >>> bbox = BoundingBox(
    ...     top_left=Point(x=100, y=100),
    ...     bottom_right=Point(x=200, y=200)
    ... )
    >>> print(bbox.center)
    Point(x=150.0, y=150.0)

    >>> bbox = BoundingBox.from_list([100, 100, 200, 200])
    """

    top_left: Point = Field(..., description="Top-left corner (x1, y1)")
    bottom_right: Point = Field(..., description="Bottom-right corner (x2, y2)")

    @computed_field
    @property
    def center(self) -> Point:
        """
        Calculate center point from top_left and bottom_right.

        Returns
        -------
        Point
            Center point of the bounding box.
        """
        return Point(
            x=(self.top_left.x + self.bottom_right.x) / 2,
            y=(self.top_left.y + self.bottom_right.y) / 2,
        )

    @classmethod
    def from_list(cls, bbox: list) -> "BoundingBox":
        """
        Create BoundingBox from coordinate list.

        Parameters
        ----------
        bbox : list
            Bounding box as [x1, y1, x2, y2].

        Returns
        -------
        BoundingBox
            New BoundingBox instance.

        Examples
        --------
        >>> bbox = BoundingBox.from_list([100, 200, 300, 400])
        """
        return cls(
            top_left=Point(x=bbox[0], y=bbox[1]),
            bottom_right=Point(x=bbox[2], y=bbox[3]),
        )


class Region(BaseAppModel):
    """
    A monitored region within a camera's field of view.

    Regions define areas where specific analytics services
    are enabled, such as dwell time tracking or occupancy counting.

    Attributes
    ----------
    tag : str
      Label identifying the purpose of the region.
    services : List[ServiceType]
      List of analytics services enabled for this region.
    polygon : List[Point], optional
      Polygon coordinates defining the region boundary.
    lines : List[Line], optional
      Line segments for footfall counting.

    Examples
    --------
    >>> from core.enums import ServiceType
    >>> region = Region(
    ...     tag="entrance",
    ...     services=[ServiceType.DWELL_TIME, ServiceType.ENTRY_EXIT],
    ...     polygon=[
    ...         Point(x=0, y=0),
    ...         Point(x=100, y=0),
    ...         Point(x=100, y=100),
    ...         Point(x=0, y=100),
    ...     ]
    ... )
    >>> region.has_dwell_service()
    True
    """

    tag: str = Field(
        ...,
        description="Label identifying the purpose of the region.",
        examples=["entry_exit", "sitting_area", "working"],
    )
    services: List[ServiceType] = Field(
        ...,
        description="List of analytics services enabled for this region.",
        examples=[[m for m in ServiceType]],
    )
    polygon: Optional[List[Point]] = Field(
        None,
        description="Polygon coordinates defining the region boundary.",
    )
    lines: Optional[List[Line]] = Field(
        None,
        description="Line segments for footfall counting.",
    )
