"""
Depth-aware interaction classification for HOI detection.

This module classifies interactions between persons and objects/persons
using depth information, spatial relations, and heuristics.

Supports both static interactions (HOLDING, TOUCHING, etc.) and
temporal interactions (PICKING, DROPPING, CARRYING, etc.).
"""
import math
from typing import List, Optional, Tuple, TYPE_CHECKING

import numpy as np

from core.data_contracts import (
    BoundingBox,
    DepthInfo,
    HOInteraction,
    DetectionWithDepth,
)
from core.enums import InteractionType, ContactRegion, TargetCategory
from utils import logger

if TYPE_CHECKING:
    from .motion_tracker import MotionTracker, MotionState


class InteractionClassifier:
    """
    Classifies human-object and human-human interactions using depth.

    Uses depth proximity, spatial relations, and bounding box analysis
    to determine interaction types with higher accuracy than IoU alone.

    Attributes
    ----------
    depth_proximity_threshold : float
        Max depth difference for physical interaction (default 0.15).
    near_threshold : float
        Max depth difference for "near" classification (default 0.3).
    min_confidence : float
        Minimum confidence threshold for interactions (default 0.5).
    spatial_overlap_threshold : float
        Minimum 2D overlap ratio for interaction (default 0.1).
    talking_distance_ratio : float
        Max distance ratio for talking detection (default 2.0).
    """

    def __init__(
        self,
        depth_proximity_threshold: float = 0.15,
        near_threshold: float = 0.3,
        min_confidence: float = 0.5,
        spatial_overlap_threshold: float = 0.1,
        talking_distance_ratio: float = 2.0,
    ) -> None:
        """
        Initialize the interaction classifier.

        Parameters
        ----------
        depth_proximity_threshold : float
            Maximum depth difference for close interaction.
        near_threshold : float
            Maximum depth difference for near classification.
        min_confidence : float
            Minimum confidence to report an interaction.
        spatial_overlap_threshold : float
            Minimum 2D bbox overlap ratio.
        talking_distance_ratio : float
            Maximum distance/size ratio for talking detection.
        """
        self.depth_proximity_threshold = depth_proximity_threshold
        self.near_threshold = near_threshold
        self.min_confidence = min_confidence
        self.spatial_overlap_threshold = spatial_overlap_threshold
        self.talking_distance_ratio = talking_distance_ratio

    def classify_person_object_interaction(
        self,
        person: DetectionWithDepth,
        obj: DetectionWithDepth,
    ) -> Optional[Tuple[InteractionType, float, ContactRegion]]:
        """
        Classify interaction between a person and an object.

        Parameters
        ----------
        person : DetectionWithDepth
            Person detection with depth info.
        obj : DetectionWithDepth
            Object detection with depth info.

        Returns
        -------
        Optional[Tuple[InteractionType, float, ContactRegion]]
            Tuple of (interaction_type, confidence, contact_region) or None.
        """
        if not person.has_depth or not obj.has_depth:
            # Fall back to spatial-only analysis
            return self._classify_spatial_only(person, obj)

        # Calculate depth distance
        depth_distance = abs(
            person.depth_info.center_depth - obj.depth_info.center_depth
        )

        # Calculate spatial metrics
        spatial_distance = self._calculate_spatial_distance(person.bbox, obj.bbox)
        overlap_ratio = self._calculate_overlap_ratio(person.bbox, obj.bbox)

        # Determine contact region based on relative positions
        contact_region = self._estimate_contact_region(person.bbox, obj.bbox)

        # Calculate base confidence from overlap and depth
        confidence = self._calculate_confidence(
            depth_distance, spatial_distance, overlap_ratio, person.bbox
        )

        if confidence < self.min_confidence:
            return None

        # Classify interaction type
        interaction_type = self._determine_interaction_type(
            depth_distance=depth_distance,
            overlap_ratio=overlap_ratio,
            spatial_distance=spatial_distance,
            contact_region=contact_region,
            target_category=obj.target_category,
            person_bbox=person.bbox,
            obj_bbox=obj.bbox,
        )

        if interaction_type == InteractionType.UNKNOWN:
            return None

        return (interaction_type, confidence, contact_region)

    def classify_person_person_interaction(
        self,
        person1: DetectionWithDepth,
        person2: DetectionWithDepth,
    ) -> Optional[Tuple[InteractionType, float, ContactRegion]]:
        """
        Classify interaction between two people.

        Parameters
        ----------
        person1 : DetectionWithDepth
            First person detection.
        person2 : DetectionWithDepth
            Second person detection.

        Returns
        -------
        Optional[Tuple[InteractionType, float, ContactRegion]]
            Tuple of (interaction_type, confidence, contact_region) or None.
        """
        # Calculate depth distance
        if person1.has_depth and person2.has_depth:
            depth_distance = abs(
                person1.depth_info.center_depth - person2.depth_info.center_depth
            )
        else:
            depth_distance = 0.0  # Assume same depth if not available

        # Calculate spatial metrics
        spatial_distance = self._calculate_spatial_distance(person1.bbox, person2.bbox)
        overlap_ratio = self._calculate_overlap_ratio(person1.bbox, person2.bbox)

        # Check for talking condition
        is_talking = self._check_talking_condition(
            person1.bbox, person2.bbox, depth_distance
        )

        # Check for physical contact
        is_physical = (
            depth_distance <= self.depth_proximity_threshold
            and overlap_ratio >= self.spatial_overlap_threshold
        )

        # Calculate confidence
        confidence = self._calculate_person_person_confidence(
            depth_distance, spatial_distance, overlap_ratio, is_talking
        )

        if confidence < self.min_confidence:
            return None

        # Determine interaction type
        if is_talking and is_physical:
            interaction_type = InteractionType.TOUCHING
            contact_region = ContactRegion.BODY
        elif is_talking:
            interaction_type = InteractionType.TALKING
            contact_region = ContactRegion.FACE
        elif is_physical:
            interaction_type = InteractionType.TOUCHING
            contact_region = ContactRegion.BODY
        elif depth_distance <= self.near_threshold:
            interaction_type = InteractionType.NEAR
            contact_region = ContactRegion.UNKNOWN
        else:
            return None

        return (interaction_type, confidence, contact_region)

    def _classify_spatial_only(
        self,
        person: DetectionWithDepth,
        obj: DetectionWithDepth,
    ) -> Optional[Tuple[InteractionType, float, ContactRegion]]:
        """Fallback classification using only spatial information."""
        overlap_ratio = self._calculate_overlap_ratio(person.bbox, obj.bbox)
        spatial_distance = self._calculate_spatial_distance(person.bbox, obj.bbox)
        contact_region = self._estimate_contact_region(person.bbox, obj.bbox)

        if overlap_ratio < self.spatial_overlap_threshold:
            return None

        # Use overlap for confidence without depth
        confidence = min(1.0, overlap_ratio * 2)

        if confidence < self.min_confidence:
            return None

        if overlap_ratio >= 0.3:
            interaction_type = InteractionType.TOUCHING
        elif overlap_ratio >= 0.1:
            interaction_type = InteractionType.NEAR
        else:
            return None

        return (interaction_type, confidence, contact_region)

    def _determine_interaction_type(
        self,
        depth_distance: float,
        overlap_ratio: float,
        spatial_distance: float,
        contact_region: ContactRegion,
        target_category: TargetCategory,
        person_bbox: BoundingBox,
        obj_bbox: BoundingBox,
    ) -> InteractionType:
        """Determine the specific interaction type."""
        # Close depth + overlap = physical interaction
        if depth_distance <= self.depth_proximity_threshold:
            if overlap_ratio >= 0.3:
                # Significant overlap - likely holding or using
                if contact_region == ContactRegion.HAND:
                    if target_category in [TargetCategory.ELECTRONICS, TargetCategory.SHELF_ITEM]:
                        return InteractionType.USING
                    return InteractionType.HOLDING
                return InteractionType.TOUCHING

            elif overlap_ratio >= self.spatial_overlap_threshold:
                # Some overlap - touching or examining
                if contact_region == ContactRegion.FACE:
                    return InteractionType.EXAMINING
                return InteractionType.TOUCHING

        # Medium depth distance
        if depth_distance <= self.near_threshold:
            if overlap_ratio >= self.spatial_overlap_threshold:
                return InteractionType.REACHING
            # Check if person is looking at object (face region)
            if contact_region == ContactRegion.FACE:
                return InteractionType.EXAMINING
            return InteractionType.NEAR

        return InteractionType.UNKNOWN

    def _calculate_spatial_distance(
        self, bbox1: BoundingBox, bbox2: BoundingBox
    ) -> float:
        """Calculate 2D Euclidean distance between bbox centers."""
        dx = bbox1.center.x - bbox2.center.x
        dy = bbox1.center.y - bbox2.center.y
        return math.sqrt(dx * dx + dy * dy)

    def _calculate_overlap_ratio(
        self, bbox1: BoundingBox, bbox2: BoundingBox
    ) -> float:
        """Calculate IoU-like overlap ratio between two bboxes."""
        x1_min, y1_min = bbox1.top_left.x, bbox1.top_left.y
        x1_max, y1_max = bbox1.bottom_right.x, bbox1.bottom_right.y
        x2_min, y2_min = bbox2.top_left.x, bbox2.top_left.y
        x2_max, y2_max = bbox2.bottom_right.x, bbox2.bottom_right.y

        # Intersection
        inter_x_min = max(x1_min, x2_min)
        inter_y_min = max(y1_min, y2_min)
        inter_x_max = min(x1_max, x2_max)
        inter_y_max = min(y1_max, y2_max)

        if inter_x_max < inter_x_min or inter_y_max < inter_y_min:
            return 0.0

        inter_area = (inter_x_max - inter_x_min) * (inter_y_max - inter_y_min)
        area1 = max(0.0, (x1_max - x1_min)) * max(0.0, (y1_max - y1_min))
        area2 = max(0.0, (x2_max - x2_min)) * max(0.0, (y2_max - y2_min))
        union_area = area1 + area2 - inter_area

        return inter_area / union_area if union_area > 0 else 0.0

    def _estimate_contact_region(
        self, person_bbox: BoundingBox, obj_bbox: BoundingBox
    ) -> ContactRegion:
        """
        Estimate which body region is in contact based on positions.

        Uses vertical position of object relative to person bbox.
        """
        person_height = person_bbox.bottom_right.y - person_bbox.top_left.y
        if person_height <= 0:
            return ContactRegion.UNKNOWN

        obj_center_y = obj_bbox.center.y
        person_top = person_bbox.top_left.y
        person_bottom = person_bbox.bottom_right.y

        # Relative vertical position (0 = top, 1 = bottom)
        relative_y = (obj_center_y - person_top) / person_height

        if relative_y < 0.15:
            return ContactRegion.HEAD
        elif relative_y < 0.35:
            return ContactRegion.FACE
        elif relative_y < 0.55:
            return ContactRegion.ARM  # Upper body / arms
        elif relative_y < 0.75:
            return ContactRegion.HAND  # Waist / hands level
        elif relative_y < 0.9:
            return ContactRegion.LEG
        else:
            return ContactRegion.FOOT

    def _calculate_confidence(
        self,
        depth_distance: float,
        spatial_distance: float,
        overlap_ratio: float,
        person_bbox: BoundingBox,
    ) -> float:
        """Calculate overall interaction confidence."""
        # Depth confidence: closer = higher
        depth_conf = max(0.0, 1.0 - (depth_distance / self.near_threshold))

        # Overlap confidence
        overlap_conf = min(1.0, overlap_ratio * 3)

        # Spatial confidence based on person size
        person_size = math.sqrt(
            (person_bbox.bottom_right.x - person_bbox.top_left.x) *
            (person_bbox.bottom_right.y - person_bbox.top_left.y)
        )
        if person_size > 0:
            distance_ratio = spatial_distance / person_size
            spatial_conf = max(0.0, 1.0 - (distance_ratio / 2.0))
        else:
            spatial_conf = 0.5

        # Weighted combination
        confidence = (depth_conf * 0.4 + overlap_conf * 0.4 + spatial_conf * 0.2)
        return min(1.0, max(0.0, confidence))

    def _calculate_person_person_confidence(
        self,
        depth_distance: float,
        spatial_distance: float,
        overlap_ratio: float,
        is_talking: bool,
    ) -> float:
        """Calculate confidence for person-person interaction."""
        depth_conf = max(0.0, 1.0 - (depth_distance / self.near_threshold))
        overlap_conf = min(1.0, overlap_ratio * 2)

        base_conf = depth_conf * 0.5 + overlap_conf * 0.5

        # Boost confidence if talking detected
        if is_talking:
            base_conf = min(1.0, base_conf + 0.2)

        return base_conf

    def _check_talking_condition(
        self,
        bbox1: BoundingBox,
        bbox2: BoundingBox,
        depth_distance: float,
    ) -> bool:
        """
        Check if two people are likely talking.

        Uses face-level alignment, similar height, and reasonable distance.
        """
        # Must be at similar depth
        if depth_distance > self.near_threshold:
            return False

        # Calculate heights
        h1 = bbox1.bottom_right.y - bbox1.top_left.y
        h2 = bbox2.bottom_right.y - bbox2.top_left.y

        # Check similar height (within 50%)
        if h1 <= 0 or h2 <= 0:
            return False
        height_ratio = min(h1, h2) / max(h1, h2)
        if height_ratio < 0.5:
            return False

        # Check vertical alignment (face level)
        face_y1 = bbox1.top_left.y + h1 * 0.25  # Approximate face level
        face_y2 = bbox2.top_left.y + h2 * 0.25
        vertical_diff = abs(face_y1 - face_y2)
        avg_height = (h1 + h2) / 2
        if vertical_diff > avg_height * 0.5:
            return False

        # Check horizontal distance (not too far, not overlapping)
        spatial_distance = self._calculate_spatial_distance(bbox1, bbox2)
        if spatial_distance > avg_height * self.talking_distance_ratio:
            return False

        return True

    # ========================================================================
    # TEMPORAL / MOTION-BASED INTERACTIONS
    # ========================================================================

    def classify_temporal_interaction(
        self,
        person: DetectionWithDepth,
        obj: DetectionWithDepth,
        motion_tracker: "MotionTracker",
        camera_id: str,
        current_interaction: Optional[InteractionType],
    ) -> Optional[Tuple[InteractionType, float, ContactRegion]]:
        """
        Classify temporal/motion-based interactions like PICKING, DROPPING.

        Parameters
        ----------
        person : DetectionWithDepth
            Person detection with depth info.
        obj : DetectionWithDepth
            Object detection with depth info.
        motion_tracker : MotionTracker
            Motion tracker with position history.
        camera_id : str
            Camera identifier.
        current_interaction : Optional[InteractionType]
            Current static interaction type (e.g., HOLDING).

        Returns
        -------
        Optional[Tuple[InteractionType, float, ContactRegion]]
            Tuple of (interaction_type, confidence, contact_region) or None.
        """
        person_id = person.tracking_id
        object_id = obj.tracking_id

        # Determine if currently holding
        is_holding = current_interaction == InteractionType.HOLDING

        # Check for PICKING
        if motion_tracker.detect_picking(camera_id, person_id, object_id, is_holding):
            contact_region = self._estimate_contact_region(person.bbox, obj.bbox)
            return (InteractionType.PICKING, 0.85, contact_region)

        # Check for DROPPING
        if motion_tracker.detect_dropping(camera_id, person_id, object_id, is_holding):
            contact_region = self._estimate_contact_region(person.bbox, obj.bbox)
            return (InteractionType.DROPPING, 0.85, contact_region)

        # Check for PLACING
        if motion_tracker.detect_placing(camera_id, person_id, object_id, is_holding):
            contact_region = self._estimate_contact_region(person.bbox, obj.bbox)
            return (InteractionType.PLACING, 0.80, contact_region)

        # Check for CARRYING (holding + person moving)
        if is_holding and motion_tracker.detect_carrying(camera_id, person_id, True):
            contact_region = self._estimate_contact_region(person.bbox, obj.bbox)
            return (InteractionType.CARRYING, 0.90, contact_region)

        return None

    # ========================================================================
    # GROUP INTERACTIONS
    # ========================================================================

    def classify_group_interaction(
        self,
        persons: List[DetectionWithDepth],
        motion_tracker: "MotionTracker",
        camera_id: str,
        proximity_threshold: float = 200.0,
    ) -> Optional[Tuple[InteractionType, float, List[int]]]:
        """
        Classify group interactions like STANDING_TOGETHER, WALKING_TOGETHER, QUEUEING.

        Parameters
        ----------
        persons : List[DetectionWithDepth]
            List of person detections.
        motion_tracker : MotionTracker
            Motion tracker with position history.
        camera_id : str
            Camera identifier.
        proximity_threshold : float
            Maximum distance between people to be considered a group.

        Returns
        -------
        Optional[Tuple[InteractionType, float, List[int]]]
            Tuple of (interaction_type, confidence, person_ids) or None.
        """
        if len(persons) < 2:
            return None

        # Find groups of nearby people
        groups = self._find_proximity_groups(persons, proximity_threshold)

        for group in groups:
            if len(group) < 2:
                continue

            group_ids = [p.tracking_id for p in group]

            # Check if all are stationary -> STANDING_TOGETHER
            all_stationary = all(
                motion_tracker.is_person_stationary(camera_id, p.tracking_id)
                for p in group
            )

            # Check if all are moving -> WALKING_TOGETHER
            all_moving = all(
                not motion_tracker.is_person_stationary(camera_id, p.tracking_id)
                for p in group
            )

            # Check for queue formation (linear arrangement)
            is_queue = self._check_queue_formation(group)

            if is_queue and all_stationary:
                return (InteractionType.QUEUEING, 0.80, group_ids)
            elif all_stationary:
                return (InteractionType.STANDING_TOGETHER, 0.75, group_ids)
            elif all_moving:
                return (InteractionType.WALKING_TOGETHER, 0.70, group_ids)

        return None

    def _find_proximity_groups(
        self,
        persons: List[DetectionWithDepth],
        threshold: float,
    ) -> List[List[DetectionWithDepth]]:
        """Find groups of people within proximity threshold."""
        if not persons:
            return []

        # Simple clustering: find connected components
        n = len(persons)
        visited = [False] * n
        groups = []

        def dfs(idx: int, group: List[DetectionWithDepth]) -> None:
            visited[idx] = True
            group.append(persons[idx])
            for j in range(n):
                if not visited[j]:
                    dist = self._calculate_spatial_distance(
                        persons[idx].bbox, persons[j].bbox
                    )
                    if dist < threshold:
                        dfs(j, group)

        for i in range(n):
            if not visited[i]:
                group: List[DetectionWithDepth] = []
                dfs(i, group)
                if len(group) >= 2:
                    groups.append(group)

        return groups

    def _check_queue_formation(
        self,
        persons: List[DetectionWithDepth],
        linearity_threshold: float = 0.8,
    ) -> bool:
        """
        Check if people are arranged in a queue (linear formation).

        Uses linear regression to check alignment.
        """
        if len(persons) < 3:
            return False

        # Get center points
        points = [(p.bbox.center.x, p.bbox.center.y) for p in persons]
        xs = [p[0] for p in points]
        ys = [p[1] for p in points]

        # Check variance in x vs y to determine orientation
        var_x = np.var(xs) if len(xs) > 1 else 0
        var_y = np.var(ys) if len(ys) > 1 else 0

        # If one dimension has much lower variance, it's more linear
        if var_x > 0 and var_y > 0:
            ratio = min(var_x, var_y) / max(var_x, var_y)
            return ratio < (1 - linearity_threshold)

        return True  # If one variance is 0, perfectly aligned

    # ========================================================================
    # POSTURE INTERACTIONS
    # ========================================================================

    def classify_posture_interaction(
        self,
        person: DetectionWithDepth,
        nearby_furniture: Optional[DetectionWithDepth] = None,
        sitting_threshold: float = 1.6,
        crouching_threshold: float = 1.2,
        bending_threshold: float = 1.5,
    ) -> Optional[Tuple[InteractionType, float, ContactRegion]]:
        """
        Classify posture-based interactions like SITTING_ON, CROUCHING, BENDING.

        Uses bounding box aspect ratio to estimate posture.
        NOTE: Without pose estimation, this can have false positives.

        Parameters
        ----------
        person : DetectionWithDepth
            Person detection with depth info.
        nearby_furniture : Optional[DetectionWithDepth]
            Nearby furniture (chair, couch, etc.) if any.
        sitting_threshold : float
            Max aspect ratio for SITTING_ON (default 1.6).
        crouching_threshold : float
            Max aspect ratio for CROUCHING (default 1.2).
        bending_threshold : float
            Max aspect ratio for BENDING (default 1.5).

        Returns
        -------
        Optional[Tuple[InteractionType, float, ContactRegion]]
            Tuple of (interaction_type, confidence, contact_region) or None.
        """
        bbox = person.bbox
        width = bbox.bottom_right.x - bbox.top_left.x
        height = bbox.bottom_right.y - bbox.top_left.y

        if width <= 0 or height <= 0:
            return None

        aspect_ratio = height / width

        # Normal standing person has aspect ratio ~2.0-3.5
        # Sitting person has aspect ratio ~1.0-1.6
        # Crouching person has aspect ratio ~0.8-1.2
        # Bending person has aspect ratio ~1.2-1.5 (wider stance)

        # Check for SITTING_ON (near furniture + low aspect ratio)
        if nearby_furniture is not None:
            furniture_category = nearby_furniture.target_category
            if furniture_category in [TargetCategory.CHAIR, TargetCategory.COUCH, TargetCategory.BED]:
                overlap = self._calculate_overlap_ratio(bbox, nearby_furniture.bbox)
                if overlap > 0.1 and aspect_ratio < sitting_threshold:
                    return (InteractionType.SITTING_ON, 0.75, ContactRegion.BODY)

        # Check for CROUCHING (very low aspect ratio, squatting)
        # Must be significantly squat to trigger
        if aspect_ratio < crouching_threshold:
            return (InteractionType.CROUCHING, 0.70, ContactRegion.BODY)

        # Check for BENDING (medium-low aspect ratio)
        # Only if clearly not standing normally
        if aspect_ratio < bending_threshold:
            return (InteractionType.BENDING, 0.65, ContactRegion.BODY)

        return None

    # ========================================================================
    # RETAIL ANALYTICS
    # ========================================================================

    def classify_browsing(
        self,
        person: DetectionWithDepth,
        examined_objects: List[int],
        min_objects_for_browsing: int = 2,
    ) -> Optional[Tuple[InteractionType, float, ContactRegion]]:
        """
        Classify BROWSING behavior (examining multiple objects).

        Parameters
        ----------
        person : DetectionWithDepth
            Person detection.
        examined_objects : List[int]
            List of object IDs the person has examined.
        min_objects_for_browsing : int
            Minimum number of examined objects to classify as browsing.

        Returns
        -------
        Optional[Tuple[InteractionType, float, ContactRegion]]
            Tuple of (interaction_type, confidence, contact_region) or None.
        """
        if len(examined_objects) >= min_objects_for_browsing:
            confidence = min(1.0, 0.6 + len(examined_objects) * 0.1)
            return (InteractionType.BROWSING, confidence, ContactRegion.FACE)

        return None

    def classify_hugging(
        self,
        person1: DetectionWithDepth,
        person2: DetectionWithDepth,
    ) -> Optional[Tuple[InteractionType, float, ContactRegion]]:
        """
        Classify HUGGING interaction between two people.

        HUGGING = high body overlap + close depth + similar heights.

        Parameters
        ----------
        person1 : DetectionWithDepth
            First person detection.
        person2 : DetectionWithDepth
            Second person detection.

        Returns
        -------
        Optional[Tuple[InteractionType, float, ContactRegion]]
            Tuple of (interaction_type, confidence, contact_region) or None.
        """
        # Calculate metrics
        overlap = self._calculate_overlap_ratio(person1.bbox, person2.bbox)

        if person1.has_depth and person2.has_depth:
            depth_distance = abs(
                person1.depth_info.center_depth - person2.depth_info.center_depth
            )
        else:
            depth_distance = 0.0

        # Heights
        h1 = person1.bbox.bottom_right.y - person1.bbox.top_left.y
        h2 = person2.bbox.bottom_right.y - person2.bbox.top_left.y

        # HUGGING requires high overlap, close depth, similar heights
        if overlap > 0.4 and depth_distance < self.depth_proximity_threshold:
            if h1 > 0 and h2 > 0:
                height_ratio = min(h1, h2) / max(h1, h2)
                if height_ratio > 0.6:
                    confidence = min(1.0, overlap + 0.3)
                    return (InteractionType.HUGGING, confidence, ContactRegion.BODY)

        return None

    def classify_handshaking(
        self,
        person1: DetectionWithDepth,
        person2: DetectionWithDepth,
    ) -> Optional[Tuple[InteractionType, float, ContactRegion]]:
        """
        Classify HANDSHAKING interaction between two people.

        HANDSHAKING = moderate overlap at hand level + facing each other.

        Parameters
        ----------
        person1 : DetectionWithDepth
            First person detection.
        person2 : DetectionWithDepth
            Second person detection.

        Returns
        -------
        Optional[Tuple[InteractionType, float, ContactRegion]]
            Tuple of (interaction_type, confidence, contact_region) or None.
        """
        # Calculate hand region overlap
        h1 = person1.bbox.bottom_right.y - person1.bbox.top_left.y
        h2 = person2.bbox.bottom_right.y - person2.bbox.top_left.y

        # Hand region is approximately at 50-75% of body height
        hand_y1_top = person1.bbox.top_left.y + h1 * 0.5
        hand_y1_bottom = person1.bbox.top_left.y + h1 * 0.75
        hand_y2_top = person2.bbox.top_left.y + h2 * 0.5
        hand_y2_bottom = person2.bbox.top_left.y + h2 * 0.75

        # Check if hand regions overlap vertically
        hand_overlap_y = (
            min(hand_y1_bottom, hand_y2_bottom) - max(hand_y1_top, hand_y2_top)
        )

        # Check horizontal proximity (not too close, not too far)
        spatial_distance = self._calculate_spatial_distance(person1.bbox, person2.bbox)
        avg_width = (
            (person1.bbox.bottom_right.x - person1.bbox.top_left.x) +
            (person2.bbox.bottom_right.x - person2.bbox.top_left.x)
        ) / 2

        # Handshake distance: roughly 0.5-1.5 body widths apart
        if hand_overlap_y > 0 and 0.5 * avg_width < spatial_distance < 1.5 * avg_width:
            if person1.has_depth and person2.has_depth:
                depth_distance = abs(
                    person1.depth_info.center_depth - person2.depth_info.center_depth
                )
                if depth_distance < self.near_threshold:
                    return (InteractionType.HANDSHAKING, 0.70, ContactRegion.HAND)

        return None
