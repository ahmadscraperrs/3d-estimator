"""
Kafka Admin Service for Analytics.

This module provides topic management functionality
including automatic topic creation on service startup.
"""

from typing import Optional, List

from aiokafka.admin import AIOKafkaAdminClient, NewTopic
from aiokafka.errors import TopicAlreadyExistsError, KafkaError

from core import configs
from utils import logger


class KafkaAdminService:
    """
    Async Kafka admin service for topic management.

    Handles topic creation and management for the dwell analytics service.

    Attributes
    ----------
    _bootstrap_servers : str
        Kafka bootstrap servers connection string.
    _admin_client : AIOKafkaAdminClient or None
        Underlying admin client instance.

    Examples
    --------
    >>> admin = KafkaAdminService()
    >>> await admin.start()
    >>> await admin.create_topic_if_not_exists("my-topic")
    >>> await admin.close()
    """

    def __init__(
            self,
            bootstrap_servers: Optional[str] = None,
    ) -> None:
        """
        Initialize Kafka admin service.

        Parameters
        ----------
        bootstrap_servers : str, optional
            Kafka bootstrap servers. Defaults to config value.
        """
        self._bootstrap_servers = bootstrap_servers or configs.kafka_bootstrap_servers
        self._admin_client: Optional[AIOKafkaAdminClient] = None

    async def start(self) -> None:
        """
        Start the admin client.

        Creates and connects the underlying AIOKafkaAdminClient.
        """
        if self._admin_client is not None:
            return

        self._admin_client = AIOKafkaAdminClient(
            bootstrap_servers=self._bootstrap_servers,
            client_id="dwell-analytics-admin",
        )
        await self._admin_client.start()
        logger.debug("Kafka admin client started")

    async def close(self) -> None:
        """
        Close the admin client.

        Disconnects and cleans up the admin client.
        """
        if self._admin_client is not None:
            try:
                await self._admin_client.close()
            except Exception as e:
                logger.error(f"Error closing admin client: {e}")
            finally:
                self._admin_client = None

    async def create_topic_if_not_exists(
            self,
            topic: str,
            num_partitions: int = 3,
            replication_factor: int = 1,
    ) -> bool:
        """
        Create a topic if it doesn't already exist.

        Parameters
        ----------
        topic : str
            Topic name to create.
        num_partitions : int, default=3
            Number of partitions for the topic.
        replication_factor : int, default=1
            Replication factor for the topic.

        Returns
        -------
        bool
            True if topic was created or already exists.

        Raises
        ------
        RuntimeError
            If admin client has not been started.
        """
        if self._admin_client is None:
            raise RuntimeError("Admin client not started. Call start() first.")

        try:
            # Check if topic already exists
            existing_topics = await self._admin_client.list_topics()
            if topic in existing_topics:
                logger.info(f"Topic '{topic}' already exists")
                return True

            # Create topic
            new_topic = NewTopic(
                name=topic,
                num_partitions=num_partitions,
                replication_factor=replication_factor,
            )

            await self._admin_client.create_topics([new_topic])

            logger.info(
                f"Created topic '{topic}' with {num_partitions} partitions "
                f"and replication factor {replication_factor}"
            )
            return True

        except TopicAlreadyExistsError:
            logger.info(f"Topic '{topic}' already exists")
            return True

        except KafkaError as e:
            logger.error(f"Kafka error creating topic '{topic}': {e}")
            return False

        except Exception as e:
            logger.error(f"Error creating topic '{topic}': {e}")
            return False

    async def create_topics_if_not_exist(
            self,
            topics: List[str],
            num_partitions: int = 3,
            replication_factor: int = 1,
    ) -> bool:
        """
        Create multiple topics if they don't exist.

        Parameters
        ----------
        topics : List[str]
            List of topic names to create.
        num_partitions : int, default=3
            Number of partitions for each topic.
        replication_factor : int, default=1
            Replication factor for each topic.

        Returns
        -------
        bool
            True if all topics were created or already exist.
        """
        all_success = True
        for topic in topics:
            if not await self.create_topic_if_not_exists(topic, num_partitions, replication_factor):
                all_success = False
        return all_success

    async def topic_exists(self, topic: str) -> bool:
        """
        Check if a topic exists.

        Parameters
        ----------
        topic : str
            Topic name to check.

        Returns
        -------
        bool
            True if topic exists.

        Raises
        ------
        RuntimeError
            If admin client has not been started.
        """
        if self._admin_client is None:
            raise RuntimeError("Admin client not started. Call start() first.")

        try:
            existing_topics = await self._admin_client.list_topics()
            return topic in existing_topics
        except Exception as e:
            logger.error(f"Error checking topic existence: {e}")
            return False


async def ensure_topics_exist(
        topics: Optional[List[str]] = None,
        bootstrap_servers: Optional[str] = None,
) -> bool:
    """
    Ensure required topics exist.

    Convenience function to create topics on service startup.

    Parameters
    ----------
    topics : List[str], optional
        List of topics to ensure exist. Defaults to input/output topics.
    bootstrap_servers : str, optional
        Kafka bootstrap servers. Defaults to config value.

    Returns
    -------
    bool
        True if all topics exist or were created.

    Examples
    --------
    >>> await ensure_topics_exist()  # Use default topics
    >>> await ensure_topics_exist(["custom-topic-1", "custom-topic-2"])
    """
    if topics is None:
        topics = [
            configs.kafka_topic_input,
            configs.kafka_topic_output,
        ]

    admin = KafkaAdminService(bootstrap_servers=bootstrap_servers)

    try:
        await admin.start()
        return await admin.create_topics_if_not_exist(topics)
    finally:
        await admin.close()
