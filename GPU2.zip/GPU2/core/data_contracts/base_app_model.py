"""
Base Pydantic model for Analytics Service.

This module contains the base model configuration used
by all other Pydantic models in the application.

All models inherit from BaseAppModel to get consistent
serialization behavior and validation settings.
"""

import uuid
from datetime import datetime

import numpy as np
from pydantic import BaseModel, ConfigDict


class BaseAppModel(BaseModel):
    """
    Base model for all application data contracts.

    Provides common configuration for JSON serialization,
    validation, and handling of special types.

    Attributes
    ----------
    model_config : ConfigDict
        Pydantic model configuration with custom JSON encoders
        and validation settings.

    Notes
    -----
    Configuration includes:
    - Custom JSON encoders for datetime, UUID, bytes, and numpy arrays
    - Population by field name enabled
    - Assignment validation enabled
    - Enum values used instead of enum objects

    Examples
    --------
    >>> class Detection(BaseAppModel):
    ...     confidence: float
    ...     tracking_id: int
    """

    model_config = ConfigDict(
        arbitrary_types_allowed=True,
        json_encoders={
            datetime: lambda v: v.isoformat() if v else None,
            uuid.UUID: lambda v: str(v) if v else None,
            bytes: lambda v: None,  # Don't serialize bytes in JSON
            np.ndarray: lambda v: None,  # Don't serialize numpy arrays
        },
        json_schema_extra={
            "example": {
                "bbox": [100.0, 200.0, 300.0, 400.0],
                "confidence": 0.95,
                "tracking_id": 1
            }
        },
        # Allow population by field name
        populate_by_name=True,
        # Validate on assignment
        validate_assignment=True,
        # Use enum values
        use_enum_values=True,
    )
