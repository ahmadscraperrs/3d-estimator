"""
Kafka Pydantic models for Analytics Service.

This module contains models for Kafka events - both consumed
from KAFKA_INPUT_TOPIC and published to KAFKA_OUTPUT_TOPIC.
"""

import uuid
from datetime import datetime
from typing import Optional, List, Dict, Any

from pydantic import Field, model_validator

from .base_app_model import BaseAppModel
from .common_models import Region
from .internal_models import Detection, Interaction
from ..enums import EventType, FrameFormat, ServiceType, Compression, InteractionType, ContactRegion


# -----------------------------------------------------------------------------
# Engagement helper enums and models
# -----------------------------------------------------------------------------


class KafkaBaseModel(BaseAppModel):
    """
    Base model for Kafka events.

    Attributes
    ----------
    event_id : uuid.UUID
        Unique identifier for this event (auto-generated if not provided).
    event_type : EventType
        Type of event (default: PERSON_DETECTION).
    camera_id : str
        Identifier of the source camera.
    """
    event_id: uuid.UUID = Field(default_factory=uuid.uuid4, description="Unique event ID")
    event_type: EventType = Field(..., description="Event type")
    camera_id: str = Field(..., description="Camera ID")


class KafkaBaseAnalyticsEvent(KafkaBaseModel):
    """
    Kafka Base Model for Analytics Events.

    Attributes
    ----------
    event_id : uuid.UUID
        Unique identifier for this event.
    event_type : EventType
        Type of event (default: PERSON_DETECTION).
    camera_id : str
        Identifier of the source camera.
    person_event_id : uuid.UUID
        Event ID of the triggering person detection event.
    """
    person_event_id: uuid.UUID = Field(
        ...,
        description="Event ID of the linked person detection event"
    )


class KafkaPersonDetectionEvent(KafkaBaseModel):
    """
    Kafka event consumed from Kafka.Topics.Input topic.

    Represents input events containing person detections
    to be processed for dwell time analysis.

    Attributes
    ----------
    event_id : uuid.UUID
        Unique identifier for this event.
    event_type : EventType
        Type of event (default: PERSON_DETECTION).
    camera_id : str
        Identifier of the source camera.
    frame_number : int
        Sequential frame number.
    timestamp : datetime
        Event timestamp from the video source.
    detections : List[Detection]
        List of person detections in the frame.
    detection_count : int
        Number of detections in the frame.
    frame_data : str, optional
        Base64-encoded compressed frame image.
    frame_format : FrameFormat
        Image format (JPEG or PNG).
    compression : Compression
        Compression algorithm used for frame_data.
    site_id : int, optional
        Site identifier for multi-site deployments.
    camera_serial : str, optional
        Camera serial number.
    services : List[ServiceType]
        Analytics services enabled for this event.
    regions : List[Region]
        Monitored regions in the camera view.
    additional_data : Dict[str, Any]
        Additional metadata key-value pairs.
    """
    frame_number: int = Field(..., ge=0, description="Frame number")
    timestamp: datetime = Field(..., description="Event timestamp")
    detections: List[Detection] = Field(default_factory=list, description="List of detections")
    detection_count: int = Field(default=0, ge=0, description="Number of detections")
    frame_data: Optional[str] = Field(None, description="Base64-encoded compressed frame")
    frame_format: FrameFormat = Field(default=FrameFormat.JPEG, description="Frame format")
    compression: Compression = Field(default=Compression.ZLIB, description="Compression type")

    # Metadata fields
    site_id: Optional[int] = Field(None, description="Site ID")
    camera_serial: Optional[str] = Field(None, description="Camera serial number")
    services: List[ServiceType] = Field(default_factory=list, description="List of enabled analytics services")
    regions: Optional[List[Region]] = Field(None, description="Monitored regions in the camera view")
    additional_data: Dict[str, Any] = Field(default_factory=dict, description="Additional key-value pairs")

    @model_validator(mode='before')
    @classmethod
    def normalize_field_names(cls, data: Any) -> Any:
        """
        Normalize common field name variations.

        Parameters
        ----------
        data : Any
            Input data to normalize.

        Returns
        -------
        Any
            Normalized data with consistent field names.

        Notes
        -----
        Handles:
        - track_id -> tracking_id in detections
        - Polygon coordinate format normalization in regions
        """
        if not isinstance(data, dict):
            return data

        # Handle tracking_id vs track_id in detections
        if 'detections' in data and isinstance(data['detections'], list):
            for detection in data['detections']:
                if isinstance(detection, dict):
                    if 'track_id' in detection and 'tracking_id' not in detection:
                        detection['tracking_id'] = detection.pop('track_id')

        # Handle polygon coordinate variations in regions
        if 'regions' in data and isinstance(data['regions'], list):
            for region in data['regions']:
                if isinstance(region, dict):
                    # Handle polygon as list of dicts with x,y or list of lists
                    if 'polygon' in region and isinstance(region['polygon'], list):
                        normalized_polygon = []
                        for point in region['polygon']:
                            if isinstance(point, dict):
                                # Already correct format
                                normalized_polygon.append(point)
                            elif isinstance(point, (list, tuple)) and len(point) >= 2:
                                # Convert [x, y] to {'x': x, 'y': y}
                                normalized_polygon.append({'x': point[0], 'y': point[1]})
                        region['polygon'] = normalized_polygon

        return data


class KafkaEngagementEvent(KafkaBaseAnalyticsEvent):
    """
    Kafka event for engagement detection.
    Published when a person interacts with an object or another person.
    Topic: video.insights.person.engagement
    
    Structure matches KafkaPersonDetectionEvent for consistency.
    Now includes HOI (Human-Object Interaction) fields for depth-aware detection.
    """

    interaction: Optional[Interaction] = Field(None, description="Interaction between person and object")
    services: List[ServiceType] = Field(
        default_factory=list,
        description="List of enabled analytics services for this camera",
    )
    region: Optional[Region] = Field(None, description="Region metadata where engagement occurred")
    
    # HOI-specific fields (depth-aware detection)
    interaction_type: Optional[InteractionType] = Field(
        None,
        description="HOI interaction type (HOLDING, TOUCHING, USING, NEAR, TALKING, etc.)"
    )
    depth_distance: Optional[float] = Field(
        None,
        description="Depth distance between person and target in relative units (0-1)"
    )
    contact_region: Optional[ContactRegion] = Field(
        None,
        description="Body region involved in the interaction (HAND, ARM, BODY, FACE, etc.)"
    )
    confidence: Optional[float] = Field(
        None,
        ge=0.0,
        le=1.0,
        description="Confidence score for the HOI detection"
    )


class KafkaEventQueueItem(BaseAppModel):
    """
    Queue item for passing events between processes.

    Used for inter-process communication via multiprocessing queues.

    Attributes
    ----------
    event : KafkaBaseAnalyticsEvent
        Analytics event to be published.
    priority : int
        Priority level (lower = higher priority).
    retry_count : int
        Number of publish retry attempts.
    """

    event: KafkaBaseAnalyticsEvent = Field(..., description="Analytics event to publish")
    priority: int = Field(default=0, description="Priority (lower = higher priority)")
    retry_count: int = Field(default=0, ge=0, description="Number of publish retries")
